# Human Or Not? + Admin moderation and Inbox

## 1. New game: "Human Or Not?" (`/human-or-not`)
- New card on the home page next to The Archive, The Button and Chaos Lab, plus a link in the top menu.
- Start screen: pick a timer — 3 minutes (default) or a custom value from 3 to 20 minutes (slider).
- Each round secretly picks the partner: "Human" (AI acting as a casual real person with typos, slang, opinions, short replies) or "Not human" (an AI that behaves like a chatbot, with small giveaways).
- Difficulty grows with the timer: longer rounds make the "Not human" partner hide its tells better and make the "Human" partner sound more polished, so it gets harder to tell.
- The player chats freely; a countdown runs. They can guess "Human" or "Not human" anytime; when time runs out they must guess.
- Result screen reveals the truth, shows a short explanation, and gives score points for a correct guess (once per round, recorded with existing scoring) plus a new achievement.
- Fully in English and Indonesian: the page text and the partner chats in the language chosen in Settings.
- Signed-in only for playing (so rounds and scores are saved); signed-out visitors see a "Sign in to play" button.

AI note: Lovable AI has no API key to set up, and it comes with a free monthly allowance. Heavy use may use workspace credits after that.

## 2. Admin: activity log of all users
- New "Activity" tab: a list of what every user does — pages and experiments played, Human Or Not rounds, profile changes (name, photo, password, preferences), sign-ins and terms acceptance. Filters for user, type of activity and date; search by username.

## 3. Admin: moderation panel
- New "Users" tab with search; open a user to see their profile, recent activity and moderation history.
- Actions (each needs a reason and is written to the audit log):
  - Warning: sends a warning message to the user's Inbox.
  - Timeout (adjustable, e.g. 10 min to 7 days): user can browse but can't play, earn points or edit their profile.
  - Suspend (adjustable, 1 day to 1 year): user can't sign in until it ends; lifts automatically.
  - Ban (permanent): user can't sign in again.
  - Lift: remove an active timeout, suspension or ban.
- The user gets an Inbox message for every action, showing the reason and end time.
- Admins can't moderate themselves or other admins.

## 4. Inbox for users + "Send Information" for admins
- Inbox icon with unread count in the header (signed-in users), and an Inbox page listing messages with type (information, warning, moderation), read/unread, and mark-as-read.
- Admin "Send Information" tab: write a title and message, send it to one user or to all users. Messages appear in the Inbox.

## 5. Translations and checks
- All new screens in English and Indonesian.
- Tests for: timer range 3–20 minutes with 3 as default, difficulty rising with duration, timeout/suspend end-time calculation, ban being permanent.
- Browser check signed in: play a round, send a warning to a test user, confirm it reaches the Inbox.

## Technical details
- Tables (with grants + RLS): `game_rounds` (user, persona hidden server-side, duration, difficulty, messages, guess, result), `moderation_actions` (target, admin, type, reason, expires_at, lifted_at), `inbox_messages` (recipient, sender, kind, title, body, read_at). Users read only their own inbox/rounds; persona never sent to the browser until the round ends.
- Chat uses a server function streaming through Lovable AI Gateway (default model), system prompt built from persona + difficulty + language; the server enforces the round deadline.
- Suspend/ban use the auth ban duration (timed or permanent) plus `profiles.status`; timeout is checked in reward/profile/game server functions. Expired actions resolve by comparing `expires_at` to now.
- Activity log extends the existing `activity_events` logging to profile changes, sign-ins and game rounds; admin reads through role-checked server functions.
