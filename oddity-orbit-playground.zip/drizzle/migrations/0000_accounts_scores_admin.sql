
-- ===== Roles =====
create type public.app_role as enum ('admin', 'moderator', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- ===== Terms version (keep in sync with TERMS_VERSION in src/lib/terms.ts) =====
create or replace function public.current_terms_version()
returns text language sql immutable set search_path = public as $$ select '1.0'::text $$;

-- ===== Profiles =====
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[a-z0-9_]{3,20}$'),
  display_name text check (display_name is null or char_length(display_name) between 1 and 40),
  avatar_url text check (avatar_url is null or char_length(avatar_url) <= 500),
  status text not null default 'active' check (status in ('active', 'suspended')),
  preferences jsonb not null default '{}'::jsonb,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index profiles_username_key on public.profiles (lower(username));
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url, preferences) on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "Users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update to authenticated
  using (auth.uid() = id and status = 'active') with check (auth.uid() = id);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end $$;
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.touch_updated_at();

create or replace function public.username_available(_username text)
returns boolean language sql stable security definer set search_path = public as $$
  select not exists (select 1 from public.profiles where lower(username) = lower(trim(_username)))
$$;
grant execute on function public.username_available(text) to anon, authenticated;

-- ===== Terms acceptances =====
create table public.terms_acceptances (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  version text not null,
  accepted_at timestamptz not null default now(),
  unique (user_id, version)
);
grant select on public.terms_acceptances to authenticated;
grant all on public.terms_acceptances to service_role;
alter table public.terms_acceptances enable row level security;
create policy "Users read own acceptances" on public.terms_acceptances for select to authenticated using (auth.uid() = user_id);

create or replace function public.accept_current_terms()
returns timestamptz language plpgsql security definer set search_path = public as $$
declare ts timestamptz;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  insert into public.terms_acceptances (user_id, version) values (auth.uid(), public.current_terms_version())
    on conflict (user_id, version) do nothing;
  select accepted_at into ts from public.terms_acceptances where user_id = auth.uid() and version = public.current_terms_version();
  return ts;
end $$;
revoke execute on function public.accept_current_terms() from public, anon;
grant execute on function public.accept_current_terms() to authenticated;

-- ===== New user trigger =====
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  uname text := lower(trim(coalesce(new.raw_user_meta_data->>'username', '')));
begin
  if uname !~ '^[a-z0-9_]{3,20}$' then
    uname := 'user_' || substr(replace(new.id::text, '-', ''), 1, 10);
  end if;
  insert into public.profiles (id, username, display_name) values (new.id, uname, uname);
  if coalesce(new.raw_user_meta_data->>'tos_version', '') = public.current_terms_version() then
    insert into public.terms_acceptances (user_id, version) values (new.id, public.current_terms_version());
  end if;
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ===== Achievements & scoring config =====
create table public.achievements (
  id text primary key check (id ~ '^[a-z0-9-]{2,40}$'),
  title_en text not null check (char_length(title_en) between 1 and 60),
  title_id text not null check (char_length(title_id) between 1 and 60),
  description_en text not null check (char_length(description_en) between 1 and 200),
  description_id text not null check (char_length(description_id) between 1 and 200),
  rarity text not null check (rarity in ('common', 'uncommon', 'rare', 'epic', 'legendary')),
  metric text not null check (metric in ('any', 'experiments', 'oddities', 'button_events', 'easter_eggs', 'discoveries')),
  target int not null check (target between 1 and 10000),
  points int not null default 0 check (points between 0 and 10000),
  active boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.achievements to anon, authenticated;
grant all on public.achievements to service_role;
alter table public.achievements enable row level security;
create policy "Anyone reads achievements" on public.achievements for select to anon, authenticated using (true);

create table public.score_rules (
  kind text primary key check (kind in ('experiment', 'oddity', 'button_event', 'easter_egg')),
  points int not null check (points between 0 and 10000),
  updated_at timestamptz not null default now()
);
grant select on public.score_rules to anon, authenticated;
grant all on public.score_rules to service_role;
alter table public.score_rules enable row level security;
create policy "Anyone reads score rules" on public.score_rules for select to anon, authenticated using (true);

insert into public.score_rules (kind, points) values
  ('experiment', 50), ('oddity', 10), ('button_event', 5), ('easter_egg', 100);

insert into public.achievements (id, title_en, title_id, description_en, description_id, rarity, metric, target, points, sort) values
  ('first-steps', 'First steps', 'Langkah pertama', 'Earn your very first point anywhere in the lab.', 'Dapatkan poin pertamamu di mana saja di lab.', 'common', 'any', 1, 10, 1),
  ('lab-rat', 'Lab rat', 'Tikus lab', 'Complete one experiment.', 'Selesaikan satu eksperimen.', 'common', 'experiments', 1, 20, 2),
  ('mad-scientist', 'Mad scientist', 'Ilmuwan gila', 'Complete all four experiments.', 'Selesaikan keempat eksperimen.', 'epic', 'experiments', 4, 150, 3),
  ('curious', 'Curious mind', 'Pikiran penasaran', 'Examine 5 entries in the Oddities Archive.', 'Periksa 5 entri di Arsip Keanehan.', 'common', 'oddities', 5, 20, 4),
  ('archivist', 'Archivist', 'Arsiparis', 'Examine 15 entries in the Oddities Archive.', 'Periksa 15 entri di Arsip Keanehan.', 'uncommon', 'oddities', 15, 50, 5),
  ('librarian', 'Keeper of oddities', 'Penjaga keanehan', 'Examine 30 entries in the Oddities Archive.', 'Periksa 30 entri di Arsip Keanehan.', 'rare', 'oddities', 30, 100, 6),
  ('button-curious', 'Button curious', 'Penasaran tombol', 'Find 10 different events on The Button.', 'Temukan 10 kejadian berbeda di Tombol.', 'uncommon', 'button_events', 10, 30, 7),
  ('button-whisperer', 'Button whisperer', 'Pembisik tombol', 'Find every event The Button can produce.', 'Temukan semua kejadian yang bisa dibuat Tombol.', 'legendary', 'button_events', 29, 250, 8),
  ('explorer', 'Explorer', 'Penjelajah', 'Make 25 discoveries across the archive and The Button.', 'Buat 25 penemuan di arsip dan Tombol.', 'rare', 'discoveries', 25, 80, 9),
  ('egg-hunter', 'Egg hunter', 'Pemburu telur', 'Find a hidden interaction.', 'Temukan satu interaksi tersembunyi.', 'uncommon', 'easter_eggs', 1, 30, 10),
  ('egg-collector', 'Egg collector', 'Kolektor telur', 'Find 3 hidden interactions.', 'Temukan 3 interaksi tersembunyi.', 'rare', 'easter_eggs', 3, 100, 11),
  ('egg-master', 'Master of secrets', 'Penguasa rahasia', 'Find every hidden interaction in ODD.LAB.', 'Temukan semua interaksi tersembunyi di ODD.LAB.', 'legendary', 'easter_eggs', 6, 300, 12);

-- ===== Rewards (one per user + item) =====
create table public.user_rewards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  kind text not null check (kind in ('experiment', 'oddity', 'button_event', 'easter_egg')),
  item_id text not null check (char_length(item_id) between 1 and 64),
  points int not null default 0,
  created_at timestamptz not null default now(),
  unique (user_id, kind, item_id)
);
create index user_rewards_user_idx on public.user_rewards (user_id);
grant select on public.user_rewards to authenticated;
grant all on public.user_rewards to service_role;
alter table public.user_rewards enable row level security;
create policy "Users read own rewards" on public.user_rewards for select to authenticated using (auth.uid() = user_id);

create table public.user_achievements (
  user_id uuid not null,
  achievement_id text not null references public.achievements(id) on delete cascade,
  points int not null default 0,
  unlocked_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);
grant select on public.user_achievements to authenticated;
grant all on public.user_achievements to service_role;
alter table public.user_achievements enable row level security;
create policy "Users read own achievements" on public.user_achievements for select to authenticated using (auth.uid() = user_id);

-- ===== Activity / presence / audit (server only) =====
create table public.activity_events (
  id bigint generated always as identity primary key,
  user_id uuid,
  kind text not null,
  item_id text,
  created_at timestamptz not null default now()
);
create index activity_events_created_idx on public.activity_events (created_at);
grant all on public.activity_events to service_role;
alter table public.activity_events enable row level security;

create table public.daily_active (
  user_id uuid not null,
  day date not null default current_date,
  primary key (user_id, day)
);
grant all on public.daily_active to service_role;
alter table public.daily_active enable row level security;

create table public.admin_audit_log (
  id bigint generated always as identity primary key,
  admin_id uuid not null,
  action text not null,
  target_type text,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
grant all on public.admin_audit_log to service_role;
alter table public.admin_audit_log enable row level security;

create or replace function public.touch_presence()
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  update public.profiles set last_seen_at = now() where id = auth.uid();
  insert into public.daily_active (user_id, day) values (auth.uid(), current_date) on conflict do nothing;
end $$;
revoke execute on function public.touch_presence() from public, anon;
grant execute on function public.touch_presence() to authenticated;

-- ===== Extra archive entries (admin managed) =====
create table public.custom_oddities (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('fact', 'mystery', 'discovery')),
  title_en text not null check (char_length(title_en) between 1 and 80),
  title_id text not null check (char_length(title_id) between 1 and 80),
  body_en text not null check (char_length(body_en) between 1 and 400),
  body_id text not null check (char_length(body_id) between 1 and 400),
  published boolean not null default true,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.custom_oddities to anon, authenticated;
grant all on public.custom_oddities to service_role;
alter table public.custom_oddities enable row level security;
create policy "Anyone reads published entries" on public.custom_oddities for select to anon, authenticated using (published);
create trigger custom_oddities_updated_at before update on public.custom_oddities
  for each row execute function public.touch_updated_at();

-- ===== Scoring functions (service role only) =====
create or replace function public.metric_count(_user_id uuid, _metric text)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.user_rewards
  where user_id = _user_id and (
    _metric = 'any'
    or (_metric = 'experiments' and kind = 'experiment')
    or (_metric = 'oddities' and kind = 'oddity')
    or (_metric = 'button_events' and kind = 'button_event')
    or (_metric = 'easter_eggs' and kind = 'easter_egg')
    or (_metric = 'discoveries' and kind in ('oddity', 'button_event'))
  )
$$;

create or replace function public.sync_achievements(_user_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r record; unlocked jsonb := '[]'::jsonb; n int;
begin
  for r in
    select a.* from public.achievements a
    where a.active and not exists (
      select 1 from public.user_achievements ua where ua.user_id = _user_id and ua.achievement_id = a.id)
    order by a.sort
  loop
    if public.metric_count(_user_id, r.metric) >= r.target then
      insert into public.user_achievements (user_id, achievement_id, points)
        values (_user_id, r.id, r.points) on conflict do nothing;
      get diagnostics n = row_count;
      if n > 0 then
        unlocked := unlocked || jsonb_build_object('id', r.id, 'title_en', r.title_en, 'title_id', r.title_id, 'rarity', r.rarity, 'points', r.points);
      end if;
    end if;
  end loop;
  return unlocked;
end $$;

create or replace function public.record_reward(_user_id uuid, _kind text, _item_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare pts int; n int;
begin
  select points into pts from public.score_rules where kind = _kind;
  if pts is null then raise exception 'Unknown reward kind'; end if;
  insert into public.user_rewards (user_id, kind, item_id, points)
    values (_user_id, _kind, _item_id, pts) on conflict (user_id, kind, item_id) do nothing;
  get diagnostics n = row_count;
  insert into public.activity_events (user_id, kind, item_id) values (_user_id, _kind, _item_id);
  if n = 0 then
    return jsonb_build_object('new', false, 'points', 0, 'achievements', '[]'::jsonb);
  end if;
  return jsonb_build_object('new', true, 'points', pts, 'achievements', public.sync_achievements(_user_id));
end $$;

-- ===== Admin read helpers (service role only) =====
create or replace function public.admin_list_users(_search text, _limit int, _offset int)
returns table (
  id uuid, email text, username text, display_name text, avatar_url text, status text,
  created_at timestamptz, last_seen_at timestamptz, last_sign_in_at timestamptz,
  is_admin boolean, score bigint, total_count bigint
) language sql stable security definer set search_path = public as $$
  with base as (
    select p.id, u.email::text as email, p.username, p.display_name, p.avatar_url, p.status,
      p.created_at, p.last_seen_at, u.last_sign_in_at,
      public.has_role(p.id, 'admin') as is_admin,
      coalesce((select sum(points) from public.user_rewards r where r.user_id = p.id), 0)
        + coalesce((select sum(points) from public.user_achievements a where a.user_id = p.id), 0) as score
    from public.profiles p join auth.users u on u.id = p.id
    where coalesce(trim(_search), '') = ''
      or p.username ilike '%' || trim(_search) || '%'
      or u.email ilike '%' || trim(_search) || '%'
      or p.display_name ilike '%' || trim(_search) || '%'
  )
  select b.*, count(*) over () as total_count from base b
  order by b.created_at desc
  limit greatest(1, least(_limit, 100)) offset greatest(0, _offset)
$$;

create or replace function public.admin_stats()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'total_users', (select count(*) from public.profiles),
    'suspended_users', (select count(*) from public.profiles where status = 'suspended'),
    'active_24h', (select count(*) from public.profiles where last_seen_at > now() - interval '24 hours'),
    'active_7d', (select count(*) from public.profiles where last_seen_at > now() - interval '7 days'),
    'active_30d', (select count(*) from public.profiles where last_seen_at > now() - interval '30 days'),
    'total_rewards', (select count(*) from public.user_rewards),
    'total_unlocks', (select count(*) from public.user_achievements),
    'events_7d', (select count(*) from public.activity_events where created_at > now() - interval '7 days'),
    'registrations_daily', (
      select coalesce(jsonb_agg(jsonb_build_object('day', d::date, 'count', (
        select count(*) from public.profiles p where p.created_at::date = d::date)) order by d), '[]'::jsonb)
      from generate_series(current_date - 29, current_date, interval '1 day') d),
    'registrations_monthly', (
      select coalesce(jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'), 'count', (
        select count(*) from public.profiles p where date_trunc('month', p.created_at) = m)) order by m), '[]'::jsonb)
      from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') m),
    'active_daily', (
      select coalesce(jsonb_agg(jsonb_build_object('day', d::date, 'count', (
        select count(*) from public.daily_active a where a.day = d::date)) order by d), '[]'::jsonb)
      from generate_series(current_date - 29, current_date, interval '1 day') d),
    'active_monthly', (
      select coalesce(jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'), 'count', (
        select count(distinct a.user_id) from public.daily_active a where date_trunc('month', a.day) = m)) order by m), '[]'::jsonb)
      from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') m),
    'experiment_popularity', (
      select coalesce(jsonb_agg(jsonb_build_object('item', item_id, 'count', c) order by c desc), '[]'::jsonb)
      from (select item_id, count(*) c from public.activity_events where kind = 'play' group by item_id) x),
    'achievement_stats', (
      select coalesce(jsonb_agg(jsonb_build_object('id', a.id, 'title', a.title_en, 'rarity', a.rarity, 'count', (
        select count(*) from public.user_achievements ua where ua.achievement_id = a.id)) order by a.sort), '[]'::jsonb)
      from public.achievements a)
  )
$$;

revoke execute on function public.metric_count(uuid, text) from public, anon, authenticated;
revoke execute on function public.sync_achievements(uuid) from public, anon, authenticated;
revoke execute on function public.record_reward(uuid, text, text) from public, anon, authenticated;
revoke execute on function public.admin_list_users(text, int, int) from public, anon, authenticated;
revoke execute on function public.admin_stats() from public, anon, authenticated;
grant execute on function public.metric_count(uuid, text) to service_role;
grant execute on function public.sync_achievements(uuid) to service_role;
grant execute on function public.record_reward(uuid, text, text) to service_role;
grant execute on function public.admin_list_users(text, int, int) to service_role;
grant execute on function public.admin_stats() to service_role;
