alter table public.profiles drop constraint if exists profiles_status_check;
alter table public.profiles add constraint profiles_status_check check (status in ('active', 'suspended', 'banned'));
alter table public.profiles add column if not exists suspended_until timestamptz;
alter table public.profiles add column if not exists timeout_until timestamptz;

drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated
  using (auth.uid() = id and status = 'active' and (timeout_until is null or timeout_until < now()))
  with check (auth.uid() = id);

-- Users must not change their own moderation fields.
revoke update on public.profiles from authenticated;
grant update (display_name, avatar_url, preferences, last_seen_at) on public.profiles to authenticated;

-- Lift an expired suspension for the signed-in user.
create or replace function public.clear_expired_moderation()
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set status = 'active', suspended_until = null
  where id = auth.uid() and status = 'suspended' and suspended_until is not null and suspended_until < now();
end $$;
revoke execute on function public.clear_expired_moderation() from public, anon;
grant execute on function public.clear_expired_moderation() to authenticated;

-- Game scoring
alter table public.score_rules drop constraint if exists score_rules_kind_check;
alter table public.score_rules add constraint score_rules_kind_check check (kind in ('experiment', 'oddity', 'button_event', 'easter_egg', 'game'));
alter table public.user_rewards drop constraint if exists user_rewards_kind_check;
alter table public.user_rewards add constraint user_rewards_kind_check check (kind in ('experiment', 'oddity', 'button_event', 'easter_egg', 'game'));
insert into public.score_rules (kind, points) values ('game', 25) on conflict (kind) do nothing;
alter table public.achievements drop constraint if exists achievements_metric_check;
alter table public.achievements add constraint achievements_metric_check check (metric in ('any', 'experiments', 'oddities', 'button_events', 'easter_eggs', 'discoveries', 'games'));

create or replace function public.metric_count(_user_id uuid, _metric text)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.user_rewards
  where user_id = _user_id and (
    _metric = 'any'
    or (_metric = 'experiments' and kind = 'experiment')
    or (_metric = 'oddities' and kind = 'oddity')
    or (_metric = 'button_events' and kind = 'button_event')
    or (_metric = 'easter_eggs' and kind = 'easter_egg')
    or (_metric = 'discoveries' and kind in ('oddity', 'button_event'))
    or (_metric = 'games' and kind = 'game')
  )
$$;
revoke execute on function public.metric_count(uuid, text) from public, anon, authenticated;
grant execute on function public.metric_count(uuid, text) to service_role;

insert into public.achievements (id, title_en, title_id, description_en, description_id, rarity, metric, target, points, sort) values
  ('turing-tester', 'Turing tester', 'Penguji Turing', 'Guess correctly in 3 rounds of Human Or Not?', 'Tebak dengan benar di 3 ronde Manusia Atau Bukan?', 'rare', 'games', 3, 75, 50)
on conflict (id) do nothing;

-- Game rounds (server only)
create table public.game_rounds (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  persona text not null check (persona in ('human', 'ai')),
  lang text not null check (lang in ('en', 'id')),
  minutes int not null check (minutes between 3 and 20),
  difficulty int not null check (difficulty between 1 and 5),
  messages jsonb not null default '[]'::jsonb,
  deadline timestamptz not null,
  guess text check (guess in ('human', 'ai')),
  correct boolean,
  finished_at timestamptz,
  created_at timestamptz not null default now()
);
create index game_rounds_user_idx on public.game_rounds (user_id, created_at);
grant all on public.game_rounds to service_role;
alter table public.game_rounds enable row level security;

-- Moderation history
create table public.moderation_actions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  admin_id uuid not null,
  action text not null check (action in ('warning', 'timeout', 'suspend', 'ban', 'lift')),
  reason text not null check (char_length(reason) between 1 and 500),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index moderation_actions_user_idx on public.moderation_actions (user_id, created_at);
grant all on public.moderation_actions to service_role;
alter table public.moderation_actions enable row level security;

-- Inbox
create table public.inbox_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  sender_id uuid,
  kind text not null default 'info' check (kind in ('info', 'warning', 'moderation')),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 2000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index inbox_messages_user_idx on public.inbox_messages (user_id, created_at);
grant select on public.inbox_messages to authenticated;
grant update (read_at) on public.inbox_messages to authenticated;
grant all on public.inbox_messages to service_role;
alter table public.inbox_messages enable row level security;
create policy "Users read own inbox" on public.inbox_messages for select to authenticated using (auth.uid() = user_id);
create policy "Users mark own inbox read" on public.inbox_messages for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Automatic activity logging
create or replace function public.log_profile_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.display_name is distinct from old.display_name then
    insert into public.activity_events (user_id, kind, item_id) values (new.id, 'profile', 'display_name');
  end if;
  if new.avatar_url is distinct from old.avatar_url then
    insert into public.activity_events (user_id, kind, item_id) values (new.id, 'profile', 'avatar');
  end if;
  if new.preferences is distinct from old.preferences then
    insert into public.activity_events (user_id, kind, item_id) values (new.id, 'profile', 'preferences');
  end if;
  return new;
end $$;
create trigger profiles_log_change after update on public.profiles for each row execute function public.log_profile_change();

create or replace function public.log_terms_acceptance()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.activity_events (user_id, kind, item_id) values (new.user_id, 'terms', new.version);
  return new;
end $$;
create trigger terms_log_accept after insert on public.terms_acceptances for each row execute function public.log_terms_acceptance();

create or replace function public.log_presence()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.activity_events (user_id, kind, item_id) values (new.user_id, 'visit', null);
  return new;
end $$;
create trigger daily_active_log after insert on public.daily_active for each row execute function public.log_presence();