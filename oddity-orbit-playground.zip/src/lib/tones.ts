export type Tone = "coral" | "mint" | "sky" | "sun" | "lime";

export const TONES: Tone[] = ["coral", "mint", "sky", "sun", "lime"];

// Static class strings so Tailwind can see them.
export const toneSoft: Record<Tone, string> = {
  coral: "bg-coral/15 text-coral",
  mint: "bg-mint/20 text-mint",
  sky: "bg-sky/15 text-sky",
  sun: "bg-sun/25 text-sun",
  lime: "bg-lime/25 text-lime",
};

export const toneSolid: Record<Tone, string> = {
  coral: "bg-coral",
  mint: "bg-mint",
  sky: "bg-sky",
  sun: "bg-sun",
  lime: "bg-lime",
};

export const toneDot: Record<Tone, string> = {
  coral: "bg-coral",
  mint: "bg-mint",
  sky: "bg-sky",
  sun: "bg-sun",
  lime: "bg-lime",
};
