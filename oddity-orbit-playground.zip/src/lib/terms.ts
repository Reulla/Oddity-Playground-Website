import type { Lang } from "./preferences";

/**
 * Current Terms of Service version. Must match public.current_terms_version() in the database.
 * Bump both together for a significant change: users then have to accept again.
 */
export const TERMS_VERSION = "1.0";
export const TERMS_EFFECTIVE = "2026-11-15";

export type TermsSection = { id: string; privacy?: boolean; title: Record<Lang, string>; body: Record<Lang, string[]> };

export const TERMS_SECTIONS: TermsSection[] = [
  {
    id: "terms",
    title: { en: "1. Terms of Service", id: "1. Ketentuan Layanan" },
    body: {
      en: [
        "ODD.LAB is a free, playful website of experiments, simulations and curiosities. By creating an account or using account features you agree to these terms.",
        "Everything on ODD.LAB is provided for fun and “as is”. Fictional mysteries are labelled as fiction; facts are shared in good faith but are not professional advice.",
        "You must be at least 13 years old, or have permission from a parent or guardian, to create an account.",
      ],
      id: [
        "ODD.LAB adalah situs gratis dan menyenangkan berisi eksperimen, simulasi, dan keanehan. Dengan membuat akun atau memakai fitur akun, kamu menyetujui ketentuan ini.",
        "Semua isi ODD.LAB disediakan untuk hiburan dan “apa adanya”. Misteri fiksi diberi label fiksi; fakta dibagikan dengan itikad baik tetapi bukan nasihat profesional.",
        "Kamu harus berusia minimal 13 tahun, atau mendapat izin orang tua atau wali, untuk membuat akun.",
      ],
    },
  },
  {
    id: "privacy",
    privacy: true,
    title: { en: "2. Privacy Policy", id: "2. Kebijakan Privasi" },
    body: {
      en: [
        "We collect as little as possible. We never sell your data and never show you advertising based on it.",
        "Your profile picture and statistics are private: only you and ODD.LAB administrators can see them.",
        "You can ask us to delete your account and all related data at any time.",
      ],
      id: [
        "Kami mengumpulkan data sesedikit mungkin. Kami tidak pernah menjual datamu dan tidak pernah menampilkan iklan berdasarkan data itu.",
        "Foto profil dan statistikmu bersifat pribadi: hanya kamu dan administrator ODD.LAB yang bisa melihatnya.",
        "Kamu bisa meminta kami menghapus akun dan semua data terkait kapan saja.",
      ],
    },
  },
  {
    id: "responsibilities",
    title: { en: "3. User Responsibilities", id: "3. Tanggung Jawab Pengguna" },
    body: {
      en: [
        "Give accurate information when you sign up and keep your email address up to date.",
        "Keep your password secret. You are responsible for activity on your account.",
        "Be kind. ODD.LAB is meant to be a friendly place for curious people.",
      ],
      id: [
        "Berikan informasi yang benar saat mendaftar dan jaga agar alamat emailmu tetap terbaru.",
        "Rahasiakan kata sandimu. Kamu bertanggung jawab atas aktivitas di akunmu.",
        "Bersikaplah baik. ODD.LAB dibuat sebagai tempat yang ramah untuk orang yang penasaran.",
      ],
    },
  },
  {
    id: "rules",
    title: { en: "4. Account Rules", id: "4. Aturan Akun" },
    body: {
      en: [
        "One person, one account. Accounts are personal and may not be sold, shared or transferred.",
        "Usernames must not impersonate others or contain offensive language. Usernames cannot be changed later.",
        "Scores and achievements are for fun and have no monetary value.",
      ],
      id: [
        "Satu orang, satu akun. Akun bersifat pribadi dan tidak boleh dijual, dibagikan, atau dipindahtangankan.",
        "Nama pengguna tidak boleh meniru orang lain atau berisi kata-kata kasar. Nama pengguna tidak bisa diubah kemudian.",
        "Skor dan pencapaian hanya untuk hiburan dan tidak memiliki nilai uang.",
      ],
    },
  },
  {
    id: "prohibited",
    title: { en: "5. Prohibited Activities", id: "5. Aktivitas yang Dilarang" },
    body: {
      en: [
        "Cheating the score system with scripts, bots or by tampering with requests.",
        "Trying to access other people's accounts, administrative areas or data you are not allowed to see.",
        "Attacking, overloading or disrupting the website, or using it for anything illegal.",
      ],
      id: [
        "Mencurangi sistem skor dengan skrip, bot, atau memanipulasi permintaan.",
        "Mencoba mengakses akun orang lain, area administrasi, atau data yang tidak boleh kamu lihat.",
        "Menyerang, membebani, atau mengganggu situs, atau memakainya untuk hal yang melanggar hukum.",
      ],
    },
  },
  {
    id: "termination",
    title: { en: "6. Account Termination Policy", id: "6. Kebijakan Penghentian Akun" },
    body: {
      en: [
        "Administrators may suspend or delete accounts that break these terms. A suspended account cannot sign in until it is reactivated.",
        "You may stop using ODD.LAB at any time and ask for your account to be deleted. Deletion removes your profile, score and achievements permanently.",
      ],
      id: [
        "Administrator dapat menangguhkan atau menghapus akun yang melanggar ketentuan ini. Akun yang ditangguhkan tidak bisa masuk sampai diaktifkan kembali.",
        "Kamu boleh berhenti memakai ODD.LAB kapan saja dan meminta akunmu dihapus. Penghapusan menghilangkan profil, skor, dan pencapaianmu secara permanen.",
      ],
    },
  },
  {
    id: "data",
    privacy: true,
    title: { en: "7. Data Collection and Usage", id: "7. Pengumpulan dan Penggunaan Data" },
    body: {
      en: [
        "Account data: username, email address, display name, profile picture and the date you joined.",
        "Activity data: which experiments you play, what you discover, your points, achievements and when you were last active. We use it to run the score system and to see which experiments people enjoy.",
        "Preferences: language, appearance and text size, stored on your device and, when signed in, on your account.",
        "Agreement records: which version of these terms you accepted and when.",
      ],
      id: [
        "Data akun: nama pengguna, alamat email, nama tampilan, foto profil, dan tanggal bergabung.",
        "Data aktivitas: eksperimen yang kamu mainkan, hal yang kamu temukan, poin, pencapaian, dan kapan terakhir kamu aktif. Kami memakainya untuk menjalankan sistem skor dan melihat eksperimen mana yang disukai orang.",
        "Preferensi: bahasa, tampilan, dan ukuran teks, disimpan di perangkatmu dan, saat masuk, di akunmu.",
        "Catatan persetujuan: versi ketentuan yang kamu setujui dan kapan.",
      ],
    },
  },
  {
    id: "security",
    privacy: true,
    title: { en: "8. Security and Account Protection", id: "8. Keamanan dan Perlindungan Akun" },
    body: {
      en: [
        "Passwords are never stored in readable form and nobody at ODD.LAB — including administrators — can see them.",
        "Password recovery only works through a time-limited link sent to your email address.",
        "If you think someone else has access to your account, change your password straight away.",
      ],
      id: [
        "Kata sandi tidak pernah disimpan dalam bentuk yang bisa dibaca dan tidak ada seorang pun di ODD.LAB — termasuk administrator — yang bisa melihatnya.",
        "Pemulihan kata sandi hanya bisa lewat tautan berbatas waktu yang dikirim ke alamat emailmu.",
        "Jika kamu merasa orang lain bisa mengakses akunmu, segera ubah kata sandimu.",
      ],
    },
  },
  {
    id: "changes",
    title: { en: "9. Changes to Terms", id: "9. Perubahan Ketentuan" },
    body: {
      en: [
        "We may update these terms. Every version has a number and an effective date shown at the top of this page.",
        "After a significant change you will be asked to review and accept the new version before you can keep using account features such as earning points.",
      ],
      id: [
        "Kami dapat memperbarui ketentuan ini. Setiap versi memiliki nomor dan tanggal berlaku yang tampil di bagian atas halaman ini.",
        "Setelah perubahan penting, kamu akan diminta meninjau dan menyetujui versi baru sebelum bisa terus memakai fitur akun seperti mengumpulkan poin.",
      ],
    },
  },
];
