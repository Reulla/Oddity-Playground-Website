import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { parsePrefs, usePreferences } from "./preferences";
import { TERMS_VERSION } from "./terms";

export type Profile = Tables<"profiles">;

type AuthCtx = {
  ready: boolean;
  user: User | null;
  profile: Profile | null;
  avatarUrl: string | null;
  isAdmin: boolean;
  /** Accepted the current Terms version. */
  termsOk: boolean;
  termsAcceptedAt: string | null;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthCtx | null>(null);

/** "Remember me" off: the session is dropped when the browser is closed. */
export const EPHEMERAL_KEY = "oddlab-ephemeral-session";
export const SESSION_ALIVE_KEY = "oddlab-session-alive";

export function setRememberMe(remember: boolean) {
  if (remember) localStorage.removeItem(EPHEMERAL_KEY);
  else localStorage.setItem(EPHEMERAL_KEY, "1");
  sessionStorage.setItem(SESSION_ALIVE_KEY, "1");
}

export async function signedAvatarUrl(path: string | null | undefined) {
  if (!path) return null;
  const { data } = await supabase.storage.from("avatars").createSignedUrl(path, 60 * 60);
  return data?.signedUrl ?? null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { prefs, ready: prefsReady, setPrefs } = usePreferences();
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [termsAcceptedAt, setTermsAcceptedAt] = useState<string | null>(null);
  const syncedPrefs = useRef<string | null>(null);
  const presenceFor = useRef<string | null>(null);

  const load = useCallback(
    async (u: User | null) => {
      setUser(u);
      if (!u) {
        setProfile(null);
        setAvatarUrl(null);
        setIsAdmin(false);
        setTermsAcceptedAt(null);
        syncedPrefs.current = null;
        setReady(true);
        return;
      }
      await supabase.rpc("clear_expired_moderation");
      const [{ data: p }, { data: roles }, { data: terms }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", u.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", u.id),
        supabase.from("terms_acceptances").select("accepted_at").eq("user_id", u.id).eq("version", TERMS_VERSION).maybeSingle(),
      ]);
      setProfile(p ?? null);
      setIsAdmin(!!roles?.some((r) => r.role === "admin"));
      setTermsAcceptedAt(terms?.accepted_at ?? null);
      setAvatarUrl(await signedAvatarUrl(p?.avatar_url));
      // Account preferences win over this device's once per sign-in.
      if (p && syncedPrefs.current === null) {
        const stored = p.preferences as Record<string, unknown> | null;
        if (stored && Object.keys(stored).length > 0) {
          const parsed = parsePrefs(stored);
          syncedPrefs.current = JSON.stringify(parsed);
          setPrefs(parsed);
        } else {
          syncedPrefs.current = "";
        }
      }
      if (presenceFor.current !== u.id) {
        presenceFor.current = u.id;
        void supabase.rpc("touch_presence");
      }
      setReady(true);
    },
    [setPrefs],
  );

  useEffect(() => {
    let cancelled = false;
    // "Remember me" was off and the browser has been closed since: drop the session.
    const ephemeral = localStorage.getItem(EPHEMERAL_KEY) === "1";
    const alive = sessionStorage.getItem(SESSION_ALIVE_KEY) === "1";
    const start = async () => {
      if (ephemeral && !alive) {
        localStorage.removeItem(EPHEMERAL_KEY);
        await supabase.auth.signOut();
      }
      const { data } = await supabase.auth.getUser();
      if (!cancelled) await load(data.user ?? null);
    };
    void start();

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      // Run outside the auth callback to avoid deadlocking the client.
      setTimeout(() => {
        void load(session?.user ?? null);
        void router.invalidate();
        if (event !== "SIGNED_OUT") void queryClient.invalidateQueries();
      }, 0);
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, [load, router, queryClient]);

  // Save preference changes to the account.
  useEffect(() => {
    if (!user || !prefsReady || syncedPrefs.current === null || profile?.status !== "active") return;
    const json = JSON.stringify(prefs);
    if (json === syncedPrefs.current) return;
    const id = window.setTimeout(() => {
      syncedPrefs.current = json;
      void supabase.from("profiles").update({ preferences: prefs }).eq("id", user.id);
    }, 400);
    return () => clearTimeout(id);
  }, [prefs, user, prefsReady, profile?.status]);

  const refresh = useCallback(async () => {
    const { data } = await supabase.auth.getUser();
    await load(data.user ?? null);
  }, [load]);

  const value = useMemo<AuthCtx>(
    () => ({
      ready,
      user,
      profile,
      avatarUrl,
      isAdmin,
      termsOk: !!termsAcceptedAt,
      termsAcceptedAt,
      refresh,
    }),
    [ready, user, profile, avatarUrl, isAdmin, termsAcceptedAt, refresh],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

/** Sign-out in the safe order: stop queries, drop cache, end session. */
export function useSignOut() {
  const queryClient = useQueryClient();
  return useCallback(async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    localStorage.removeItem(EPHEMERAL_KEY);
    await supabase.auth.signOut();
  }, [queryClient]);
}
