import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { USERNAME_RE } from "./rewards";

export type UsernameSignInResult =
  | { ok: true; access_token: string; refresh_token: string }
  | { ok: false; error: "invalid" | "suspended" | "unconfirmed" | "rate_limited" };

/**
 * Signs in with a username instead of an email. The email lookup happens only on the
 * server and is never returned, so usernames can't be used to discover email addresses.
 */
export const signInWithUsername = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ username: z.string().trim().toLowerCase().max(20), password: z.string().min(1).max(200) }).parse(input),
  )
  .handler(async ({ data }): Promise<UsernameSignInResult> => {
    if (!USERNAME_RE.test(data.username)) return { ok: false, error: "invalid" };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .ilike("username", data.username)
      .maybeSingle();
    if (!profile) return { ok: false, error: "invalid" };
    const { data: userRes } = await supabaseAdmin.auth.admin.getUserById(profile.id);
    const email = userRes.user?.email;
    if (!email) return { ok: false, error: "invalid" };

    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const client = createClient<Database>(process.env["SUPABASE_URL"]!, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data: res, error } = await client.auth.signInWithPassword({ email, password: data.password });
    if (error || !res.session) {
      const msg = (error?.message ?? "").toLowerCase();
      const code = (error as { code?: string } | null)?.code ?? "";
      if (code === "user_banned" || msg.includes("banned")) return { ok: false, error: "suspended" };
      if (code === "email_not_confirmed" || msg.includes("not confirmed")) return { ok: false, error: "unconfirmed" };
      if (error?.status === 429) return { ok: false, error: "rate_limited" };
      return { ok: false, error: "invalid" };
    }
    return { ok: true, access_token: res.session.access_token, refresh_token: res.session.refresh_token };
  });

/** Checks the signed-in user's current password before it's changed. */
export const verifyCurrentPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ password: z.string().min(1).max(200) }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: userRes } = await context.supabase.auth.getUser();
    const email = userRes.user?.email;
    if (!email) return { ok: false };
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const client = createClient<Database>(process.env["SUPABASE_URL"]!, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data: res, error } = await client.auth.signInWithPassword({ email, password: data.password });
    if (res.session) await client.auth.signOut({ scope: "local" });
    return { ok: !error && !!res.session };
  });
