import { createOpenAI } from "@ai-sdk/openai";
import { streamText, type ModelMessage } from "ai";

const GATEWAY = "https://ai.gateway.lovable.dev/v1";
const MODEL = "openai/gpt-6-astra";

export class AiGatewayError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Streams one reply through Lovable AI and returns the final text. */
export async function generateReply(system: string, messages: ModelMessage[]) {
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) throw new AiGatewayError(401, "AI is not configured");
  let runId: string | undefined;
  const provider = createOpenAI({
    baseURL: GATEWAY,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const headers = new Headers(init?.headers);
      if (runId) headers.set("X-Lovable-AIG-Run-ID", runId);
      const res = await fetch(input, { ...init, headers });
      runId ??= res.headers.get("X-Lovable-AIG-Run-ID") ?? undefined;
      if (!res.ok) {
        let msg = "AI request failed";
        try {
          const body = (await res.clone().json()) as { message?: string; error?: { message?: string } };
          msg = body.message ?? body.error?.message ?? msg;
        } catch {}
        throw new AiGatewayError(res.status, msg);
      }
      return res;
    },
  });
  let failure: unknown;
  const result = streamText({
    model: provider.responses(MODEL),
    system,
    messages,
    maxRetries: 0,
    onError: ({ error }) => {
      failure = error;
    },
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  const text = (await result.text).trim();
  if (failure) throw failure;
  if (!text) throw new AiGatewayError(200, "Empty reply");
  return text;
}
