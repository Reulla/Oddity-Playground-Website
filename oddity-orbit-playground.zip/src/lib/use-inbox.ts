import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./auth";

export const inboxQueryKey = (userId: string | undefined) => ["inbox", userId] as const;

export function useInbox() {
  const { user } = useAuth();
  return useQuery({
    queryKey: inboxQueryKey(user?.id),
    enabled: !!user,
    refetchInterval: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inbox_messages")
        .select("id, kind, title, body, read_at, created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  });
}

