import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { EXPERIMENT_IDS, REWARD_KINDS, checkRewardItem, metricCount, totalScore, type AchievementMetric } from "./rewards";
import { TERMS_VERSION } from "./terms";
import { isTimedOut } from "./moderation";

type Unlock = { id: string; title_en: string; title_id: string; rarity: string; points: number };
export type RecordResult =
  | { ok: false; reason: "invalid" | "suspended" | "terms" }
  | { ok: true; points: number; newItems: string[]; achievements: Unlock[] };

const recordInput = z.object({
  kind: z.enum(REWARD_KINDS),
  itemIds: z.array(z.string().min(1).max(64)).min(1).max(40),
});

/** Awards points for things the signed-in user discovered. Each item only ever pays out once. */
export const recordProgress = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => recordInput.parse(input))
  .handler(async ({ data, context }): Promise<RecordResult> => {
    const { supabase, userId } = context;

    const [{ data: profile }, { data: acceptance }] = await Promise.all([
      supabase.from("profiles").select("status, timeout_until").eq("id", userId).maybeSingle(),
      supabase.from("terms_acceptances").select("id").eq("user_id", userId).eq("version", TERMS_VERSION).maybeSingle(),
    ]);
    if (!profile || profile.status !== "active" || isTimedOut(profile.timeout_until)) return { ok: false, reason: "suspended" };
    if (!acceptance) return { ok: false, reason: "terms" };

    const items = [...new Set(data.itemIds)];
    const valid: string[] = [];
    for (const id of items) {
      const check = checkRewardItem(data.kind, id);
      if (check === "ok") valid.push(id);
      else if (check === "custom") {
        const { data: entry } = await supabase.from("custom_oddities").select("id").eq("id", id).maybeSingle();
        if (entry) valid.push(id);
      }
    }
    if (valid.length === 0) return { ok: false, reason: "invalid" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let points = 0;
    const newItems: string[] = [];
    const achievements: Unlock[] = [];
    for (const id of valid) {
      const { data: res, error } = await supabaseAdmin.rpc("record_reward", {
        _user_id: userId,
        _kind: data.kind,
        _item_id: id,
      });
      if (error) {
        console.error("record_reward failed", error);
        continue;
      }
      const r = res as { new: boolean; points: number; achievements: Unlock[] };
      if (r.new) {
        points += r.points;
        newItems.push(id);
        achievements.push(...r.achievements);
      }
    }
    return { ok: true, points, newItems, achievements };
  });

/** Logs that a signed-in user opened an experiment (for the popularity chart). */
export const logPlay = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ experiment: z.enum(EXPERIMENT_IDS) }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("activity_events").insert({ user_id: context.userId, kind: "play", item_id: data.experiment });
    return { ok: true };
  });

export type MyStats = {
  joinedAt: string;
  totalScore: number;
  experiments: number;
  discoveries: number;
  eggs: number;
  unlockedCount: number;
  rules: { kind: string; points: number }[];
  achievements: {
    id: string;
    title_en: string;
    title_id: string;
    description_en: string;
    description_id: string;
    rarity: string;
    points: number;
    target: number;
    progress: number;
    unlockedAt: string | null;
  }[];
};

/** Score page data for the signed-in user. */
export const getMyStats = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MyStats> => {
    const { supabase, userId } = context;

    // Pick up achievements an admin added after the user already qualified.
    const { data: profileRow } = await supabase.from("profiles").select("status, created_at").eq("id", userId).maybeSingle();
    if (profileRow?.status === "active") {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.rpc("sync_achievements", { _user_id: userId });
    }

    const [rewardsRes, unlockedRes, achRes, rulesRes] = await Promise.all([
      supabase.from("user_rewards").select("kind, item_id, points").eq("user_id", userId),
      supabase.from("user_achievements").select("achievement_id, points, unlocked_at").eq("user_id", userId),
      supabase.from("achievements").select("*").order("sort"),
      supabase.from("score_rules").select("kind, points"),
    ]);
    const rewards = rewardsRes.data ?? [];
    const unlocked = unlockedRes.data ?? [];
    const unlockedMap = new Map(unlocked.map((u) => [u.achievement_id, u.unlocked_at]));

    const achievements = (achRes.data ?? [])
      .filter((a) => a.active || unlockedMap.has(a.id))
      .map((a) => ({
        id: a.id,
        title_en: a.title_en,
        title_id: a.title_id,
        description_en: a.description_en,
        description_id: a.description_id,
        rarity: a.rarity,
        points: a.points,
        target: a.target,
        progress: Math.min(a.target, metricCount(rewards, a.metric as AchievementMetric)),
        unlockedAt: unlockedMap.get(a.id) ?? null,
      }));

    return {
      joinedAt: profileRow?.created_at ?? new Date().toISOString(),
      totalScore: totalScore(rewards, unlocked),
      experiments: metricCount(rewards, "experiments"),
      discoveries: metricCount(rewards, "discoveries"),
      eggs: metricCount(rewards, "easter_eggs"),
      unlockedCount: unlocked.length,
      rules: rulesRes.data ?? [],
      achievements,
    };
  });
