import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  HON_MAX_MESSAGE_LENGTH,
  HON_MAX_MESSAGES,
  HON_MAX_MINUTES,
  HON_MIN_MINUTES,
  buildSystemPrompt,
  difficultyFor,
  pickPersona,
  type ChatLine,
  type Persona,
} from "./human-or-not";
import { isTimedOut } from "./moderation";
import { TERMS_VERSION } from "./terms";

type Ctx = { supabase: import("@supabase/supabase-js").SupabaseClient<import("@/integrations/supabase/types").Database>; userId: string };

async function canPlay(context: Ctx) {
  const [{ data: profile }, { data: terms }] = await Promise.all([
    context.supabase.from("profiles").select("status, timeout_until").eq("id", context.userId).maybeSingle(),
    context.supabase.from("terms_acceptances").select("id").eq("user_id", context.userId).eq("version", TERMS_VERSION).maybeSingle(),
  ]);
  if (!profile || profile.status !== "active") return "suspended" as const;
  if (isTimedOut(profile.timeout_until)) return "timeout" as const;
  if (!terms) return "terms" as const;
  return null;
}

export const startRound = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ minutes: z.number().int().min(HON_MIN_MINUTES).max(HON_MAX_MINUTES), lang: z.enum(["en", "id"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const blocked = await canPlay(context);
    if (blocked) return { ok: false as const, reason: blocked };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const deadline = new Date(Date.now() + data.minutes * 60_000).toISOString();
    const { data: row, error } = await supabaseAdmin
      .from("game_rounds")
      .insert({
        user_id: context.userId,
        persona: pickPersona(),
        lang: data.lang,
        minutes: data.minutes,
        difficulty: difficultyFor(data.minutes),
        deadline,
      })
      .select("id, deadline, difficulty")
      .single();
    if (error || !row) throw new Error("Could not start a round");
    await supabaseAdmin.from("activity_events").insert({ user_id: context.userId, kind: "play", item_id: "human" });
    return { ok: true as const, roundId: row.id, deadline: row.deadline, difficulty: row.difficulty };
  });

export const sendRoundMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ roundId: z.string().uuid(), text: z.string().trim().min(1).max(HON_MAX_MESSAGE_LENGTH) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: round } = await supabaseAdmin
      .from("game_rounds")
      .select("*")
      .eq("id", data.roundId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!round) return { ok: false as const, reason: "missing" as const };
    if (round.finished_at) return { ok: false as const, reason: "finished" as const };
    if (Date.now() > new Date(round.deadline).getTime() + 5_000) return { ok: false as const, reason: "time" as const };
    const history = (round.messages as unknown as ChatLine[]) ?? [];
    if (history.length >= HON_MAX_MESSAGES) return { ok: false as const, reason: "limit" as const };
    const mine: ChatLine = { from: "me", text: data.text, at: new Date().toISOString() };
    const next = [...history, mine];
    const { generateReply, AiGatewayError } = await import("./hon-ai.server");
    let reply: string;
    try {
      const seed = parseInt(round.id.slice(0, 6), 16);
      reply = await generateReply(
        buildSystemPrompt(round.persona as Persona, round.difficulty, round.lang as "en" | "id", seed),
        next.map((m) => ({ role: m.from === "me" ? ("user" as const) : ("assistant" as const), content: m.text })),
      );
    } catch (e) {
      const status = e instanceof AiGatewayError ? e.status : 500;
      console.error("Human Or Not reply failed", status, e);
      return { ok: false as const, reason: status === 402 || status === 403 ? ("credits" as const) : status === 429 ? ("busy" as const) : ("ai" as const) };
    }
    const theirs: ChatLine = { from: "them", text: reply.slice(0, 600), at: new Date().toISOString() };
    await supabaseAdmin.from("game_rounds").update({ messages: [...next, theirs] as never }).eq("id", round.id);
    return { ok: true as const, reply: theirs.text };
  });

export const submitGuess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ roundId: z.string().uuid(), guess: z.enum(["human", "ai"]) }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: round } = await supabaseAdmin
      .from("game_rounds")
      .select("id, persona, finished_at, guess, correct, difficulty")
      .eq("id", data.roundId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!round) throw new Error("Round not found");
    if (round.finished_at) {
      return { persona: round.persona as Persona, correct: !!round.correct, points: 0, achievements: [] as { title_en: string; title_id: string; points: number }[] };
    }
    const correct = round.persona === data.guess;
    await supabaseAdmin
      .from("game_rounds")
      .update({ guess: data.guess, correct, finished_at: new Date().toISOString() })
      .eq("id", round.id)
      .is("finished_at", null);
    await supabaseAdmin.from("activity_events").insert({ user_id: context.userId, kind: "game", item_id: correct ? "correct" : "wrong" });

    let points = 0;
    const achievements: { title_en: string; title_id: string; points: number }[] = [];
    if (!(await canPlay(context))) {
      const rewards: [string, string][] = [["experiment", "human"]];
      if (correct) rewards.push(["game", round.id]);
      for (const [kind, item] of rewards) {
        const { data: res } = await supabaseAdmin.rpc("record_reward", { _user_id: context.userId, _kind: kind, _item_id: item });
        const r = res as { new: boolean; points: number; achievements: { title_en: string; title_id: string; points: number }[] } | null;
        if (r?.new) {
          points += r.points;
          achievements.push(...r.achievements);
        }
      }
    }
    return { persona: round.persona as Persona, correct, points, achievements };
  });
