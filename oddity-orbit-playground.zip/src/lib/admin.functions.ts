import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { ACHIEVEMENT_METRICS, RARITIES, REWARD_KINDS } from "./rewards";
import { MOD_ACTIONS, moderationExpiry } from "./moderation";


/** Every admin endpoint starts here: verifies the caller's admin role on the server. */
async function adminClient(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const { data: isAdmin, error } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (error || !isAdmin) throw new Error("Forbidden: admin access required");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const audit = async (action: string, targetType: string | null, targetId: string | null, details: Record<string, unknown> = {}) => {
    await supabaseAdmin.from("admin_audit_log").insert({
      admin_id: context.userId,
      action,
      target_type: targetType,
      target_id: targetId,
      details: details as never,
    });
  };
  return { db: supabaseAdmin, audit };
}

export const adminCheck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    return { isAdmin: !!data };
  });

export type AdminStats = {
  total_users: number;
  suspended_users: number;
  active_24h: number;
  active_7d: number;
  active_30d: number;
  total_rewards: number;
  total_unlocks: number;
  events_7d: number;
  registrations_daily: { day: string; count: number }[];
  registrations_monthly: { month: string; count: number }[];
  active_daily: { day: string; count: number }[];
  active_monthly: { month: string; count: number }[];
  experiment_popularity: { item: string; count: number }[];
  achievement_stats: { id: string; title: string; rarity: string; count: number }[];
};

export const adminGetStats = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await adminClient(context);
    const { data, error } = await db.rpc("admin_stats");
    if (error) throw new Error("Could not load stats");
    return data as unknown as AdminStats;
  });

export type AdminUser = {
  id: string;
  email: string;
  username: string;
  display_name: string | null;
  status: string;
  created_at: string;
  last_seen_at: string | null;
  last_sign_in_at: string | null;
  is_admin: boolean;
  score: number;
};

export const adminListUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ search: z.string().trim().max(100).default(""), page: z.number().int().min(0).max(10000).default(0) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db } = await adminClient(context);
    const pageSize = 20;
    const { data: rows, error } = await db.rpc("admin_list_users", {
      _search: data.search,
      _limit: pageSize,
      _offset: data.page * pageSize,
    });
    if (error) throw new Error("Could not load users");
    const list = rows ?? [];
    return {
      users: list.map(({ total_count: _t, avatar_url: _a, ...u }) => u) as AdminUser[],
      total: Number(list[0]?.total_count ?? 0),
      pageSize,
    };
  });

export const adminSetUserStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ userId: z.string().uuid(), status: z.enum(["active", "suspended"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    if (data.userId === context.userId) throw new Error("You can't change your own status");
    const { error: banError } = await db.auth.admin.updateUserById(data.userId, {
      ban_duration: data.status === "suspended" ? "876000h" : "none",
    });
    if (banError) throw new Error("Could not update the account");
    const { error } = await db.from("profiles").update({ status: data.status }).eq("id", data.userId);
    if (error) throw new Error("Could not update the account");
    await audit(data.status === "suspended" ? "user.suspend" : "user.reactivate", "user", data.userId);
    return { ok: true };
  });

export const adminDeleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    if (data.userId === context.userId) throw new Error("You can't delete your own account here");
    const { data: profile } = await db.from("profiles").select("username").eq("id", data.userId).maybeSingle();
    const { data: files } = await db.storage.from("avatars").list(data.userId);
    if (files?.length) await db.storage.from("avatars").remove(files.map((f) => `${data.userId}/${f.name}`));
    await Promise.all([
      db.from("user_rewards").delete().eq("user_id", data.userId),
      db.from("user_achievements").delete().eq("user_id", data.userId),
      db.from("terms_acceptances").delete().eq("user_id", data.userId),
      db.from("daily_active").delete().eq("user_id", data.userId),
      db.from("activity_events").update({ user_id: null }).eq("user_id", data.userId),
    ]);
    const { error } = await db.auth.admin.deleteUser(data.userId);
    if (error) throw new Error("Could not delete the account");
    await audit("user.delete", "user", data.userId, { username: profile?.username ?? null });
    return { ok: true };
  });

// ----- Achievements & scoring -----

export const adminListAchievements = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await adminClient(context);
    const { data } = await db.from("achievements").select("*").order("sort");
    return data ?? [];
  });

const achievementSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]{2,40}$/),
  title_en: z.string().trim().min(1).max(60),
  title_id: z.string().trim().min(1).max(60),
  description_en: z.string().trim().min(1).max(200),
  description_id: z.string().trim().min(1).max(200),
  rarity: z.enum(RARITIES),
  metric: z.enum(ACHIEVEMENT_METRICS),
  target: z.number().int().min(1).max(10000),
  points: z.number().int().min(0).max(10000),
  active: z.boolean(),
  sort: z.number().int().min(0).max(1000).default(100),
});

export const adminSaveAchievement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => achievementSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    const { error } = await db.from("achievements").upsert(data);
    if (error) throw new Error("Could not save the achievement");
    await audit("achievement.save", "achievement", data.id, { points: data.points, target: data.target, active: data.active });
    return { ok: true };
  });

export const adminDeleteAchievement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().regex(/^[a-z0-9-]{2,40}$/) }).parse(input))
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    const { error } = await db.from("achievements").delete().eq("id", data.id);
    if (error) throw new Error("Could not delete the achievement");
    await audit("achievement.delete", "achievement", data.id);
    return { ok: true };
  });

export const adminListScoreRules = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await adminClient(context);
    const { data } = await db.from("score_rules").select("kind, points").order("kind");
    return data ?? [];
  });

export const adminSaveScoreRule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ kind: z.enum(REWARD_KINDS), points: z.number().int().min(0).max(10000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    const { error } = await db
      .from("score_rules")
      .update({ points: data.points, updated_at: new Date().toISOString() })
      .eq("kind", data.kind);
    if (error) throw new Error("Could not save the rule");
    await audit("score_rule.save", "score_rule", data.kind, { points: data.points });
    return { ok: true };
  });

// ----- Archive content -----

export const adminListOddities = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await adminClient(context);
    const { data } = await db.from("custom_oddities").select("*").order("created_at", { ascending: false });
    return data ?? [];
  });

const odditySchema = z.object({
  id: z.string().uuid().optional(),
  kind: z.enum(["fact", "mystery", "discovery"]),
  title_en: z.string().trim().min(1).max(80),
  title_id: z.string().trim().min(1).max(80),
  body_en: z.string().trim().min(1).max(400),
  body_id: z.string().trim().min(1).max(400),
  published: z.boolean(),
});

export const adminSaveOddity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => odditySchema.parse(input))
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    const { id, ...fields } = data;
    const res = id
      ? await db.from("custom_oddities").update(fields).eq("id", id).select("id").single()
      : await db.from("custom_oddities").insert({ ...fields, created_by: context.userId }).select("id").single();
    if (res.error) throw new Error("Could not save the entry");
    await audit(id ? "content.update" : "content.create", "oddity", res.data.id, { title: fields.title_en, published: fields.published });
    return { ok: true };
  });

export const adminDeleteOddity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    const { error } = await db.from("custom_oddities").delete().eq("id", data.id);
    if (error) throw new Error("Could not delete the entry");
    await audit("content.delete", "oddity", data.id);
    return { ok: true };
  });

// ----- Audit log -----

export const adminListAudit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await adminClient(context);
    const { data } = await db.from("admin_audit_log").select("*").order("created_at", { ascending: false }).limit(100);
    const rows = data ?? [];
    const ids = [...new Set(rows.map((r) => r.admin_id))];
    const { data: admins } = ids.length
      ? await db.from("profiles").select("id, username").in("id", ids)
      : { data: [] as { id: string; username: string }[] };
    const names = new Map((admins ?? []).map((a) => [a.id, a.username]));
    return rows.map((r) => ({
      id: r.id,
      created_at: r.created_at,
      admin: names.get(r.admin_id) ?? r.admin_id.slice(0, 8),
      action: r.action,
      target: [r.target_type, r.target_id].filter(Boolean).join(" · "),
      details: JSON.stringify(r.details ?? {}),
    }));
  });

// ----- Activity log, moderation, inbox -----

export const ACTIVITY_KINDS = ["visit", "play", "experiment", "oddity", "button_event", "easter_egg", "game", "profile", "terms"] as const;

export type ActivityRow = { id: number; created_at: string; user_id: string | null; username: string | null; kind: string; item_id: string | null };

async function withUsernames<T extends { user_id: string | null }>(db: SupabaseClient<Database>, rows: T[]) {
  const ids = [...new Set(rows.map((r) => r.user_id).filter((x): x is string => !!x))];
  const { data } = ids.length ? await db.from("profiles").select("id, username").in("id", ids) : { data: [] };
  const names = new Map((data ?? []).map((p) => [p.id, p.username]));
  return rows.map((r) => ({ ...r, username: r.user_id ? (names.get(r.user_id) ?? null) : null }));
}

export const adminListActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        username: z.string().trim().max(40).default(""),
        kind: z.enum(["all", ...ACTIVITY_KINDS]).default("all"),
        days: z.number().int().min(1).max(365).default(7),
        page: z.number().int().min(0).max(1000).default(0),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db } = await adminClient(context);
    const pageSize = 50;
    let q = db
      .from("activity_events")
      .select("id, created_at, user_id, kind, item_id")
      .gte("created_at", new Date(Date.now() - data.days * 86_400_000).toISOString())
      .order("created_at", { ascending: false })
      .range(data.page * pageSize, data.page * pageSize + pageSize);
    if (data.kind !== "all") q = q.eq("kind", data.kind);
    if (data.username) {
      const { data: matches } = await db.from("profiles").select("id").ilike("username", `%${data.username.replace(/[%_]/g, "")}%`).limit(50);
      const ids = (matches ?? []).map((m) => m.id);
      if (ids.length === 0) return { rows: [] as ActivityRow[], hasMore: false };
      q = q.in("user_id", ids);
    }
    const { data: rows, error } = await q;
    if (error) throw new Error("Could not load activity");
    const list = rows ?? [];
    return { rows: (await withUsernames(db, list.slice(0, pageSize))) as ActivityRow[], hasMore: list.length > pageSize };
  });

export const adminUserDetail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { db } = await adminClient(context);
    const [{ data: profile }, { data: actions }, { data: activity }, { data: isAdmin }] = await Promise.all([
      db.from("profiles").select("id, username, display_name, status, suspended_until, timeout_until, created_at, last_seen_at").eq("id", data.userId).maybeSingle(),
      db.from("moderation_actions").select("*").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(30),
      db.from("activity_events").select("id, created_at, user_id, kind, item_id").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(30),
      db.rpc("has_role", { _user_id: data.userId, _role: "admin" }),
    ]);
    if (!profile) throw new Error("User not found");
    const history = await (async () => {
      const rows = actions ?? [];
      const ids = [...new Set(rows.map((r) => r.admin_id))];
      const { data: admins } = ids.length ? await db.from("profiles").select("id, username").in("id", ids) : { data: [] };
      const names = new Map((admins ?? []).map((a) => [a.id, a.username]));
      return rows.map((r) => ({ ...r, admin: names.get(r.admin_id) ?? "—" }));
    })();
    return { profile, isAdmin: !!isAdmin, history, activity: activity ?? [] };
  });

const MOD_TEXT = {
  warning: { title: "Warning from ODD.LAB / Peringatan dari ODD.LAB" },
  timeout: { title: "You've been timed out / Kamu sedang di-timeout" },
  suspend: { title: "Account suspended / Akun ditangguhkan" },
  ban: { title: "Account banned / Akun diblokir" },
  lift: { title: "Restriction lifted / Pembatasan dicabut" },
} as const;

export const adminModerate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        action: z.enum(MOD_ACTIONS),
        amount: z.number().int().nullable().default(null),
        reason: z.string().trim().min(1).max(500),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    if (data.userId === context.userId) throw new Error("You can't moderate yourself");
    const { data: targetAdmin } = await db.rpc("has_role", { _user_id: data.userId, _role: "admin" });
    if (targetAdmin) throw new Error("Admins can't be moderated here");
    const expiry = moderationExpiry(data.action, data.amount);
    if (expiry === "invalid") throw new Error("Invalid duration");
    const until = expiry ? expiry.toISOString() : null;

    if (data.action === "timeout") {
      await db.from("profiles").update({ timeout_until: until }).eq("id", data.userId);
    } else if (data.action === "suspend" || data.action === "ban") {
      const hours = data.action === "ban" ? 876000 : Math.ceil((expiry!.getTime() - Date.now()) / 3_600_000);
      const { error: banError } = await db.auth.admin.updateUserById(data.userId, { ban_duration: `${hours}h` });
      if (banError) throw new Error("Could not update the account");
      await db
        .from("profiles")
        .update({ status: data.action === "ban" ? "banned" : "suspended", suspended_until: data.action === "ban" ? null : until })
        .eq("id", data.userId);
    } else if (data.action === "lift") {
      const { error: banError } = await db.auth.admin.updateUserById(data.userId, { ban_duration: "none" });
      if (banError) throw new Error("Could not update the account");
      await db.from("profiles").update({ status: "active", suspended_until: null, timeout_until: null }).eq("id", data.userId);
    }

    const { error } = await db.from("moderation_actions").insert({
      user_id: data.userId,
      admin_id: context.userId,
      action: data.action,
      reason: data.reason,
      expires_at: until,
    });
    if (error) throw new Error("Could not record the action");
    const ends = until ? `\n\nUntil / Sampai: ${until.replace("T", " ").slice(0, 16)} UTC` : data.action === "ban" ? "\n\nPermanent / Permanen" : "";
    await db.from("inbox_messages").insert({
      user_id: data.userId,
      sender_id: context.userId,
      kind: data.action === "warning" ? "warning" : "moderation",
      title: MOD_TEXT[data.action].title,
      body: `${data.reason}${ends}`.slice(0, 2000),
    });
    await audit(`user.${data.action}`, "user", data.userId, { reason: data.reason, until });
    return { ok: true };
  });

export const adminSendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        to: z.union([z.literal("all"), z.string().trim().min(3).max(40)]),
        title: z.string().trim().min(1).max(120),
        body: z.string().trim().min(1).max(2000),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { db, audit } = await adminClient(context);
    let ids: string[];
    if (data.to === "all") {
      const { data: all } = await db.from("profiles").select("id").limit(10000);
      ids = (all ?? []).map((p) => p.id);
    } else {
      const { data: one } = await db.from("profiles").select("id").eq("username", data.to.toLowerCase()).maybeSingle();
      if (!one) return { ok: false as const, reason: "notFound" as const };
      ids = [one.id];
    }
    for (let i = 0; i < ids.length; i += 500) {
      const { error } = await db.from("inbox_messages").insert(
        ids.slice(i, i + 500).map((id) => ({ user_id: id, sender_id: context.userId, kind: "info", title: data.title, body: data.body })),
      );
      if (error) throw new Error("Could not send the message");
    }
    await audit("inbox.send", "inbox", data.to, { title: data.title, recipients: ids.length });
    return { ok: true as const, count: ids.length };
  });
