import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { en, type MessageKey } from "./i18n/en";
import { id } from "./i18n/id";

export const LANGS = ["en", "id"] as const;
export const THEMES = ["light", "dark"] as const;
export const TEXT_SIZES = ["sm", "md", "lg", "xl"] as const;
export type Lang = (typeof LANGS)[number];
export type Theme = (typeof THEMES)[number];
export type TextSize = (typeof TEXT_SIZES)[number];
export type Prefs = { lang: Lang; theme: Theme; textSize: TextSize };

export const DEFAULT_PREFS: Prefs = { lang: "en", theme: "light", textSize: "md" };
export const PREFS_KEY = "oddlab-prefs-v1";

/** Turns anything (stored JSON, account data) into valid preferences, falling back to defaults. */
export function parsePrefs(raw: unknown): Prefs {
  const o = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    lang: LANGS.includes(o["lang"] as Lang) ? (o["lang"] as Lang) : DEFAULT_PREFS.lang,
    theme: THEMES.includes(o["theme"] as Theme) ? (o["theme"] as Theme) : DEFAULT_PREFS.theme,
    textSize: TEXT_SIZES.includes(o["textSize"] as TextSize) ? (o["textSize"] as TextSize) : DEFAULT_PREFS.textSize,
  };
}

const DICTS: Record<Lang, Record<MessageKey, string>> = { en, id };

export function translate(lang: Lang, key: MessageKey, vars?: Record<string, string | number>) {
  let s = DICTS[lang][key] ?? en[key];
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
  return s;
}

/** Runs before paint (inline in <head>) so dark mode and text size never flash. */
export const PREFS_BOOT_SCRIPT = `(function(){try{var p=JSON.parse(localStorage.getItem('${PREFS_KEY}')||'{}');var d=document.documentElement;if(p.theme==='dark')d.classList.add('dark');if(p.textSize==='sm'||p.textSize==='lg'||p.textSize==='xl')d.setAttribute('data-text-size',p.textSize);if(p.lang==='id')d.lang='id';}catch(e){}})();`;

function applyToDocument(p: Prefs) {
  const d = document.documentElement;
  d.classList.toggle("dark", p.theme === "dark");
  if (p.textSize === "md") d.removeAttribute("data-text-size");
  else d.setAttribute("data-text-size", p.textSize);
  d.lang = p.lang;
}

type Ctx = {
  prefs: Prefs;
  ready: boolean;
  setPrefs: (patch: Partial<Prefs>) => void;
  t: (key: MessageKey, vars?: Record<string, string | number>) => string;
};

const PrefsContext = createContext<Ctx | null>(null);

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [prefs, setState] = useState<Prefs>(DEFAULT_PREFS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      setState(parsePrefs(JSON.parse(localStorage.getItem(PREFS_KEY) ?? "{}")));
    } catch {
      /* broken storage: keep defaults */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    applyToDocument(prefs);
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  }, [prefs, ready]);

  const setPrefs = useCallback((patch: Partial<Prefs>) => {
    setState((p) => parsePrefs({ ...p, ...patch }));
  }, []);

  const t = useCallback(
    (key: MessageKey, vars?: Record<string, string | number>) => translate(prefs.lang, key, vars),
    [prefs.lang],
  );

  const value = useMemo(() => ({ prefs, ready, setPrefs, t }), [prefs, ready, setPrefs, t]);
  return <PrefsContext.Provider value={value}>{children}</PrefsContext.Provider>;
}

export function usePreferences() {
  const ctx = useContext(PrefsContext);
  if (!ctx) throw new Error("usePreferences must be used inside PreferencesProvider");
  return ctx;
}

const fallbackT = (key: MessageKey, vars?: Record<string, string | number>) => translate("en", key, vars);

/** Translator for the current language (falls back to English outside the provider). */
export function useT() {
  return useContext(PrefsContext)?.t ?? fallbackT;
}

export function useLang(): Lang {
  return useContext(PrefsContext)?.prefs.lang ?? "en";
}

/** Formats a date for the current language. */
export function formatDate(lang: Lang, value: string | Date | null | undefined, withTime = false) {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleDateString(lang === "id" ? "id-ID" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  });
}
