import type { ButtonEvent } from "../button-events";
import type { Oddity, OddityKind } from "../oddities";
import type { Lang } from "../preferences";
import { translate } from "../preferences";
import { ID_BUTTON_EVENTS, ID_EXPERIMENTS, ID_MILESTONES, ID_ODDITIES } from "./content-id";

export function experimentText(lang: Lang, e: { id: string; title: string; blurb: string; tag: string }) {
  if (lang === "id" && ID_EXPERIMENTS[e.id]) return ID_EXPERIMENTS[e.id]!;
  return { title: e.title, blurb: e.blurb, tag: e.tag };
}

export function buttonEventText(lang: Lang, ev: ButtonEvent) {
  if (lang !== "id") return ev.text;
  const milestone = /^milestone-(\d+)$/.exec(ev.id);
  if (milestone) return ID_MILESTONES[Number(milestone[1])] ?? ev.text;
  return ID_BUTTON_EVENTS[ev.id] ?? ev.text;
}

/** Archive entries may carry their own Indonesian text (admin-added entries). */
export type ArchiveEntry = Oddity & { key: string; rewardId: string; custom?: boolean; titleId?: string; bodyId?: string };

export function oddityText(lang: Lang, o: Oddity | ArchiveEntry) {
  if (lang !== "id") return { title: o.title, body: o.body };
  if ("custom" in o && o.custom) return { title: o.titleId ?? o.title, body: o.bodyId ?? o.body };
  return ID_ODDITIES[o.id] ?? { title: o.title, body: o.body };
}

export function kindLabel(lang: Lang, kind: OddityKind) {
  return translate(lang, `odd.kind.${kind}`);
}
