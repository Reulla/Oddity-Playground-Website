import { linkOptions } from "@tanstack/react-router";
import { Atom, Bot, Circle, MousePointerClick, Orbit, Palette, Shuffle } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Tone } from "./tones";

export const LAB_EXPERIMENTS = ["particles", "gravity", "art"] as const;
export type LabExperiment = (typeof LAB_EXPERIMENTS)[number];

export type Experiment = {
  id: string;
  no: string;
  title: string;
  blurb: string;
  tag: string;
  tone: Tone;
  icon: LucideIcon;
  /** Typed navigation options, built with linkOptions(). */
  link: unknown;
};

export const experiments = [
  {
    id: "particles",
    no: "01",
    title: "Particle Swarm",
    blurb: "Hundreds of tiny dots with strong opinions about your cursor.",
    tag: "Chaos Lab",
    tone: "coral",
    icon: Atom,
    link: linkOptions({ to: "/lab", search: { exp: "particles" } }),
  },
  {
    id: "gravity",
    no: "02",
    title: "Gravity Box",
    blurb: "Drop, fling and flip planets in a very small universe.",
    tag: "Chaos Lab",
    tone: "sky",
    icon: Orbit,
    link: linkOptions({ to: "/lab", search: { exp: "gravity" } }),
  },
  {
    id: "art",
    no: "03",
    title: "Specimen Generator",
    blurb: "A machine that paints a never-before-seen picture on every press.",
    tag: "Chaos Lab",
    tone: "mint",
    icon: Palette,
    link: linkOptions({ to: "/lab", search: { exp: "art" } }),
  },
  {
    id: "button",
    no: "04",
    title: "The Button",
    blurb: "It's a button. Something happens. Nobody knows what.",
    tag: "Toy",
    tone: "sun",
    icon: MousePointerClick,
    link: linkOptions({ to: "/button" }),
  },
  {
    id: "archive",
    no: "05",
    title: "Oddities Archive",
    blurb: "Strange facts, invented mysteries and very real weird discoveries.",
    tag: "Archive",
    tone: "lime",
    icon: Circle,
    link: linkOptions({ to: "/oddities" }),
  },
  {
    id: "discover",
    no: "06",
    title: "Random Discovery",
    blurb: "Pull one oddity out of the archive, sight unseen.",
    tag: "Archive",
    tone: "coral",
    icon: Shuffle,
    link: linkOptions({ to: "/oddities", search: { discover: true } }),
  },
  {
    id: "human",
    no: "07",
    title: "Human Or Not?",
    blurb: "Chat with a stranger against the clock, then decide: person or machine?",
    tag: "Game",
    tone: "sky",
    icon: Bot,
    link: linkOptions({ to: "/human-or-not" }),
  },
] satisfies Experiment[];

export function pickRandomExperiment(exceptId?: string, rand: () => number = Math.random) {
  const pool = experiments.filter((e) => e.id !== exceptId);
  return pool[Math.floor(rand() * pool.length)] ?? experiments[0];
}
