/** Reads design-token colors so canvas drawings follow the design system. */
export function readPalette() {
  const s = getComputedStyle(document.documentElement);
  const g = (name: string) => s.getPropertyValue(name).trim();
  return {
    accents: [g("--coral"), g("--mint"), g("--sky"), g("--sun"), g("--lime")],
    ink: g("--foreground"),
    card: g("--card"),
    muted: g("--muted-foreground"),
    border: g("--border"),
  };
}

/** Keeps a canvas sharp at its CSS size. Returns a cleanup function. */
export function fitCanvas(
  canvas: HTMLCanvasElement,
  onSize: (w: number, h: number) => void,
): () => void {
  const ctx = canvas.getContext("2d");
  let sized = false;
  const resize = () => {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(rect.width * dpr));
    const h = Math.max(1, Math.round(rect.height * dpr));
    // Resizing a canvas wipes it, so skip when nothing changed (keeps still drawings visible)
    if (canvas.width === w && canvas.height === h && sized) return;
    sized = true;
    canvas.width = w;
    canvas.height = h;
    ctx?.setTransform(dpr, 0, 0, dpr, 0, 0);
    onSize(rect.width, rect.height);
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(canvas);
  return () => ro.disconnect();
}

/** Small seeded random number generator (mulberry32). */
export function seeded(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
