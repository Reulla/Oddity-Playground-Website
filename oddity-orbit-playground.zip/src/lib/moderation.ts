export const MOD_ACTIONS = ["warning", "timeout", "suspend", "ban", "lift"] as const;
export type ModAction = (typeof MOD_ACTIONS)[number];

/** Allowed lengths: timeouts 10 minutes – 7 days, suspensions 1 day – 365 days. Bans never end. */
export const TIMEOUT_MINUTES = { min: 10, max: 7 * 24 * 60 };
export const SUSPEND_DAYS = { min: 1, max: 365 };

/** Returns the end time for an action, null for actions that never expire, or "invalid". */
export function moderationExpiry(action: ModAction, amount: number | null | undefined, now = new Date()): Date | null | "invalid" {
  if (action === "ban" || action === "warning" || action === "lift") return null;
  const n = Number(amount);
  if (!Number.isInteger(n)) return "invalid";
  if (action === "timeout") {
    if (n < TIMEOUT_MINUTES.min || n > TIMEOUT_MINUTES.max) return "invalid";
    return new Date(now.getTime() + n * 60_000);
  }
  if (n < SUSPEND_DAYS.min || n > SUSPEND_DAYS.max) return "invalid";
  return new Date(now.getTime() + n * 86_400_000);
}

export function isTimedOut(timeoutUntil: string | null | undefined, now = Date.now()) {
  return !!timeoutUntil && new Date(timeoutUntil).getTime() > now;
}
