import { useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { useAuth } from "./auth";
import { useLang, useT } from "./preferences";
import { logPlay, recordProgress } from "./progress.functions";
import type { ExperimentId, RewardKind } from "./rewards";

// Items already sent this page session, per user, so repeat actions don't call the server again.
const sent = new Map<string, Set<string>>();
const guestEggs = new Set<string>();

export function useRewards() {
  const { user, termsOk, profile } = useAuth();
  const t = useT();
  const lang = useLang();
  const record = useServerFn(recordProgress);
  const play = useServerFn(logPlay);
  const queryClient = useQueryClient();

  const award = useCallback(
    async (kind: RewardKind, ids: string | string[], label?: string) => {
      const list = Array.isArray(ids) ? ids : [ids];
      if (!user) {
        if (kind === "easter_egg") {
          for (const id of list) {
            if (guestEggs.has(id)) continue;
            guestEggs.add(id);
            toast(t("toast.egg"), { description: t("toast.eggGuest") });
          }
        }
        return;
      }
      if (!termsOk || profile?.status !== "active") return;
      const mine = sent.get(user.id) ?? new Set<string>();
      sent.set(user.id, mine);
      const fresh = list.filter((id) => !mine.has(`${kind}:${id}`));
      if (fresh.length === 0) return;
      fresh.forEach((id) => mine.add(`${kind}:${id}`));
      try {
        const res = await record({ data: { kind, itemIds: fresh } });
        if (!res.ok) {
          if (res.reason === "terms") toast(t("terms.needed"));
          return;
        }
        if (res.points > 0) {
          const pts = t("toast.points", { n: res.points });
          if (kind === "easter_egg") toast.success(t("toast.egg"), { description: pts });
          else if (kind === "experiment") toast.success(t("toast.expComplete", { title: label ?? "" }), { description: pts });
          else toast(pts, { duration: 1800 });
        }
        for (const a of res.achievements) {
          toast.success(t("toast.achievement", { title: lang === "id" ? a.title_id : a.title_en }), {
            description: t("toast.points", { n: a.points }),
          });
        }
        if (res.newItems.length) void queryClient.invalidateQueries({ queryKey: ["my-stats"] });
      } catch {
        fresh.forEach((id) => mine.delete(`${kind}:${id}`));
      }
    },
    [user, termsOk, profile?.status, record, t, lang, queryClient],
  );

  const logExperiment = useCallback(
    (experiment: ExperimentId) => {
      if (user) void play({ data: { experiment } }).catch(() => {});
    },
    [user, play],
  );

  return { award, logExperiment, signedIn: !!user };
}
