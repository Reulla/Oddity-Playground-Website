import { BUTTON_EVENTS, GOLDEN_EVENT } from "./button-events";
import { oddities } from "./oddities";

export const REWARD_KINDS = ["experiment", "oddity", "button_event", "easter_egg"] as const;
export type RewardKind = (typeof REWARD_KINDS)[number];

/** Experiments that can be "completed" for points. */
export const EXPERIMENT_IDS = ["particles", "gravity", "art", "button", "human"] as const;
export type ExperimentId = (typeof EXPERIMENT_IDS)[number];

/** Hidden interactions (easter eggs). */
export const EASTER_EGGS = [
  "golden-click", // The Golden Click on The Button
  "lights-out", // the blackout event on The Button
  "konami", // ↑↑↓↓←→←→BA anywhere
  "logo-spinner", // click the logo 5 times quickly
  "anti-gravity", // gravity slider all the way up
  "crowd-control", // maximum particles
] as const;
export type EasterEgg = (typeof EASTER_EGGS)[number];

/** What counts as "completing" each experiment. */
export const GOALS = {
  gravityPlanets: 10,
  artSpecimens: 5,
  buttonClicks: 25,
  particleModes: ["attract", "repel", "orbit"] as const,
};

export const ACHIEVEMENT_METRICS = ["any", "experiments", "oddities", "button_events", "easter_eggs", "discoveries", "games"] as const;
export type AchievementMetric = (typeof ACHIEVEMENT_METRICS)[number];
export const RARITIES = ["common", "uncommon", "rare", "epic", "legendary"] as const;
export type Rarity = (typeof RARITIES)[number];

const BUTTON_IDS = new Set([...BUTTON_EVENTS.map((e) => e.id), GOLDEN_EVENT.id]);
const ODDITY_IDS = new Set(oddities.map((o) => String(o.id)));
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Checks a reward request against the built-in content.
 * Returns "custom" for an admin-added archive entry id, which the server must look up.
 */
export function checkRewardItem(kind: RewardKind, itemId: string): "ok" | "custom" | "invalid" {
  switch (kind) {
    case "experiment":
      return (EXPERIMENT_IDS as readonly string[]).includes(itemId) ? "ok" : "invalid";
    case "easter_egg":
      return (EASTER_EGGS as readonly string[]).includes(itemId) ? "ok" : "invalid";
    case "button_event":
      return BUTTON_IDS.has(itemId) ? "ok" : "invalid";
    case "oddity":
      if (ODDITY_IDS.has(itemId)) return "ok";
      return UUID.test(itemId) ? "custom" : "invalid";
    default:
      return "invalid";
  }
}

/** Same counting rule as public.metric_count() in the database. */
export function metricCount(rewards: { kind: string }[], metric: AchievementMetric) {
  return rewards.filter((r) => {
    switch (metric) {
      case "any":
        return true;
      case "experiments":
        return r.kind === "experiment";
      case "oddities":
        return r.kind === "oddity";
      case "button_events":
        return r.kind === "button_event";
      case "easter_eggs":
        return r.kind === "easter_egg";
      case "discoveries":
        return r.kind === "oddity" || r.kind === "button_event";
      case "games":
        return r.kind === "game";
    }
  }).length;
}

/** Total score = points from every reward + points from every unlocked achievement. */
export function totalScore(rewards: { points: number }[], unlocked: { points: number }[]) {
  return [...rewards, ...unlocked].reduce((sum, r) => sum + r.points, 0);
}

/** Particle Swarm is complete once all three modes have been tried. */
export function particlesComplete(modesTried: Iterable<string>) {
  const tried = new Set(modesTried);
  return GOALS.particleModes.every((m) => tried.has(m));
}

export const USERNAME_RE = /^[a-z0-9_]{3,20}$/;
/** At least 8 characters with a letter and a number. */
export function isStrongPassword(pw: string) {
  return pw.length >= 8 && pw.length <= 72 && /[a-zA-Z]/.test(pw) && /\d/.test(pw);
}
