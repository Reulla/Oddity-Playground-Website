/** Sign-up form details kept in memory (never stored) between the form and the Terms step. */
export type PendingSignup = { username: string; email: string; password: string };

let pending: PendingSignup | null = null;
let returnError: { field: "username" | "email"; key: "err.usernameTaken" | "err.emailTaken" } | null = null;

export const signupStore = {
  get: () => pending,
  set: (p: PendingSignup) => {
    pending = p;
  },
  clear: () => {
    pending = null;
  },
  setError: (e: typeof returnError) => {
    returnError = e;
  },
  takeError: () => {
    const e = returnError;
    returnError = null;
    return e;
  },
};
