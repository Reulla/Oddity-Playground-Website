import type { Tone } from "./tones";

export type ButtonAnim = "wobble" | "spin" | "jelly" | "pop" | "flip" | "shake" | "none";
export type ButtonEffect = "confetti" | "runaway" | "tiny" | "giant" | "upside" | "blackout" | "none";

export type ButtonEvent = {
  id: string;
  text: string;
  tone: Tone;
  anim: ButtonAnim;
  effect: ButtonEffect;
};

export const BUTTON_EVENTS: ButtonEvent[] = [
  { id: "nothing", text: "Nothing happened. Suspicious.", tone: "sky", anim: "none", effect: "none" },
  { id: "unlock", text: "You've unlocked: absolutely nothing.", tone: "mint", anim: "pop", effect: "none" },
  { id: "pigeon", text: "Somewhere, a pigeon nodded at you.", tone: "lime", anim: "wobble", effect: "none" },
  { id: "enjoyed", text: "The button enjoyed that.", tone: "coral", anim: "jelly", effect: "none" },
  { id: "ouch", text: "Ouch.", tone: "coral", anim: "shake", effect: "none" },
  { id: "stop", text: "Please stop. (Don't stop.)", tone: "sun", anim: "wobble", effect: "none" },
  { id: "confetti", text: "Mandatory celebration!", tone: "sun", anim: "pop", effect: "confetti" },
  { id: "shy", text: "The button got shy and moved.", tone: "mint", anim: "none", effect: "runaway" },
  { id: "upside", text: "Gravity has been reversed. Briefly.", tone: "sky", anim: "flip", effect: "upside" },
  { id: "giant", text: "Big button energy.", tone: "lime", anim: "pop", effect: "giant" },
  { id: "tiny", text: "Tiny button mode activated.", tone: "coral", anim: "pop", effect: "tiny" },
  { id: "sock", text: "A sock just went missing. Sorry.", tone: "sky", anim: "wobble", effect: "none" },
  { id: "better", text: "That click was 4% better than average.", tone: "mint", anim: "jelly", effect: "none" },
  { id: "achievement", text: "Achievement: Pressed a button.", tone: "sun", anim: "pop", effect: "confetti" },
  { id: "warm", text: "The button is now slightly warmer.", tone: "coral", anim: "jelly", effect: "none" },
  { id: "buffering", text: "Reality is buffering…", tone: "sky", anim: "spin", effect: "none" },
  { id: "fortune", text: "Your fortune: you will click again.", tone: "lime", anim: "wobble", effect: "none" },
  { id: "complaint", text: "The button has filed a complaint.", tone: "coral", anim: "shake", effect: "none" },
  { id: "archive", text: "Your click has been added to the archive.", tone: "mint", anim: "pop", effect: "none" },
  { id: "lights", text: "Who turned off the lights?", tone: "sun", anim: "none", effect: "blackout" },
  { id: "applause", text: "Applause from an invisible audience.", tone: "lime", anim: "jelly", effect: "confetti" },
  { id: "tickle", text: "Hehe. That tickled.", tone: "sun", anim: "wobble", effect: "none" },
  { id: "name", text: "The button is learning your name.", tone: "sky", anim: "none", effect: "none" },
  { id: "spin", text: "Spin cycle activated.", tone: "mint", anim: "spin", effect: "none" },
  { id: "teapot", text: "Error 418: I'm a teapot.", tone: "coral", anim: "shake", effect: "none" },
  { id: "cloud", text: "A cloud changed shape because of you.", tone: "sky", anim: "jelly", effect: "none" },
  { id: "flip", text: "Do a flip! (The button did a flip.)", tone: "lime", anim: "flip", effect: "none" },
  { id: "escape", text: "The button tried to escape.", tone: "sun", anim: "shake", effect: "runaway" },
];

export const GOLDEN_EVENT: ButtonEvent = {
  id: "golden",
  text: "LEGENDARY — The Golden Click. 1 in 100.",
  tone: "sun",
  anim: "spin",
  effect: "confetti",
};

export const MILESTONES: Record<number, string> = {
  10: "10 clicks. The button respects you now.",
  25: "25 clicks. You are officially a regular.",
  50: "50 clicks. The button is writing a song about you.",
  100: "100 clicks! A small statue has been ordered.",
  250: "250 clicks. Have you considered a hobby? (This is the hobby.)",
  500: "500 clicks. The button is speechless.",
  1000: "1,000 clicks. You have become the button.",
};

export const TOTAL_EVENTS = BUTTON_EVENTS.length + 1;

/**
 * Picks what happens on a click.
 * - Milestone click counts always show their milestone message (with confetti).
 * - 1% of other clicks are the Golden Click.
 * - Otherwise a random event, never the same one twice in a row.
 */
export function pickButtonEvent(
  clickNumber: number,
  previousId: string | undefined,
  rand: () => number = Math.random,
): ButtonEvent {
  const milestone = MILESTONES[clickNumber];
  if (milestone) {
    return { id: `milestone-${clickNumber}`, text: milestone, tone: "sun", anim: "pop", effect: "confetti" };
  }
  if (rand() < 0.01) return GOLDEN_EVENT;
  const pool = BUTTON_EVENTS.filter((e) => e.id !== previousId);
  return pool[Math.floor(rand() * pool.length)] ?? BUTTON_EVENTS[0]!;
}
