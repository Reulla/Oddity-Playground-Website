export type OddityKind = "fact" | "mystery" | "discovery";

export type Oddity = {
  id: number;
  kind: OddityKind;
  title: string;
  body: string;
};

export const KIND_LABEL: Record<OddityKind, string> = {
  fact: "Strange fact",
  mystery: "Fictional mystery",
  discovery: "Odd discovery",
};

const raw: Omit<Oddity, "id">[] = [
  { kind: "fact", title: "Cube-shaped droppings", body: "Wombats are the only known animals that produce cube-shaped poop. The shape helps it stay put on rocks, where wombats use it to mark territory." },
  { kind: "mystery", title: "The Tuesday Library", body: "The public library of Wenmouth loses exactly one book every Tuesday. It is always returned years later, slightly heavier, with a pressed flower nobody can identify." },
  { kind: "discovery", title: "The Antikythera mechanism", body: "Divers off a Greek island in 1901 recovered a corroded lump of bronze gears. It turned out to be a 2,000-year-old device for predicting eclipses and planetary positions." },
  { kind: "fact", title: "Three hearts, blue blood", body: "Octopuses have three hearts and copper-based blue blood. Two hearts pump blood through the gills, one pumps it to the rest of the body." },
  { kind: "fact", title: "A long day on Venus", body: "Venus spins so slowly that a single day there (about 243 Earth days) is longer than its year (about 225 Earth days)." },
  { kind: "mystery", title: "The Lighthouse of Vell", body: "A lighthouse on the cliffs of Vell shines brightly, but only at noon. Ships that follow it arrive one day earlier than they left." },
  { kind: "discovery", title: "The Voynich manuscript", body: "A 15th-century book filled with an unknown script and drawings of plants that don't seem to exist. Over a century of codebreakers have failed to read a single word." },
  { kind: "fact", title: "Bananas are berries", body: "Botanically, bananas, grapes and even avocados count as berries. Strawberries and raspberries do not." },
  { kind: "fact", title: "Older than trees", body: "Sharks have been around for roughly 450 million years. The first trees appeared about 385 million years ago." },
  { kind: "mystery", title: "Hollow Creek Time", body: "Every clock in Hollow Creek runs seven minutes slow — including phones, sundials and the residents' heartbeats. Visitors adjust within a week." },
  { kind: "discovery", title: "The Tully monster", body: "A 300-million-year-old fossil from Illinois with eyes on a bar and a claw on a long snout. Scientists still argue about whether it was a fish, a worm or something else." },
  { kind: "fact", title: "Older than the Aztecs", body: "Teaching at Oxford University began around 1096. The Aztec city of Tenochtitlan was founded in 1325." },
  { kind: "fact", title: "Cleopatra and the Moon", body: "Cleopatra lived closer in time to the Moon landing than to the building of the Great Pyramid of Giza." },
  { kind: "mystery", title: "The colour Murn", body: "In 1803 a painter in Lisbon described a colour called murn, \"the shade of a sound remembered.\" Seven people have seen it since. None can paint it." },
  { kind: "discovery", title: "Immortal jellyfish", body: "Turritopsis dohrnii can turn back into its juvenile polyp stage when stressed, essentially restarting its life cycle." },
  { kind: "fact", title: "The national unicorn", body: "Scotland's official national animal is the unicorn, chosen for its symbolism of purity and power." },
  { kind: "fact", title: "A flamboyance", body: "A group of flamingos is called a flamboyance." },
  { kind: "mystery", title: "The extra step", body: "The old staircase in Pell House has thirteen steps by day and fourteen by night. Nobody who has stood on the fourteenth remembers it." },
  { kind: "discovery", title: "Tardigrades in space", body: "In 2007, microscopic tardigrades were exposed to the vacuum of space on a satellite mission. Many survived and later had healthy offspring." },
  { kind: "fact", title: "Chess is enormous", body: "There are estimated to be more possible games of chess than atoms in the observable universe." },
  { kind: "fact", title: "Tasting with feet", body: "Butterflies have taste receptors on their feet, which helps them find the right plants to lay eggs on." },
  { kind: "mystery", title: "The polite fog", body: "On autumn mornings a fog rolls over the village of Brennick. Those walking through it report hearing it whisper \"sorry\" as it passes." },
  { kind: "discovery", title: "Milky seas", body: "Sailors have described oceans glowing white for miles at night. Satellites have since photographed these bioluminescent 'milky seas' from space." },
  { kind: "fact", title: "A can for eternity", body: "Fredric Baur, who designed the Pringles can, asked for some of his ashes to be buried in one. His family obliged." },
  { kind: "fact", title: "Summer growth spurt", body: "The Eiffel Tower gets a few centimetres taller in summer, as its iron expands in the heat." },
  { kind: "mystery", title: "Platform 0", body: "A vending machine at a station that no longer exists sells tomorrow's newspaper for one coin. It only accepts coins that haven't been minted yet." },
  { kind: "discovery", title: "Glass frogs vanish", body: "Sleeping glass frogs can hide almost all of their red blood cells inside their liver, making their bodies nearly transparent." },
  { kind: "fact", title: "Breath holders", body: "Sloths can slow their heart rate and hold their breath for up to 40 minutes underwater." },
  { kind: "mystery", title: "The seventh moon", body: "The notebooks of astronomer Ida Venn describe a seventh moon visible only on Thursdays, which she named Later." },
  { kind: "discovery", title: "Booming dunes", body: "Some desert sand dunes produce a deep, steady hum when sand avalanches down their slopes — a sound that can last for minutes." },
];

export const oddities: Oddity[] = raw.map((o, i) => ({ ...o, id: i + 1 }));

export function pickRandomOddity(
  pool: Oddity[],
  exceptId?: number,
  rand: () => number = Math.random,
): Oddity | undefined {
  const options = pool.length > 1 ? pool.filter((o) => o.id !== exceptId) : pool;
  if (options.length === 0) return undefined;
  return options[Math.floor(rand() * options.length)];
}
