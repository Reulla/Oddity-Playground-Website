import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Dices } from "lucide-react";
import { experiments, pickRandomExperiment } from "@/lib/experiments";
import { toneSoft } from "@/lib/tones";
import { useLang, useT } from "@/lib/preferences";
import { experimentText } from "@/lib/i18n/content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ODD.LAB — strange experiments for curious people" },
      {
        name: "description",
        content:
          "An interactive playground of particle swarms, tiny universes, a mysterious button and an archive of oddities.",
      },
      { property: "og:title", content: "ODD.LAB — strange experiments for curious people" },
      {
        property: "og:description",
        content: "Particle swarms, tiny universes, a mysterious button and an archive of oddities.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function RandomExperimentButton() {
  const navigate = useNavigate();
  const t = useT();
  const lang = useLang();
  const [rolling, setRolling] = useState<string | null>(null);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach((t) => clearTimeout(t)), []);

  const roll = () => {
    if (rolling) return;
    const target = pickRandomExperiment();
    if (!target) return;
    let i = 0;
    const flicker = () => {
      setRolling((() => { const e = experiments[i % experiments.length]; return e ? experimentText(lang, e).title : null; })());
      i++;
    };
    flicker();
    const iv = window.setInterval(flicker, 70);
    timers.current.push(
      window.setTimeout(() => {
        clearInterval(iv);
        setRolling(experimentText(lang, target).title);
      }, 650),
      window.setTimeout(() => {
        navigate(target.link as Parameters<typeof navigate>[0]);
      }, 950),
    );
    timers.current.push(iv);
  };

  return (
    <button
      type="button"
      onClick={roll}
      className="group inline-flex h-12 items-center gap-3 rounded-full bg-primary pl-5 pr-6 text-primary-foreground shadow-lift transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]"
    >
      <Dices className="size-5 transition-transform duration-500 group-hover:rotate-180" />
      <span className="min-w-[11.5rem] text-left font-medium">
        {rolling ?? t("home.random")}
      </span>
    </button>
  );
}

function Home() {
  const t = useT();
  const lang = useLang();
  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <section className="pb-14 pt-10 sm:pb-20 sm:pt-20">
        <p className="label-mono animate-fade-up">{t("home.eyebrow")}</p>
        <h1 className="mt-4 max-w-3xl animate-fade-up text-5xl font-extrabold leading-[0.95] [animation-delay:60ms] sm:text-7xl">
          {t("home.title1")}
          <br />
          {t("home.title2")}<span className="text-coral">.</span>
        </h1>
        <p className="mt-6 max-w-lg animate-fade-up text-lg text-muted-foreground [animation-delay:120ms]">
          {t("home.intro")}
        </p>
        <div className="mt-8 flex animate-fade-up flex-wrap items-center gap-4 [animation-delay:180ms]">
          <RandomExperimentButton />
          <span className="label-mono">{t("home.count", { n: experiments.length })}</span>
        </div>
      </section>

      <section aria-labelledby="experiments-heading">
        <div className="mb-5 flex items-baseline justify-between border-b pb-3">
          <h2 id="experiments-heading" className="text-lg font-bold">
            {t("home.listTitle")}
          </h2>
          <span className="label-mono">{t("home.pick")}</span>
        </div>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {experiments.map((e, i) => {
            const Icon = e.icon;
            return (
              <li
                key={e.id}
                className="animate-fade-up"
                style={{ animationDelay: `${200 + i * 50}ms` }}
              >
                <Link
                  {...e.link}
                  className="group flex h-full flex-col rounded-2xl border bg-card p-5 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-foreground/20 hover:shadow-lift"
                >
                  <div className="flex items-start justify-between">
                    <span
                      className={`grid size-12 place-items-center rounded-xl ${toneSoft[e.tone]} transition-transform duration-300 group-hover:rotate-[-8deg] group-hover:scale-110`}
                    >
                      <Icon className="size-6" strokeWidth={2.2} />
                    </span>
                    <span className="label-mono">{t("home.no", { no: e.no })}</span>
                  </div>
                  <h3 className="mt-6 text-xl font-bold">{experimentText(lang, e).title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{experimentText(lang, e).blurb}</p>
                  <div className="mt-auto flex items-center justify-between pt-6">
                    <span className="label-mono">{experimentText(lang, e).tag}</span>
                    <ArrowUpRight className="size-4 text-muted-foreground transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-foreground" />
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
