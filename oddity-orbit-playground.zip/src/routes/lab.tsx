import { createFileRoute, Link } from "@tanstack/react-router";
import { GravityBox } from "@/components/lab/gravity-box";
import { ParticleSwarm } from "@/components/lab/particle-swarm";
import { SpecimenGenerator } from "@/components/lab/specimen-generator";
import { LAB_EXPERIMENTS, type LabExperiment } from "@/lib/experiments";
import { toneDot, type Tone } from "@/lib/tones";
import { useLang, useT } from "@/lib/preferences";
import { ID_EXPERIMENTS } from "@/lib/i18n/content-id";

const INFO: Record<LabExperiment, { title: string; tone: Tone; text: string }> = {
  particles: {
    title: "Particle Swarm",
    tone: "coral",
    text: "Move your pointer through the swarm. Switch between attract, repel and orbit, or tap to make them scatter.",
  },
  gravity: {
    title: "Gravity Box",
    tone: "sky",
    text: "Tap to drop a planet, drag to fling one. Then bend the rules: flip gravity, turn it off, or shake the box.",
  },
  art: {
    title: "Specimen Generator",
    tone: "mint",
    text: "Every press paints a new picture from a random seed. No two are alike. Save the ones you like.",
  },
};

export const Route = createFileRoute("/lab")({
  validateSearch: (search: Record<string, unknown>): { exp?: LabExperiment | undefined } => ({
    exp: LAB_EXPERIMENTS.includes(search["exp"] as LabExperiment)
      ? (search["exp"] as LabExperiment)
      : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Chaos Laboratory — ODD.LAB" },
      {
        name: "description",
        content: "A particle swarm, a gravity box and a generative art machine. Poke them all.",
      },
      { property: "og:title", content: "Chaos Laboratory — ODD.LAB" },
      {
        property: "og:description",
        content: "A particle swarm, a gravity box and a generative art machine. Poke them all.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Lab,
});

function Lab() {
  const { exp = "particles" } = Route.useSearch();
  const info = INFO[exp];
  const t = useT();
  const lang = useLang();

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <section className="pb-8 pt-8 sm:pt-14">
        <p className="label-mono">{t("lab.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("lab.title")}<span className="text-coral">.</span>
        </h1>
      </section>

      <div role="tablist" aria-label={t("lab.tabs")} className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {LAB_EXPERIMENTS.map((id, i) => (
          <Link
            key={id}
            to="/lab"
            search={{ exp: id }}
            role="tab"
            aria-selected={exp === id}
            className={`flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200 ${
              exp === id
                ? "border-primary bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            <span className={`size-2 rounded-full ${toneDot[INFO[id].tone]}`} />
            <span className="font-mono text-xs opacity-60">0{i + 1}</span>
            {lang === "id" ? (ID_EXPERIMENTS[id]?.title ?? INFO[id].title) : INFO[id].title}
          </Link>
        ))}
      </div>

      <div key={exp} className="animate-fade-up">
        <p className="mb-5 max-w-xl text-muted-foreground">{t(`lab.text.${exp}`)}</p>
        {exp === "particles" && <ParticleSwarm />}
        {exp === "gravity" && <GravityBox />}
        {exp === "art" && <SpecimenGenerator />}
      </div>
    </div>
  );
}
