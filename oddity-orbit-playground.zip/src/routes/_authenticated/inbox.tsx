import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { inboxQueryKey, useInbox } from "@/lib/use-inbox";
import { Mail, ShieldAlert, TriangleAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { isTimedOut } from "@/lib/moderation";
import { formatDate, useLang, useT } from "@/lib/preferences";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/inbox")({
  head: () => ({
    meta: [
      { title: "Inbox — ODD.LAB" },
      { name: "description", content: "Messages and notices from the ODD.LAB team." },
      { property: "og:title", content: "Inbox — ODD.LAB" },
      { property: "og:description", content: "Messages and notices from the ODD.LAB team." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: InboxPage,
});

const ICON = { info: Mail, warning: TriangleAlert, moderation: ShieldAlert } as const;

function InboxPage() {
  const t = useT();
  const lang = useLang();
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const { data, isLoading } = useInbox();
  const unread = (data ?? []).filter((m) => !m.read_at);

  const markRead = async (ids: string[]) => {
    if (!ids.length) return;
    await supabase.from("inbox_messages").update({ read_at: new Date().toISOString() }).in("id", ids);
    void queryClient.invalidateQueries({ queryKey: inboxQueryKey(user?.id) });
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">{t("inbox.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("inbox.title")}<span className="text-coral">.</span>
        </h1>
      </section>
      {isTimedOut(profile?.timeout_until) && (
        <p className="mb-4 rounded-2xl border border-coral/40 bg-coral/10 p-4 text-sm">
          {t("inbox.timeout", { date: formatDate(lang, profile!.timeout_until, true) })}
        </p>
      )}
      {unread.length > 0 && (
        <button type="button" onClick={() => markRead(unread.map((m) => m.id))} className="mb-4 h-9 rounded-full border bg-card px-4 text-sm hover:bg-muted">
          {t("inbox.markAll")}
        </button>
      )}
      {isLoading ? (
        <p className="text-muted-foreground">{t("common.loading")}</p>
      ) : !data?.length ? (
        <p className="rounded-2xl border bg-card p-6 text-muted-foreground shadow-soft">{t("inbox.empty")}</p>
      ) : (
        <ul className="space-y-3">
          {data.map((m) => {
            const Icon = ICON[m.kind as keyof typeof ICON] ?? Mail;
            return (
              <li key={m.id}>
                <button
                  type="button"
                  onClick={() => !m.read_at && markRead([m.id])}
                  className={cn("w-full rounded-2xl border bg-card p-4 text-left shadow-soft", !m.read_at && "border-foreground/30")}
                >
                  <div className="flex items-center gap-2">
                    <Icon className={cn("size-4", m.kind === "info" ? "text-sky" : "text-coral")} />
                    <span className="label-mono">{t(`inbox.kind.${m.kind as "info" | "warning" | "moderation"}`)}</span>
                    {!m.read_at && <span className="rounded-full bg-coral px-2 text-[0.65rem] font-bold uppercase text-primary-foreground">{t("inbox.new")}</span>}
                    <span className="label-mono ml-auto">{formatDate(lang, m.created_at, true)}</span>
                  </div>
                  <p className="mt-2 font-bold">{m.title}</p>
                  <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">{m.body}</p>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
