import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Camera, Trash2 } from "lucide-react";
import { Field, FormMessage, PrimaryButton, authErrorKey } from "@/components/auth/auth-ui";
import { PreferenceRows } from "@/components/site/preference-controls";
import { UserAvatar } from "@/components/site/user-avatar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { verifyCurrentPassword } from "@/lib/auth.functions";
import type { MessageKey } from "@/lib/i18n/en";
import { formatDate, useLang, useT } from "@/lib/preferences";
import { isStrongPassword } from "@/lib/rewards";
import { TERMS_VERSION } from "@/lib/terms";
import { cn } from "@/lib/utils";

const TABS = ["profile", "account", "password", "preferences"] as const;
type Tab = (typeof TABS)[number];

export const Route = createFileRoute("/_authenticated/profile")({
  validateSearch: (search: Record<string, unknown>): { tab?: Tab | undefined } => ({
    tab: TABS.includes(search["tab"] as Tab) ? (search["tab"] as Tab) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Your profile — ODD.LAB" },
      { name: "description", content: "Manage your ODD.LAB display name, picture, password and preferences." },
      { property: "og:title", content: "Your profile — ODD.LAB" },
      { property: "og:description", content: "Manage your ODD.LAB account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const t = useT();
  const { tab = "profile" } = Route.useSearch();
  const navigate = useNavigate();
  const { profile } = useAuth();

  return (
    <div className="mx-auto w-full max-w-3xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">{t("profile.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("profile.title")}
          <span className="text-coral">.</span>
        </h1>
      </section>
      <div role="tablist" className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {TABS.map((id) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            onClick={() => navigate({ to: "/profile", search: { tab: id }, replace: true })}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200",
              tab === id ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground",
            )}
          >
            {t(`profile.tab.${id}`)}
          </button>
        ))}
      </div>
      <div key={tab} className="animate-fade-up rounded-3xl border bg-card p-6 shadow-soft sm:p-8">
        {!profile ? (
          <p className="text-muted-foreground">{t("common.loading")}</p>
        ) : tab === "profile" ? (
          <ProfileTab />
        ) : tab === "account" ? (
          <AccountTab />
        ) : tab === "password" ? (
          <PasswordTab />
        ) : (
          <div>
            <p className="mb-6 text-sm text-muted-foreground">{t("profile.prefsHint")}</p>
            <PreferenceRows />
          </div>
        )}
      </div>
    </div>
  );
}

const IMAGE_TYPES: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif" };

function ProfileTab() {
  const t = useT();
  const lang = useLang();
  const { user, profile, avatarUrl, refresh } = useAuth();
  const [name, setName] = useState(profile?.display_name ?? "");
  const [error, setError] = useState<MessageKey | null>(null);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => setName(profile?.display_name ?? ""), [profile?.display_name]);
  if (!user || !profile) return null;

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = name.trim();
    if (clean.length < 1 || clean.length > 40) return setError("profile.displayNameInvalid");
    setError(null);
    setBusy(true);
    const { error: err } = await supabase.from("profiles").update({ display_name: clean }).eq("id", user.id);
    setBusy(false);
    if (err) return setError("err.generic");
    await refresh();
    toast.success(t("profile.saved"));
  };

  const upload = async (file: File) => {
    const ext = IMAGE_TYPES[file.type];
    if (!ext) { toast.error(t("profile.pictureType")); return; }
    if (file.size > 2 * 1024 * 1024) { toast.error(t("profile.pictureTooBig")); return; }
    setUploading(true);
    const path = `${user.id}/avatar-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, file, { contentType: file.type });
    if (upErr) {
      setUploading(false);
      { toast.error(t("err.generic")); return; }
    }
    const old = profile.avatar_url;
    const { error: err } = await supabase.from("profiles").update({ avatar_url: path }).eq("id", user.id);
    if (!err && old) await supabase.storage.from("avatars").remove([old]);
    setUploading(false);
    if (err) { toast.error(t("err.generic")); return; }
    await refresh();
    toast.success(t("profile.pictureSaved"));
  };

  const removePicture = async () => {
    if (!profile.avatar_url) return;
    const old = profile.avatar_url;
    const { error: err } = await supabase.from("profiles").update({ avatar_url: null }).eq("id", user.id);
    if (err) { toast.error(t("err.generic")); return; }
    await supabase.storage.from("avatars").remove([old]);
    await refresh();
    toast.success(t("profile.pictureSaved"));
  };

  return (
    <div className="space-y-8">
      <div>
        <p className="mb-3 text-sm font-medium">{t("profile.picture")}</p>
        <div className="flex flex-wrap items-center gap-4">
          <UserAvatar name={profile.display_name || profile.username} url={avatarUrl} className="size-20 text-xl" />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={uploading}
              onClick={() => fileRef.current?.click()}
              className="inline-flex h-9 items-center gap-1.5 rounded-full border bg-card px-4 text-sm font-medium transition-colors hover:bg-muted disabled:opacity-50"
            >
              <Camera className="size-4" /> {uploading ? t("common.saving") : profile.avatar_url ? t("profile.change") : t("profile.upload")}
            </button>
            {profile.avatar_url && (
              <button
                type="button"
                onClick={removePicture}
                className="inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-sm text-muted-foreground transition-colors hover:text-destructive"
              >
                <Trash2 className="size-4" /> {t("profile.remove")}
              </button>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
            aria-label={t("profile.upload")}
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = "";
              if (f) void upload(f);
            }}
          />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">{t("profile.pictureHint")}</p>
      </div>

      <form onSubmit={save} noValidate className="space-y-4">
        <Field
          label={t("profile.displayName")}
          name="display_name"
          maxLength={40}
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={error ? t(error) : undefined}
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <Info label={t("profile.username")} value={`@${profile.username}`} hint={t("profile.usernameFixed")} />
          <Info label={t("profile.joined")} value={formatDate(lang, profile.created_at)} />
        </div>
        <PrimaryButton type="submit" className="sm:w-auto" disabled={busy}>
          {busy ? t("common.saving") : t("profile.save")}
        </PrimaryButton>
      </form>
    </div>
  );
}

function Info({ label, value, hint }: { label: string; value: React.ReactNode; hint?: string }) {
  return (
    <div className="rounded-xl bg-muted/60 px-4 py-3">
      <p className="label-mono">{label}</p>
      <p className="mt-1 break-all font-medium">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function AccountTab() {
  const t = useT();
  const lang = useLang();
  const { user, profile, isAdmin, termsAcceptedAt } = useAuth();
  if (!user || !profile) return null;
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Info label={t("profile.email")} value={user.email} />
      <Info label={t("profile.username")} value={`@${profile.username}`} />
      <Info label={t("profile.role")} value={isAdmin ? t("profile.role.admin") : t("profile.role.user")} />
      <Info
        label={t("profile.status")}
        value={profile.status === "active" ? t("profile.status.active") : t("profile.status.suspended")}
      />
      <Info label={t("profile.joined")} value={formatDate(lang, profile.created_at, true)} />
      <Info label={t("profile.lastSignIn")} value={formatDate(lang, user.last_sign_in_at, true)} />
      <div className="sm:col-span-2">
        <Info
          label={t("profile.terms")}
          value={
            termsAcceptedAt ? (
              <span>
                v{TERMS_VERSION} · {formatDate(lang, termsAcceptedAt, true)} ·{" "}
                <Link to="/terms" className="underline underline-offset-4">
                  {t("terms.review")}
                </Link>
              </span>
            ) : (
              <Link to="/terms-update" className="underline underline-offset-4">
                {t("profile.termsNone")}
              </Link>
            )
          }
        />
      </div>
    </div>
  );
}

function PasswordTab() {
  const t = useT();
  const verify = useServerFn(verifyCurrentPassword);
  const [form, setForm] = useState({ current: "", next: "", confirm: "" });
  const [error, setError] = useState<MessageKey | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDone(false);
    if (!form.current) return setError("err.passwordRequired");
    if (!isStrongPassword(form.next)) return setError("err.passwordWeak");
    if (form.next !== form.confirm) return setError("err.passwordMismatch");
    if (form.next === form.current) return setError("profile.samePassword");
    setError(null);
    setBusy(true);
    try {
      const check = await verify({ data: { password: form.current } });
      if (!check.ok) return setError("profile.wrongPassword");
      const { error: err } = await supabase.auth.updateUser({ password: form.next, current_password: form.current });
      if (err) return setError(err.code === "same_password" ? "profile.samePassword" : authErrorKey(err));
      setForm({ current: "", next: "", confirm: "" });
      setDone(true);
      toast.success(t("profile.passwordUpdated"));
    } catch {
      setError("err.generic");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate className="max-w-md space-y-4">
      {error && <FormMessage tone="error">{t(error)}</FormMessage>}
      {done && <FormMessage tone="success">{t("profile.passwordUpdated")}</FormMessage>}
      <Field label={t("profile.currentPassword")} name="current" type="password" autoComplete="current-password" maxLength={200} value={form.current} onChange={set("current")} />
      <Field label={t("profile.newPassword")} name="next" type="password" autoComplete="new-password" maxLength={72} value={form.next} onChange={set("next")} hint={t("auth.passwordHint")} />
      <Field label={t("auth.confirmPassword")} name="confirm" type="password" autoComplete="new-password" maxLength={72} value={form.confirm} onChange={set("confirm")} />
      <PrimaryButton type="submit" className="sm:w-auto" disabled={busy}>
        {busy ? t("common.saving") : t("profile.updatePassword")}
      </PrimaryButton>
    </form>
  );
}
