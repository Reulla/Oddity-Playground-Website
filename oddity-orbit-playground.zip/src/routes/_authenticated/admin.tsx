import { createFileRoute, redirect } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AdminOverview } from "@/components/admin/admin-overview";
import { AdminUsers } from "@/components/admin/admin-users";
import { AdminActivity } from "@/components/admin/admin-activity";
import { AdminSend } from "@/components/admin/admin-send";
import { supabase } from "@/integrations/supabase/client";
import { useT } from "@/lib/preferences";

const TABS = ["overview", "users", "activity", "send"] as const;

export const Route = createFileRoute("/_authenticated/admin")({
  // UI gate only — every admin action is also checked on the server.
  beforeLoad: async ({ context }) => {
    const { data } = await supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!data) throw redirect({ to: "/" });
  },
  head: () => ({
    meta: [
      { title: "Admin Dashboard — ODD.LAB" },
      { name: "description", content: "ODD.LAB staff dashboard." },
      { property: "og:title", content: "Admin Dashboard — ODD.LAB" },
      { property: "og:description", content: "ODD.LAB staff dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const t = useT();
  return (
    <div className="mx-auto w-full max-w-6xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">{t("admin.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("admin.title")}
          <span className="text-coral">.</span>
        </h1>
      </section>
      <Tabs defaultValue="overview">
        <div className="-mx-4 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
          <TabsList className="h-auto gap-1 rounded-full border bg-card p-1">
            {TABS.map((id) => (
              <TabsTrigger
                key={id}
                value={id}
                className="rounded-full px-4 py-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                {t(`admin.tab.${id}`)}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
        <TabsContent value="overview" className="mt-6">
          <AdminOverview />
        </TabsContent>
        <TabsContent value="users" className="mt-6">
          <AdminUsers />
        </TabsContent>
        <TabsContent value="activity" className="mt-6">
          <AdminActivity />
        </TabsContent>
        <TabsContent value="send" className="mt-6">
          <AdminSend />
        </TabsContent>
      </Tabs>
    </div>
  );
}
