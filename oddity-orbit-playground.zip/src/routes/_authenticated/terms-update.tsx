import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { FormMessage, PrimaryButton } from "@/components/auth/auth-ui";
import { TermsDocument } from "@/components/auth/terms-document";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { formatDate, useLang, useT } from "@/lib/preferences";
import { TERMS_VERSION } from "@/lib/terms";

export const Route = createFileRoute("/_authenticated/terms-update")({
  head: () => ({
    meta: [
      { title: "Review the updated terms — ODD.LAB" },
      { name: "description", content: "Review and accept the latest ODD.LAB Terms of Service." },
      { property: "og:title", content: "Review the updated terms — ODD.LAB" },
      { property: "og:description", content: "Review and accept the latest ODD.LAB Terms of Service." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: TermsUpdate,
});

function TermsUpdate() {
  const t = useT();
  const lang = useLang();
  const navigate = useNavigate();
  const { termsOk, termsAcceptedAt, refresh } = useAuth();
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  const accept = async () => {
    setBusy(true);
    setError(false);
    const { error: err } = await supabase.rpc("accept_current_terms");
    setBusy(false);
    if (err) return setError(true);
    await refresh();
    toast.success(t("toast.termsAccepted"));
    navigate({ to: "/score" });
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pt-8 sm:px-8 sm:pt-14">
      <h1 className="text-4xl font-extrabold sm:text-5xl">
        {termsOk ? t("terms.title") : t("terms.updatedTitle")}
        <span className="text-coral">.</span>
      </h1>
      <p className="mt-3 text-muted-foreground">
        {termsOk
          ? t("terms.acceptedOn", { v: TERMS_VERSION, date: formatDate(lang, termsAcceptedAt, true) })
          : t("terms.updatedSub")}
      </p>
      <div className="mt-8 max-h-[55vh] overflow-y-auto rounded-3xl border bg-card p-6 shadow-soft sm:p-8">
        <TermsDocument />
      </div>
      {!termsOk && (
        <div className="mt-6 space-y-4 rounded-3xl border bg-card p-6 shadow-soft">
          {error && <FormMessage tone="error">{t("err.generic")}</FormMessage>}
          <label className="flex cursor-pointer items-start gap-3 text-sm">
            <Checkbox className="mt-0.5" checked={checked} onCheckedChange={(v) => setChecked(v === true)} />
            <span>{t("terms.checkbox")}</span>
          </label>
          <PrimaryButton type="button" className="sm:w-auto" disabled={!checked || busy} onClick={accept}>
            {busy ? t("common.saving") : t("terms.accept")}
          </PrimaryButton>
        </div>
      )}
    </div>
  );
}
