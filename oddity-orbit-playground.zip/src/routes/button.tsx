import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  BUTTON_EVENTS,
  GOLDEN_EVENT,
  TOTAL_EVENTS,
  pickButtonEvent,
  type ButtonAnim,
  type ButtonEvent,
} from "@/lib/button-events";
import { useLang, useT } from "@/lib/preferences";
import { buttonEventText } from "@/lib/i18n/content";
import { useRewards } from "@/lib/use-rewards";
import { GOALS } from "@/lib/rewards";
import { TONES, toneSolid, type Tone } from "@/lib/tones";

export const Route = createFileRoute("/button")({
  head: () => ({
    meta: [
      { title: "The Button — ODD.LAB" },
      {
        name: "description",
        content: "One big button. Every press does something different. Can you find every event?",
      },
      { property: "og:title", content: "The Button — ODD.LAB" },
      {
        property: "og:description",
        content: "One big button. Every press does something different. Can you find every event?",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ButtonPage,
});

const STORAGE_KEY = "oddlab-button-v1";
const KNOWN_IDS = new Set([...BUTTON_EVENTS.map((e) => e.id), GOLDEN_EVENT.id]);

const stageBg: Record<Tone, string> = {
  coral: "bg-coral/15",
  mint: "bg-mint/20",
  sky: "bg-sky/15",
  sun: "bg-sun/25",
  lime: "bg-lime/25",
};

const ANIMS: Record<Exclude<ButtonAnim, "none">, Keyframe[]> = {
  wobble: [
    { transform: "rotate(0)" },
    { transform: "rotate(-12deg)" },
    { transform: "rotate(10deg)" },
    { transform: "rotate(-6deg)" },
    { transform: "rotate(0)" },
  ],
  spin: [{ transform: "rotate(0)" }, { transform: "rotate(360deg)" }],
  jelly: [
    { transform: "scale(1, 1)" },
    { transform: "scale(1.25, 0.75)" },
    { transform: "scale(0.85, 1.15)" },
    { transform: "scale(1.05, 0.95)" },
    { transform: "scale(1, 1)" },
  ],
  pop: [{ transform: "scale(1)" }, { transform: "scale(1.15)" }, { transform: "scale(1)" }],
  flip: [{ transform: "perspective(600px) rotateY(0)" }, { transform: "perspective(600px) rotateY(360deg)" }],
  shake: [
    { transform: "translateX(0)" },
    { transform: "translateX(-12px)" },
    { transform: "translateX(12px)" },
    { transform: "translateX(-8px)" },
    { transform: "translateX(8px)" },
    { transform: "translateX(0)" },
  ],
};

type Piece = { id: number; dx: number; dy: number; rot: number; tone: Tone; round: boolean };

function ButtonPage() {
  const t = useT();
  const lang = useLang();
  const [clicks, setClicks] = useState(0);
  const [found, setFound] = useState<string[]>([]);
  const [event, setEvent] = useState<ButtonEvent | null>(null);
  const [history, setHistory] = useState<{ n: number; ev: ButtonEvent }[]>([]);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [pieces, setPieces] = useState<Piece[]>([]);
  const [loaded, setLoaded] = useState(false);
  const animRef = useRef<HTMLDivElement>(null);
  const pieceId = useRef(0);
  const { award, logExperiment } = useRewards();
  useEffect(() => logExperiment("button"), [logExperiment]);

  // Restore progress after hydration
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null");
      if (saved && typeof saved.clicks === "number") {
        setClicks(saved.clicks);
        setFound((saved.found ?? []).filter((id: string) => KNOWN_IDS.has(id)));
      }
    } catch {
      /* ignore broken storage */
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ clicks, found }));
  }, [clicks, found, loaded]);

  const burst = () => {
    const fresh: Piece[] = Array.from({ length: 28 }, () => {
      const angle = Math.random() * Math.PI * 2;
      const dist = 120 + Math.random() * 160;
      return {
        id: pieceId.current++,
        dx: Math.cos(angle) * dist,
        dy: Math.sin(angle) * dist,
        rot: (Math.random() - 0.5) * 720,
        tone: TONES[Math.floor(Math.random() * TONES.length)] ?? "coral",
        round: Math.random() > 0.5,
      };
    });
    setPieces((p) => [...p, ...fresh]);
    const ids = new Set(fresh.map((f) => f.id));
    window.setTimeout(() => setPieces((p) => p.filter((x) => !ids.has(x.id))), 1000);
  };

  const press = () => {
    const n = clicks + 1;
    const next = pickButtonEvent(n, event?.id);
    setClicks(n);
    setEvent(next);
    setHistory((h) => [{ n, ev: next }, ...h].slice(0, 5));
    if (KNOWN_IDS.has(next.id)) void award("button_event", next.id);
    if (next.id === GOLDEN_EVENT.id) void award("easter_egg", "golden-click");
    if (next.effect === "blackout") void award("easter_egg", "lights-out");
    if (n >= GOALS.buttonClicks) void award("experiment", "button", t("button.title"));
    if (KNOWN_IDS.has(next.id)) setFound((f) => (f.includes(next.id) ? f : [...f, next.id]));

    if (next.effect === "runaway") {
      const range = Math.min(window.innerWidth / 4, 140);
      setOffset({ x: (Math.random() - 0.5) * 2 * range, y: (Math.random() - 0.5) * 80 });
    } else {
      setOffset({ x: 0, y: 0 });
    }
    if (next.effect === "confetti") burst();
    if (next.anim !== "none") {
      animRef.current?.animate(ANIMS[next.anim], {
        duration: next.anim === "spin" || next.anim === "flip" ? 700 : 500,
        easing: "cubic-bezier(0.3, 0.7, 0.4, 1)",
      });
    }
  };

  const reset = () => {
    setClicks(0);
    setFound([]);
    setEvent(null);
    setHistory([]);
    setOffset({ x: 0, y: 0 });
  };

  const effect = event?.effect ?? "none";
  const dark = effect === "blackout";
  const scale = effect === "giant" ? 1.3 : effect === "tiny" ? 0.45 : 1;
  const tone: Tone = event?.tone ?? "coral";

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">{t("button.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("button.title")}<span className="text-coral">.</span>
        </h1>
      </section>

      <div
        className={`relative overflow-hidden rounded-3xl border transition-colors duration-500 ${
          dark ? "bg-ink text-primary-foreground" : event ? stageBg[tone] : "bg-card"
        }`}
      >
        <div
          className={`flex min-h-[520px] flex-col items-center justify-between gap-8 px-5 py-10 transition-transform duration-700 sm:min-h-[580px] ${
            effect === "upside" ? "rotate-180" : ""
          }`}
        >
          <p
            key={clicks}
            aria-live="polite"
            className="min-h-[4rem] max-w-md animate-fade-up text-balance text-center font-display text-2xl font-bold sm:text-3xl"
          >
            {event ? buttonEventText(lang, event) : t("button.goOn")}
          </p>

          <div
            className="relative transition-transform duration-500 ease-out"
            style={{ transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})` }}
          >
            <div ref={animRef}>
              <button
                type="button"
                onClick={press}
                aria-label={t("button.aria")}
                className={`grid size-52 select-none place-items-center rounded-full border-4 border-ink font-display text-3xl font-extrabold tracking-wide text-ink shadow-[0_10px_0_var(--ink)] transition-[transform,box-shadow,background-color] duration-150 active:translate-y-2.5 active:shadow-[0_0_0_var(--ink)] sm:size-64 ${
                  event?.id === GOLDEN_EVENT.id ? toneSolid.sun : toneSolid[tone]
                }`}
              >
                {t("button.press")}
              </button>
            </div>
            <div className="pointer-events-none absolute left-1/2 top-1/2" aria-hidden>
              {pieces.map((p) => (
                <span
                  key={p.id}
                  className={`confetti-piece absolute left-0 top-0 size-2.5 ${toneSolid[p.tone]} ${
                    p.round ? "rounded-full" : "rounded-[2px]"
                  }`}
                  style={
                    {
                      "--dx": `${p.dx}px`,
                      "--dy": `${p.dy}px`,
                      "--rot": `${p.rot}deg`,
                    } as React.CSSProperties
                  }
                />
              ))}
            </div>
          </div>

          <div className="flex w-full flex-wrap items-center justify-center gap-x-6 gap-y-2 font-mono text-xs opacity-70">
            <span>
              {t("button.clicks")} <strong className="font-medium">{clicks.toLocaleString()}</strong>
            </span>
            <span>
              {t("button.found")}{" "}
              <strong className="font-medium">
                {found.length}/{TOTAL_EVENTS}
              </strong>
            </span>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-[1fr_auto]">
        <div>
          <p className="label-mono mb-3">{t("button.recent")}</p>
          {history.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("button.waiting")}</p>
          ) : (
            <ol className="space-y-1.5">
              {history.map((h, i) => (
                <li
                  key={h.n}
                  className="flex gap-3 text-sm transition-opacity"
                  style={{ opacity: 1 - i * 0.17 }}
                >
                  <span className="w-12 shrink-0 font-mono text-xs text-muted-foreground">
                    #{h.n}
                  </span>
                  {buttonEventText(lang, h.ev)}
                </li>
              ))}
            </ol>
          )}
        </div>
        <button
          type="button"
          onClick={reset}
          className="h-9 self-start rounded-full border bg-card px-4 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          {t("button.reset")}
        </button>
      </div>
    </div>
  );
}
