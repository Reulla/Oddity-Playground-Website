import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { AuthCard, Field, FormMessage, PrimaryButton } from "@/components/auth/auth-ui";
import { supabase } from "@/integrations/supabase/client";
import type { MessageKey } from "@/lib/i18n/en";
import { useT } from "@/lib/preferences";
import { USERNAME_RE, isStrongPassword } from "@/lib/rewards";
import { signupStore } from "@/lib/signup-store";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create an account — ODD.LAB" },
      { name: "description", content: "Join ODD.LAB to collect points, unlock achievements and save your preferences." },
      { property: "og:title", content: "Create an account — ODD.LAB" },
      { property: "og:description", content: "Collect points, unlock achievements and save your preferences." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SignUpPage,
});

const schema = z
  .object({
    username: z.string().trim().toLowerCase().regex(USERNAME_RE, "err.usernameFormat"),
    email: z.string().trim().max(255, "err.emailInvalid").email("err.emailInvalid"),
    password: z.string().refine(isStrongPassword, "err.passwordWeak"),
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, { path: ["confirm"], message: "err.passwordMismatch" });

type Errors = Partial<Record<"username" | "email" | "password" | "confirm" | "form", MessageKey>>;

function SignUpPage() {
  const t = useT();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);

  // Coming back from the Terms step: restore the details and any error.
  useEffect(() => {
    const p = signupStore.get();
    if (p) setForm({ username: p.username, email: p.email, password: p.password, confirm: p.password });
    const err = signupStore.takeError();
    if (err) setErrors({ [err.field]: err.key });
  }, []);

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const next: Errors = {};
      for (const issue of parsed.error.issues) {
        const field = issue.path[0] as keyof Errors;
        if (!next[field]) next[field] = issue.message as MessageKey;
      }
      setErrors(next);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      const { data: available, error } = await supabase.rpc("username_available", { _username: parsed.data.username });
      if (error) {
        setErrors({ form: "err.generic" });
        return;
      }
      if (!available) {
        setErrors({ username: "err.usernameTaken" });
        return;
      }
      signupStore.set({ username: parsed.data.username, email: parsed.data.email, password: parsed.data.password });
      navigate({ to: "/signup/terms" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthCard eyebrow={t("auth.step", { n: 1 })} title={t("auth.signUpTitle")} sub={t("auth.signUpSub")}>
      <form onSubmit={submit} noValidate className="space-y-4">
        {errors.form && <FormMessage tone="error">{t(errors.form)}</FormMessage>}
        <Field
          label={t("auth.username")}
          name="username"
          autoComplete="username"
          maxLength={20}
          value={form.username}
          onChange={update("username")}
          hint={t("auth.usernameHint")}
          error={errors.username && t(errors.username)}
        />
        <Field
          label={t("auth.email")}
          name="email"
          type="email"
          autoComplete="email"
          maxLength={255}
          value={form.email}
          onChange={update("email")}
          error={errors.email && t(errors.email)}
        />
        <Field
          label={t("auth.password")}
          name="password"
          type="password"
          autoComplete="new-password"
          maxLength={72}
          value={form.password}
          onChange={update("password")}
          hint={t("auth.passwordHint")}
          error={errors.password && t(errors.password)}
        />
        <Field
          label={t("auth.confirmPassword")}
          name="confirm"
          type="password"
          autoComplete="new-password"
          maxLength={72}
          value={form.confirm}
          onChange={update("confirm")}
          error={errors.confirm && t(errors.confirm)}
        />
        <PrimaryButton type="submit" disabled={busy}>
          {busy ? t("auth.checking") : t("auth.continue")}
        </PrimaryButton>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        {t("auth.haveAccount")}{" "}
        <Link to="/auth" search={{ redirect: undefined }} className="font-medium text-foreground underline-offset-4 hover:underline">
          {t("auth.signIn")}
        </Link>
      </p>
    </AuthCard>
  );
}
