import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AuthCard, Field, FormMessage, PrimaryButton, authErrorKey } from "@/components/auth/auth-ui";
import { supabase } from "@/integrations/supabase/client";
import type { MessageKey } from "@/lib/i18n/en";
import { useT } from "@/lib/preferences";
import { isStrongPassword } from "@/lib/rewards";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password — ODD.LAB" },
      { name: "description", content: "Set a new password for your ODD.LAB account." },
      { property: "og:title", content: "Choose a new password — ODD.LAB" },
      { property: "og:description", content: "Set a new password for your ODD.LAB account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const t = useT();
  const navigate = useNavigate();
  const [state, setState] = useState<"checking" | "ready" | "invalid">("checking");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<MessageKey | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const fromLink = window.location.hash.includes("type=recovery") || window.location.search.includes("code=");
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setState("ready");
    });
    const timer = window.setTimeout(async () => {
      const { data } = await supabase.auth.getSession();
      setState((s) => (s === "ready" ? s : data.session && fromLink ? "ready" : "invalid"));
    }, 1500);
    return () => {
      sub.subscription.unsubscribe();
      clearTimeout(timer);
    };
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isStrongPassword(password)) return setError("err.passwordWeak");
    if (password !== confirm) return setError("err.passwordMismatch");
    setError(null);
    setBusy(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (err) return setError(authErrorKey(err));
    toast.success(t("reset.done"));
    navigate({ to: "/", replace: true });
  };

  return (
    <AuthCard title={t("reset.title")}>
      {state === "checking" && <p className="text-sm text-muted-foreground">{t("reset.waiting")}</p>}
      {state === "invalid" && <FormMessage tone="error">{t("reset.invalid")}</FormMessage>}
      {state === "ready" && (
        <form onSubmit={submit} noValidate className="space-y-4">
          {error && <FormMessage tone="error">{t(error)}</FormMessage>}
          <Field
            label={t("reset.newPassword")}
            name="password"
            type="password"
            autoComplete="new-password"
            maxLength={72}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            hint={t("auth.passwordHint")}
          />
          <Field
            label={t("auth.confirmPassword")}
            name="confirm"
            type="password"
            autoComplete="new-password"
            maxLength={72}
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
          <PrimaryButton type="submit" disabled={busy}>
            {busy ? t("common.saving") : t("reset.save")}
          </PrimaryButton>
        </form>
      )}
    </AuthCard>
  );
}
