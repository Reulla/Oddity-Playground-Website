import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { Bot, Send, Timer, User } from "lucide-react";
import { toast } from "sonner";
import { Slider } from "@/components/ui/slider";
import { useAuth } from "@/lib/auth";
import { useLang, useT } from "@/lib/preferences";
import type { MessageKey } from "@/lib/i18n/en";
import {
  HON_DEFAULT_MINUTES,
  HON_MAX_MESSAGE_LENGTH,
  HON_MAX_MINUTES,
  HON_MIN_MINUTES,
  difficultyFor,
  roundSecondsLeft,
  type Persona,
} from "@/lib/human-or-not";
import { sendRoundMessage, startRound, submitGuess } from "@/lib/human-or-not.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/human-or-not")({
  head: () => ({
    meta: [
      { title: "Human Or Not? — ODD.LAB" },
      { name: "description", content: "Chat with a stranger against the clock and guess: human or AI? In English and Indonesian." },
      { property: "og:title", content: "Human Or Not? — ODD.LAB" },
      { property: "og:description", content: "A chat game: talk to a stranger, then decide if they're a person or a machine." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HumanOrNotPage,
});

type Line = { from: "me" | "them"; text: string };
type Round = { id: string; deadline: string; difficulty: number };
type Result = { persona: Persona; correct: boolean; points: number };

function mmss(s: number) {
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function HumanOrNotPage() {
  const t = useT();
  const { user, ready } = useAuth();
  return (
    <div className="mx-auto w-full max-w-3xl px-4 sm:px-8">
      <section className="pb-8 pt-8 sm:pt-14">
        <p className="label-mono">{t("hon.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("hon.title")}
        </h1>
        <p className="mt-4 max-w-xl text-muted-foreground">{t("hon.intro")}</p>
      </section>
      {!ready ? (
        <p className="text-muted-foreground">{t("common.loading")}</p>
      ) : user ? (
        <Game />
      ) : (
        <div className="rounded-2xl border bg-card p-6 shadow-soft">
          <p className="text-muted-foreground">{t("hon.signInText")}</p>
          <Link
            to="/auth"
            search={{ redirect: "/human-or-not" }}
            className="mt-4 inline-flex h-11 items-center rounded-full bg-primary px-6 font-medium text-primary-foreground"
          >
            {t("hon.signIn")}
          </Link>
        </div>
      )}
    </div>
  );
}

function Game() {
  const t = useT();
  const lang = useLang();
  const queryClient = useQueryClient();
  const start = useServerFn(startRound);
  const send = useServerFn(sendRoundMessage);
  const guessFn = useServerFn(submitGuess);
  const [minutes, setMinutes] = useState(HON_DEFAULT_MINUTES);
  const [custom, setCustom] = useState(false);
  const [round, setRound] = useState<Round | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [left, setLeft] = useState(0);
  const [result, setResult] = useState<Result | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!round || result) return;
    const tick = () => setLeft(roundSecondsLeft(round.deadline));
    tick();
    const id = window.setInterval(tick, 500);
    return () => clearInterval(id);
  }, [round, result]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [lines, waiting]);

  const begin = async () => {
    setBusy(true);
    try {
      const res = await start({ data: { minutes, lang } });
      if (!res.ok) {
        toast.error(t(res.reason === "terms" ? "terms.needed" : "hon.err.blocked"));
        return;
      }
      setRound({ id: res.roundId, deadline: res.deadline, difficulty: res.difficulty });
      setLines([]);
      setResult(null);
      setTimeout(() => inputRef.current?.focus(), 50);
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  };

  const timeUp = !!round && left <= 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const msg = text.trim();
    if (!round || !msg || waiting || timeUp) return;
    setText("");
    setLines((l) => [...l, { from: "me", text: msg }]);
    setWaiting(true);
    try {
      const started = Date.now();
      const res = await send({ data: { roundId: round.id, text: msg } });
      if (!res.ok) {
        toast.error(t(`hon.err.${res.reason === "missing" || res.reason === "finished" ? "time" : res.reason}` as MessageKey));
        return;
      }
      // A short, human-ish typing pause.
      const pause = Math.min(2500, 400 + res.reply.length * 25) - (Date.now() - started);
      if (pause > 0) await new Promise((r) => setTimeout(r, pause));
      setLines((l) => [...l, { from: "them", text: res.reply }]);
    } catch {
      toast.error(t("hon.err.ai"));
    } finally {
      setWaiting(false);
      inputRef.current?.focus();
    }
  };

  const guess = async (g: Persona) => {
    if (!round) return;
    setBusy(true);
    try {
      const res = await guessFn({ data: { roundId: round.id, guess: g } });
      setResult({ persona: res.persona, correct: res.correct, points: res.points });
      for (const a of res.achievements) toast.success(t("toast.achievement", { title: lang === "id" ? a.title_id : a.title_en }));
      if (res.points > 0) void queryClient.invalidateQueries({ queryKey: ["my-stats"] });
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  };

  if (!round) {
    const presets = [3, 5, 10, 20];
    return (
      <div className="rounded-2xl border bg-card p-6 shadow-soft">
        <p className="label-mono">{t("hon.timer")}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => { setCustom(false); setMinutes(HON_DEFAULT_MINUTES); }}
            className={cn("h-9 rounded-full border px-4 text-sm", !custom ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
          >
            {t("hon.default")}
          </button>
          <button
            type="button"
            onClick={() => setCustom(true)}
            className={cn("h-9 rounded-full border px-4 text-sm", custom ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
          >
            {t("hon.custom")}
          </button>
        </div>
        {custom && (
          <div className="mt-5">
            <div className="flex items-baseline justify-between">
              <span className="font-display text-2xl font-extrabold">{t("hon.minutes", { n: minutes })}</span>
              <span className="label-mono">{presets.join(" · ")}</span>
            </div>
            <Slider
              className="mt-3"
              min={HON_MIN_MINUTES}
              max={HON_MAX_MINUTES}
              step={1}
              value={[minutes]}
              onValueChange={(v) => setMinutes(v[0] ?? HON_DEFAULT_MINUTES)}
              aria-label={t("hon.timer")}
            />
          </div>
        )}
        <p className="mt-5 text-sm text-muted-foreground">
          <span className="font-medium text-foreground">{t("hon.difficulty", { n: difficultyFor(minutes) })}</span> · {t("hon.harder")}
        </p>
        <button
          type="button"
          onClick={begin}
          disabled={busy}
          className="mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-primary px-6 font-medium text-primary-foreground shadow-lift disabled:opacity-60"
        >
          <Bot className="size-5" /> {busy ? t("hon.starting") : t("hon.start")}
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border bg-card shadow-soft">
      <div className="flex items-center justify-between border-b px-4 py-3">
        <span className="flex items-center gap-2 font-medium">
          <span className="grid size-8 place-items-center rounded-full bg-sky/25"><User className="size-4" /></span>
          {t("hon.stranger")}
        </span>
        <span className="label-mono">{t("hon.difficulty", { n: round.difficulty })}</span>
        <span className={cn("flex items-center gap-1.5 font-mono text-sm", left <= 30 && !result && "text-coral")}>
          <Timer className="size-4" /> {mmss(result ? 0 : left)}
        </span>
      </div>

      <div className="h-[22rem] space-y-3 overflow-y-auto p-4" aria-live="polite">
        {lines.length === 0 && <p className="pt-10 text-center text-sm text-muted-foreground">{t("hon.empty")}</p>}
        {lines.map((l, i) => (
          <div key={i} className={cn("flex", l.from === "me" ? "justify-end" : "justify-start")}>
            <p
              className={cn(
                "max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-4 py-2 text-sm",
                l.from === "me" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground",
              )}
            >
              {l.text}
            </p>
          </div>
        ))}
        {waiting && <p className="text-sm italic text-muted-foreground">{t("hon.typing")}</p>}
        <div ref={endRef} />
      </div>

      {result ? (
        <div className="border-t p-5 text-center">
          <p className={cn("font-display text-3xl font-extrabold", result.correct ? "text-foreground" : "text-coral")}>
            {result.correct ? t("hon.resultRight") : t("hon.resultWrong")}
          </p>
          <p className="mt-2">{result.persona === "human" ? t("hon.wasHuman") : t("hon.wasAi")}</p>
          {result.points > 0 && <p className="label-mono mt-1">{t("hon.points", { n: result.points })}</p>}
          <p className="mx-auto mt-3 max-w-md text-xs text-muted-foreground">{t("hon.note")}</p>
          <button
            type="button"
            onClick={() => setRound(null)}
            className="mt-5 inline-flex h-11 items-center rounded-full bg-primary px-6 font-medium text-primary-foreground"
          >
            {t("hon.again")}
          </button>
        </div>
      ) : (
        <div className="space-y-3 border-t p-4">
          {timeUp ? (
            <p className="text-center font-medium text-coral">{t("hon.timeUp")}</p>
          ) : (
            <form onSubmit={submit} className="flex gap-2">
              <input
                ref={inputRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                maxLength={HON_MAX_MESSAGE_LENGTH}
                placeholder={t("hon.placeholder")}
                aria-label={t("hon.placeholder")}
                className="h-11 flex-1 rounded-full border bg-background px-4 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
              />
              <button
                type="submit"
                disabled={waiting || !text.trim()}
                aria-label={t("hon.send")}
                className="grid size-11 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
              >
                <Send className="size-4" />
              </button>
            </form>
          )}
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="label-mono mr-1">{t("hon.guessNow")}</span>
            <button type="button" disabled={busy} onClick={() => guess("human")} className="inline-flex h-10 items-center gap-1.5 rounded-full border px-4 text-sm hover:bg-muted disabled:opacity-50">
              <User className="size-4" /> {t("hon.isHuman")}
            </button>
            <button type="button" disabled={busy} onClick={() => guess("ai")} className="inline-flex h-10 items-center gap-1.5 rounded-full border px-4 text-sm hover:bg-muted disabled:opacity-50">
              <Bot className="size-4" /> {t("hon.isAi")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
