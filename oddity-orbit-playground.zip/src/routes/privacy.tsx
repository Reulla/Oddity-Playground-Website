import { createFileRoute } from "@tanstack/react-router";
import { TermsDocument } from "@/components/auth/terms-document";
import { useT } from "@/lib/preferences";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — ODD.LAB" },
      { name: "description", content: "What ODD.LAB collects, why, and how it's protected." },
      { property: "og:title", content: "Privacy Policy — ODD.LAB" },
      { property: "og:description", content: "What ODD.LAB collects, why, and how it's protected." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

function Page() {
  const t = useT();
  return (
    <div className="mx-auto w-full max-w-3xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">ODD.LAB</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("terms.privacyTitle")}
          <span className="text-coral">.</span>
        </h1>
      </section>
      <TermsDocument only="privacy" />
    </div>
  );
}
