import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { AuthCard, Field, FormMessage, PrimaryButton, authErrorKey, safeRedirect } from "@/components/auth/auth-ui";
import { supabase } from "@/integrations/supabase/client";
import { setRememberMe } from "@/lib/auth";
import { signInWithUsername } from "@/lib/auth.functions";
import type { MessageKey } from "@/lib/i18n/en";
import { useT } from "@/lib/preferences";

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>): { redirect?: string | undefined } => ({
    redirect: typeof search["redirect"] === "string" ? search["redirect"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Sign in — ODD.LAB" },
      { name: "description", content: "Sign in to ODD.LAB to keep your score, achievements and preferences." },
      { property: "og:title", content: "Sign in — ODD.LAB" },
      { property: "og:description", content: "Sign in to keep your score, achievements and preferences." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SignInPage,
});

function SignInPage() {
  const t = useT();
  const navigate = useNavigate();
  const { redirect } = Route.useSearch();
  const signInUsername = useServerFn(signInWithUsername);
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<{ identifier?: MessageKey; password?: MessageKey; form?: MessageKey }>({});
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = identifier.trim();
    const next: typeof errors = {};
    if (!id) next.identifier = "err.identifierRequired";
    if (!password) next.password = "err.passwordRequired";
    setErrors(next);
    if (Object.keys(next).length) return;

    setBusy(true);
    setRememberMe(remember);
    try {
      if (id.includes("@")) {
        const { error } = await supabase.auth.signInWithPassword({ email: id, password });
        if (error) {
          setErrors({ form: authErrorKey(error) });
          return;
        }
      } else {
        const res = await signInUsername({ data: { username: id, password } });
        if (!res.ok) {
          const map = {
            invalid: "err.invalidCredentials",
            suspended: "err.suspended",
            unconfirmed: "err.emailNotConfirmed",
            rate_limited: "err.rateLimited",
          } as const;
          setErrors({ form: map[res.error] });
          return;
        }
        const { error } = await supabase.auth.setSession({ access_token: res.access_token, refresh_token: res.refresh_token });
        if (error) {
          setErrors({ form: "err.generic" });
          return;
        }
      }
      toast.success(t("toast.signedIn"));
      navigate({ to: safeRedirect(redirect), replace: true });
    } catch {
      setErrors({ form: "err.generic" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthCard title={t("auth.signInTitle")} sub={t("auth.signInSub")}>
      <form onSubmit={submit} noValidate className="space-y-4">
        {errors.form && <FormMessage tone="error">{t(errors.form)}</FormMessage>}
        <Field
          label={t("auth.identifier")}
          name="identifier"
          autoComplete="username"
          value={identifier}
          maxLength={255}
          onChange={(e) => setIdentifier(e.target.value)}
          error={errors.identifier && t(errors.identifier)}
        />
        <Field
          label={t("auth.password")}
          name="password"
          type="password"
          autoComplete="current-password"
          value={password}
          maxLength={200}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password && t(errors.password)}
        />
        <div className="flex items-center justify-between gap-3">
          <label className="flex cursor-pointer items-center gap-2 text-sm">
            <Checkbox checked={remember} onCheckedChange={(v) => setRemember(v === true)} />
            {t("auth.remember")}
          </label>
          <Link to="/forgot-password" className="text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
            {t("auth.forgot")}
          </Link>
        </div>
        <PrimaryButton type="submit" disabled={busy}>
          {busy ? t("auth.signingIn") : t("auth.signIn")}
        </PrimaryButton>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        {t("auth.noAccount")}{" "}
        <Link to="/signup" className="font-medium text-foreground underline-offset-4 hover:underline">
          {t("auth.createAccount")}
        </Link>
      </p>
    </AuthCard>
  );
}
