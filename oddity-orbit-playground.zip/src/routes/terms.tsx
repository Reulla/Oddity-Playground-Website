import { createFileRoute } from "@tanstack/react-router";
import { TermsDocument } from "@/components/auth/terms-document";
import { useT } from "@/lib/preferences";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — ODD.LAB" },
      { name: "description", content: "The rules for using ODD.LAB and its accounts." },
      { property: "og:title", content: "Terms of Service — ODD.LAB" },
      { property: "og:description", content: "The rules for using ODD.LAB and its accounts." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

function Page() {
  const t = useT();
  return (
    <div className="mx-auto w-full max-w-3xl px-4 sm:px-8">
      <section className="pb-6 pt-8 sm:pt-14">
        <p className="label-mono">ODD.LAB</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("terms.title")}
          <span className="text-coral">.</span>
        </h1>
      </section>
      <TermsDocument />
    </div>
  );
}
