import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Shuffle, X } from "lucide-react";
import { oddities, pickRandomOddity, type Oddity, type OddityKind } from "@/lib/oddities";
import { toneDot, toneSoft, type Tone } from "@/lib/tones";
import { useLang, useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";
import { kindLabel, oddityText } from "@/lib/i18n/content";

export const Route = createFileRoute("/oddities")({
  validateSearch: (search: Record<string, unknown>): { discover?: boolean | undefined } => ({
    discover: search["discover"] === true || search["discover"] === "true" ? true : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Oddities Archive — ODD.LAB" },
      {
        name: "description",
        content: "A catalogue of strange facts, fictional mysteries and unusual real discoveries.",
      },
      { property: "og:title", content: "Oddities Archive — ODD.LAB" },
      {
        property: "og:description",
        content: "A catalogue of strange facts, fictional mysteries and unusual real discoveries.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Archive,
});

const KIND_TONE: Record<OddityKind, Tone> = { fact: "sky", mystery: "coral", discovery: "mint" };
type Filter = "all" | OddityKind;
const FILTERS: Filter[] = ["all", "fact", "mystery", "discovery"];

const pad = (n: number) => String(n).padStart(3, "0");

function KindBadge({ kind }: { kind: OddityKind }) {
  const lang = useLang();
  return (
    <span className="label-mono inline-flex items-center gap-1.5">
      <span className={`size-1.5 rounded-full ${toneDot[KIND_TONE[kind]]}`} />
      {kindLabel(lang, kind)}
    </span>
  );
}

function Archive() {
  const { discover } = Route.useSearch();
  const t = useT();
  const lang = useLang();
  const [filter, setFilter] = useState<Filter>("all");
  const [featured, setFeatured] = useState<Oddity | null>(null);
  const [draws, setDraws] = useState(0);
  const featuredRef = useRef<HTMLDivElement>(null);
  const { award } = useRewards();
  useEffect(() => {
    if (featured) void award("oddity", String(featured.id));
  }, [featured, award]);

  const list = useMemo(
    () => (filter === "all" ? oddities : oddities.filter((o) => o.kind === filter)),
    [filter],
  );

  const drawRandom = () => {
    const pick = pickRandomOddity(list, featured?.id);
    if (!pick) return;
    setFeatured(pick);
    setDraws((d) => d + 1);
    requestAnimationFrame(() =>
      featuredRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }),
    );
  };

  // Arriving from "Random Discovery" draws one straight away
  useEffect(() => {
    if (discover) {
      setFeatured(pickRandomOddity(oddities) ?? null);
      setDraws(1);
    }
  }, [discover]);

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <section className="pb-8 pt-8 sm:pt-14">
        <p className="label-mono">{t("odd.eyebrow", { n: oddities.length })}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("odd.title")}<span className="text-coral">.</span>
        </h1>
        <p className="mt-4 max-w-xl text-muted-foreground">
          {t("odd.intro")}
        </p>
      </section>

      <div ref={featuredRef} className="scroll-mt-6">
        <div className="rounded-3xl border bg-card p-6 shadow-soft sm:p-10">
          {featured ? (
            <div key={`${featured.id}-${draws}`} className="animate-fade-up">
              <div className="flex items-center justify-between gap-3">
                <KindBadge kind={featured.kind} />
                <span className="label-mono">{t("odd.entry", { id: pad(featured.id) })}</span>
              </div>
              <h2 className="mt-5 text-3xl font-extrabold sm:text-4xl">{oddityText(lang, featured).title}</h2>
              <p className="mt-3 max-w-2xl text-lg leading-relaxed text-muted-foreground">
                {oddityText(lang, featured).body}
              </p>
            </div>
          ) : (
            <div>
              <p className="label-mono">{t("odd.randomLabel")}</p>
              <h2 className="mt-5 text-3xl font-extrabold sm:text-4xl">
                {t("odd.reachTitle")}<span className="animate-blink">_</span>
              </h2>
              <p className="mt-3 max-w-2xl text-lg text-muted-foreground">
                {t("odd.reachText")}
              </p>
            </div>
          )}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={drawRandom}
              className="group inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground shadow-lift transition-transform duration-200 hover:-translate-y-0.5 active:scale-[0.98]"
            >
              <Shuffle className="size-4 transition-transform duration-300 group-hover:rotate-12" />
              {featured ? t("odd.another") : t("odd.random")}
            </button>
            {featured && (
              <button
                type="button"
                onClick={() => setFeatured(null)}
                className="inline-flex h-11 items-center gap-1.5 rounded-full px-4 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <X className="size-4" /> {t("odd.putBack")}
              </button>
            )}
            {draws > 0 && <span className="label-mono ml-auto">{t("odd.draws", { n: draws })}</span>}
          </div>
        </div>
      </div>

      <div className="mt-12 flex flex-wrap items-center gap-2 border-b pb-4">
        {FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            aria-pressed={filter === f}
            className={`h-9 rounded-full border px-4 text-sm font-medium transition-all duration-200 ${
              filter === f
                ? "border-primary bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            {t(`odd.filter.${f}`)}
          </button>
        ))}
        <span className="label-mono ml-auto">{t("odd.shown", { n: list.length })}</span>
      </div>

      <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((o, i) => (
          <li
            key={`${filter}-${o.id}`}
            className={`animate-fade-up rounded-2xl border bg-card p-5 transition-all duration-300 ${
              featured?.id === o.id ? "border-foreground/40 shadow-lift" : "shadow-soft"
            }`}
            style={{ animationDelay: `${Math.min(i, 12) * 30}ms` }}
          >
            <div className="flex items-center justify-between">
              <KindBadge kind={o.kind} />
              <span className="font-mono text-[0.7rem] text-muted-foreground">#{pad(o.id)}</span>
            </div>
            <h3 className="mt-4 text-lg font-bold leading-snug">{oddityText(lang, o).title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{oddityText(lang, o).body}</p>
            {o.kind === "mystery" && (
              <span className={`mt-4 inline-block rounded-full px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-wider ${toneSoft.coral}`}>
                {t("odd.fiction")}
              </span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
