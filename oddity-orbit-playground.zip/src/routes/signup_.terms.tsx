import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { FormMessage, PrimaryButton, authErrorKey } from "@/components/auth/auth-ui";
import { TermsDocument } from "@/components/auth/terms-document";
import { supabase } from "@/integrations/supabase/client";
import { setRememberMe } from "@/lib/auth";
import type { MessageKey } from "@/lib/i18n/en";
import { useT } from "@/lib/preferences";
import { signupStore, type PendingSignup } from "@/lib/signup-store";
import { TERMS_VERSION } from "@/lib/terms";

export const Route = createFileRoute("/signup_/terms")({
  head: () => ({
    meta: [
      { title: "Accept the terms — ODD.LAB" },
      { name: "description", content: "Review and accept the ODD.LAB Terms of Service and Privacy Policy to finish creating your account." },
      { property: "og:title", content: "Accept the terms — ODD.LAB" },
      { property: "og:description", content: "Review the Terms of Service and Privacy Policy to finish signing up." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SignupTerms,
});

function SignupTerms() {
  const t = useT();
  const navigate = useNavigate();
  const [pending, setPending] = useState<PendingSignup | null>(null);
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<MessageKey | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setPending(signupStore.get());
    setLoaded(true);
  }, []);

  const back = (err?: Parameters<typeof signupStore.setError>[0]) => {
    if (err) signupStore.setError(err);
    navigate({ to: "/signup" });
  };

  const accept = async () => {
    if (!pending || !checked) return;
    setBusy(true);
    setError(null);
    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: pending.email,
        password: pending.password,
        options: {
          emailRedirectTo: window.location.origin,
          data: { username: pending.username, tos_version: TERMS_VERSION },
        },
      });
      if (signUpError) {
        const msg = signUpError.message.toLowerCase();
        if (msg.includes("database error") || msg.includes("duplicate")) return back({ field: "username", key: "err.usernameTaken" });
        if (msg.includes("already registered") || signUpError.code === "user_already_exists")
          return back({ field: "email", key: "err.emailTaken" });
        setError(authErrorKey(signUpError));
        return;
      }
      // An existing email comes back as a user with no identities.
      if (data.user && (data.user.identities?.length ?? 0) === 0) return back({ field: "email", key: "err.emailTaken" });
      signupStore.clear();
      if (data.session) {
        setRememberMe(true);
        toast.success(t("toast.welcome", { name: pending.username }));
      } else {
        toast.success(t("toast.registered"), { duration: 8000 });
      }
      navigate({ to: "/", replace: true });
    } catch {
      setError("err.generic");
    } finally {
      setBusy(false);
    }
  };

  if (loaded && !pending) {
    return (
      <div className="mx-auto w-full max-w-md px-4 pt-14">
        <FormMessage tone="error">{t("err.signupExpired")}</FormMessage>
        <Link to="/signup" className="mt-4 inline-block text-sm font-medium underline underline-offset-4">
          {t("auth.createAccount")}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pt-8 sm:px-8 sm:pt-14">
      <p className="label-mono">{t("auth.step", { n: 2 })}</p>
      <h1 className="mt-3 text-4xl font-extrabold sm:text-5xl">
        {t("terms.acceptTitle")}
        <span className="text-coral">.</span>
      </h1>
      <p className="mt-3 max-w-xl text-muted-foreground">{t("terms.acceptSub")}</p>
      {pending && (
        <p className="mt-2 font-mono text-xs text-muted-foreground">
          {t("terms.creatingFor", { name: pending.username, email: pending.email })}
        </p>
      )}

      <div className="mt-8 max-h-[55vh] overflow-y-auto rounded-3xl border bg-card p-6 shadow-soft sm:p-8">
        <h2 className="text-2xl font-extrabold">{t("terms.title")}</h2>
        <div className="mt-4">
          <TermsDocument />
        </div>
      </div>

      <div className="mt-6 space-y-4 rounded-3xl border bg-card p-6 shadow-soft">
        {error && <FormMessage tone="error">{t(error)}</FormMessage>}
        <label className="flex cursor-pointer items-start gap-3 text-sm leading-relaxed">
          <Checkbox className="mt-0.5" checked={checked} onCheckedChange={(v) => setChecked(v === true)} />
          <span>{t("terms.checkbox")}</span>
        </label>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            onClick={() => back()}
            className="h-11 rounded-full px-5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("terms.back")}
          </button>
          <PrimaryButton type="button" className="sm:w-auto" disabled={!checked || busy || !pending} onClick={accept}>
            {busy ? t("terms.creating") : t("terms.accept")}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}
