import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { AuthCard, Field, FormMessage, PrimaryButton, authErrorKey } from "@/components/auth/auth-ui";
import { supabase } from "@/integrations/supabase/client";
import type { MessageKey } from "@/lib/i18n/en";
import { useT } from "@/lib/preferences";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset your password — ODD.LAB" },
      { name: "description", content: "Get a secure link to reset your ODD.LAB password." },
      { property: "og:title", content: "Reset your password — ODD.LAB" },
      { property: "og:description", content: "Get a secure link to reset your ODD.LAB password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ForgotPassword,
});

function ForgotPassword() {
  const t = useT();
  const [email, setEmail] = useState("");
  const [error, setError] = useState<MessageKey | null>(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = z.string().trim().email().max(255).safeParse(email);
    if (!parsed.success) {
      setError("err.emailInvalid");
      return;
    }
    setError(null);
    setBusy(true);
    const { error: err } = await supabase.auth.resetPasswordForEmail(parsed.data, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    // Same message whether or not the account exists.
    if (err && err.status === 429) setError(authErrorKey(err));
    else setSent(true);
  };

  return (
    <AuthCard title={t("forgot.title")} sub={t("forgot.sub")}>
      {sent ? (
        <FormMessage tone="success">{t("forgot.sent")}</FormMessage>
      ) : (
        <form onSubmit={submit} noValidate className="space-y-4">
          <Field
            label={t("auth.email")}
            name="email"
            type="email"
            autoComplete="email"
            maxLength={255}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            error={error ? t(error) : undefined}
          />
          <PrimaryButton type="submit" disabled={busy}>
            {busy ? t("forgot.sending") : t("forgot.send")}
          </PrimaryButton>
        </form>
      )}
      <p className="mt-6 text-center text-sm">
        <Link to="/auth" search={{ redirect: undefined }} className="text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
          {t("forgot.back")}
        </Link>
      </p>
    </AuthCard>
  );
}
