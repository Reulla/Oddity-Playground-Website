import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Lock, Trophy } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/lib/auth";
import { formatDate, useLang, useT } from "@/lib/preferences";
import { getMyStats, type MyStats } from "@/lib/progress.functions";
import { EASTER_EGGS, EXPERIMENT_IDS, REWARD_KINDS, type Rarity } from "@/lib/rewards";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/score")({
  head: () => ({
    meta: [
      { title: "Score & Achievements — ODD.LAB" },
      { name: "description", content: "Your ODD.LAB score, discoveries and achievements — from common to legendary." },
      { property: "og:title", content: "Score & Achievements — ODD.LAB" },
      { property: "og:description", content: "Collect points and unlock achievements across every experiment." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ScorePage,
});

const RARITY_STYLE: Record<Rarity, string> = {
  common: "bg-muted text-muted-foreground",
  uncommon: "bg-mint/25 text-foreground",
  rare: "bg-sky/25 text-foreground",
  epic: "bg-coral/20 text-foreground",
  legendary: "bg-sun/40 text-foreground",
};

function Stat({ label, value, accent }: { label: string; value: React.ReactNode; accent?: string }) {
  return (
    <div className="rounded-2xl border bg-card p-4 shadow-soft">
      <p className="label-mono">{label}</p>
      <p className={cn("mt-2 font-display text-3xl font-extrabold", accent)}>{value}</p>
    </div>
  );
}

function ScorePage() {
  const t = useT();
  const lang = useLang();
  const { ready, user, termsOk } = useAuth();
  const fetchStats = useServerFn(getMyStats);
  const { data, isLoading, isError, refetch } = useQuery<MyStats>({
    queryKey: ["my-stats", user?.id],
    queryFn: () => fetchStats(),
    enabled: !!user,
  });

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <section className="pb-8 pt-8 sm:pt-14">
        <p className="label-mono">{t("score.eyebrow")}</p>
        <h1 className="mt-3 text-4xl font-extrabold sm:text-6xl">
          {t("score.title")}
          <span className="text-coral">.</span>
        </h1>
      </section>

      {ready && !user && (
        <div className="rounded-3xl border bg-card p-6 shadow-soft sm:p-10">
          <Trophy className="size-8 text-sun" />
          <h2 className="mt-4 text-2xl font-extrabold">{t("score.signedOutTitle")}</h2>
          <p className="mt-2 max-w-lg text-muted-foreground">{t("score.signedOutText")}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/auth" search={{ redirect: "/score" }} className="inline-flex h-11 items-center rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground">
              {t("settings.signIn")}
            </Link>
            <Link to="/signup" className="inline-flex h-11 items-center rounded-full border bg-card px-5 text-sm font-medium">
              {t("auth.createAccount")}
            </Link>
          </div>
        </div>
      )}

      {user && !termsOk && ready && (
        <p className="mb-6 rounded-2xl border border-sun bg-sun/20 px-4 py-3 text-sm">{t("terms.needed")}</p>
      )}

      {user && isLoading && <p className="text-muted-foreground">{t("common.loading")}</p>}
      {user && isError && (
        <button type="button" onClick={() => refetch()} className="text-sm underline">
          {t("admin.error")}
        </button>
      )}

      {data && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-5">
            <div className="col-span-2 lg:col-span-1">
              <Stat label={t("score.total")} value={data.totalScore.toLocaleString()} accent="text-coral" />
            </div>
            <Stat label={t("score.experiments")} value={`${data.experiments}/${EXPERIMENT_IDS.length}`} />
            <Stat label={t("score.discoveries")} value={data.discoveries} />
            <Stat label={t("score.achievements")} value={`${data.unlockedCount}/${data.achievements.length}`} />
            <Stat label={t("score.joined")} value={<span className="text-xl">{formatDate(lang, data.joinedAt)}</span>} />
          </div>
          <p className="mt-3 font-mono text-xs text-muted-foreground">
            {t("score.eggs")} · {data.eggs}/{EASTER_EGGS.length}
          </p>

          <section className="mt-12">
            <div className="mb-5 flex items-baseline justify-between border-b pb-3">
              <h2 className="text-lg font-bold">{t("score.progress")}</h2>
              <span className="label-mono">
                {data.unlockedCount} {t("score.unlocked").toLowerCase()}
              </span>
            </div>
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {data.achievements.map((a) => {
                const unlocked = !!a.unlockedAt;
                return (
                  <li
                    key={a.id}
                    className={cn(
                      "flex flex-col rounded-2xl border bg-card p-5 shadow-soft transition-opacity",
                      !unlocked && "opacity-80",
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className={cn("rounded-full px-2.5 py-0.5 font-mono text-[0.65rem] uppercase tracking-wider", RARITY_STYLE[a.rarity as Rarity])}>
                        {t(`rarity.${a.rarity as Rarity}`)}
                      </span>
                      <span className="font-mono text-xs text-muted-foreground">{t("score.pts", { n: a.points })}</span>
                    </div>
                    <h3 className="mt-4 flex items-center gap-2 text-lg font-bold">
                      {unlocked ? <Trophy className="size-4 text-sun" /> : <Lock className="size-4 text-muted-foreground" />}
                      {lang === "id" ? a.title_id : a.title_en}
                    </h3>
                    <p className="mt-1.5 text-sm text-muted-foreground">{lang === "id" ? a.description_id : a.description_en}</p>
                    <div className="mt-auto pt-5">
                      {a.target > 1 && (
                        <div className="mb-2 flex items-center gap-3">
                          <Progress value={(a.progress / a.target) * 100} className="h-1.5" />
                          <span className="shrink-0 font-mono text-xs text-muted-foreground">
                            {a.progress}/{a.target}
                          </span>
                        </div>
                      )}
                      <p className="label-mono">
                        {unlocked ? t("score.unlockedOn", { date: formatDate(lang, a.unlockedAt) }) : t("score.locked")}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>

          <section className="mt-12 rounded-3xl border bg-card p-6 shadow-soft">
            <h2 className="text-lg font-bold">{t("score.howTitle")}</h2>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {REWARD_KINDS.map((k) => (
                <li key={k} className="flex items-center justify-between gap-3 rounded-xl bg-muted/60 px-4 py-2.5 text-sm">
                  {t(`score.how.${k}`)}
                  <span className="font-mono text-xs">+{data.rules.find((r) => r.kind === k)?.points ?? 0}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-muted-foreground">{t("score.howNote")}</p>
          </section>
        </>
      )}
    </div>
  );
}
