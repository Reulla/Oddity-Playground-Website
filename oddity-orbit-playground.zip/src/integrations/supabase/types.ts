export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          active: boolean
          created_at: string
          description_en: string
          description_id: string
          id: string
          metric: string
          points: number
          rarity: string
          sort: number
          target: number
          title_en: string
          title_id: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description_en: string
          description_id: string
          id: string
          metric: string
          points?: number
          rarity: string
          sort?: number
          target: number
          title_en: string
          title_id: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description_en?: string
          description_id?: string
          id?: string
          metric?: string
          points?: number
          rarity?: string
          sort?: number
          target?: number
          title_en?: string
          title_id?: string
        }
        Relationships: []
      }
      activity_events: {
        Row: {
          created_at: string
          id: number
          item_id: string | null
          kind: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: never
          item_id?: string | null
          kind: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: never
          item_id?: string | null
          kind?: string
          user_id?: string | null
        }
        Relationships: []
      }
      admin_audit_log: {
        Row: {
          action: string
          admin_id: string
          created_at: string
          details: Json
          id: number
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string
          details?: Json
          id?: never
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string
          details?: Json
          id?: never
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: []
      }
      custom_oddities: {
        Row: {
          body_en: string
          body_id: string
          created_at: string
          created_by: string | null
          id: string
          kind: string
          published: boolean
          title_en: string
          title_id: string
          updated_at: string
        }
        Insert: {
          body_en: string
          body_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          kind: string
          published?: boolean
          title_en: string
          title_id: string
          updated_at?: string
        }
        Update: {
          body_en?: string
          body_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          kind?: string
          published?: boolean
          title_en?: string
          title_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      daily_active: {
        Row: {
          day: string
          user_id: string
        }
        Insert: {
          day?: string
          user_id: string
        }
        Update: {
          day?: string
          user_id?: string
        }
        Relationships: []
      }
      game_rounds: {
        Row: {
          correct: boolean | null
          created_at: string
          deadline: string
          difficulty: number
          finished_at: string | null
          guess: string | null
          id: string
          lang: string
          messages: Json
          minutes: number
          persona: string
          user_id: string
        }
        Insert: {
          correct?: boolean | null
          created_at?: string
          deadline: string
          difficulty: number
          finished_at?: string | null
          guess?: string | null
          id?: string
          lang: string
          messages?: Json
          minutes: number
          persona: string
          user_id: string
        }
        Update: {
          correct?: boolean | null
          created_at?: string
          deadline?: string
          difficulty?: number
          finished_at?: string | null
          guess?: string | null
          id?: string
          lang?: string
          messages?: Json
          minutes?: number
          persona?: string
          user_id?: string
        }
        Relationships: []
      }
      inbox_messages: {
        Row: {
          body: string
          created_at: string
          id: string
          kind: string
          read_at: string | null
          sender_id: string | null
          title: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          sender_id?: string | null
          title: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          sender_id?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      moderation_actions: {
        Row: {
          action: string
          admin_id: string
          created_at: string
          expires_at: string | null
          id: string
          reason: string
          user_id: string
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string
          expires_at?: string | null
          id?: string
          reason: string
          user_id: string
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
          last_seen_at: string | null
          preferences: Json
          status: string
          suspended_until: string | null
          timeout_until: string | null
          updated_at: string
          username: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id: string
          last_seen_at?: string | null
          preferences?: Json
          status?: string
          suspended_until?: string | null
          timeout_until?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          last_seen_at?: string | null
          preferences?: Json
          status?: string
          suspended_until?: string | null
          timeout_until?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      score_rules: {
        Row: {
          kind: string
          points: number
          updated_at: string
        }
        Insert: {
          kind: string
          points: number
          updated_at?: string
        }
        Update: {
          kind?: string
          points?: number
          updated_at?: string
        }
        Relationships: []
      }
      terms_acceptances: {
        Row: {
          accepted_at: string
          id: string
          user_id: string
          version: string
        }
        Insert: {
          accepted_at?: string
          id?: string
          user_id: string
          version: string
        }
        Update: {
          accepted_at?: string
          id?: string
          user_id?: string
          version?: string
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          points: number
          unlocked_at: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          points?: number
          unlocked_at?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          points?: number
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
        ]
      }
      user_rewards: {
        Row: {
          created_at: string
          id: string
          item_id: string
          kind: string
          points: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_id: string
          kind: string
          points?: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_id?: string
          kind?: string
          points?: number
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_current_terms: { Args: never; Returns: string }
      admin_list_users: {
        Args: { _limit: number; _offset: number; _search: string }
        Returns: {
          avatar_url: string
          created_at: string
          display_name: string
          email: string
          id: string
          is_admin: boolean
          last_seen_at: string
          last_sign_in_at: string
          score: number
          status: string
          total_count: number
          username: string
        }[]
      }
      admin_stats: { Args: never; Returns: Json }
      clear_expired_moderation: { Args: never; Returns: undefined }
      current_terms_version: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      metric_count: {
        Args: { _metric: string; _user_id: string }
        Returns: number
      }
      record_reward: {
        Args: { _item_id: string; _kind: string; _user_id: string }
        Returns: Json
      }
      sync_achievements: { Args: { _user_id: string }; Returns: Json }
      touch_presence: { Args: never; Returns: undefined }
      username_available: { Args: { _username: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
