import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ChevronRight, KeyRound, LogOut, Settings, ShieldCheck, Trophy, User, UserCog } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth, useSignOut } from "@/lib/auth";
import { useT } from "@/lib/preferences";
import { AppearanceControl, LanguageControl, Row, TextSizeControl } from "./preference-controls";
import { UserAvatar } from "./user-avatar";
import { usePreferences } from "@/lib/preferences";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="label-mono mb-3">{title}</h3>
      {children}
    </section>
  );
}

const itemClass =
  "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors hover:bg-muted";

export function SettingsPanel() {
  const [open, setOpen] = useState(false);
  const t = useT();
  const { prefs } = usePreferences();
  const { user, profile, avatarUrl, isAdmin } = useAuth();
  const signOut = useSignOut();
  const navigate = useNavigate();
  const close = () => setOpen(false);

  const logOut = async () => {
    close();
    await signOut();
    toast(t("toast.signedOut"));
    navigate({ to: "/auth", search: { redirect: undefined }, replace: true });
  };

  const name = profile?.display_name || profile?.username || user?.email || "";

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          type="button"
          aria-label={t("nav.settings")}
          className="group ml-1 grid size-9 shrink-0 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-card hover:text-foreground hover:shadow-soft"
        >
          <Settings className="size-[18px] transition-transform duration-500 group-hover:rotate-90" />
        </button>
      </SheetTrigger>
      <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-sm">
        <SheetHeader className="border-b px-6 py-5 text-left">
          <SheetTitle className="font-display text-xl font-extrabold">
            {t("settings.title")}
            <span className="text-coral">.</span>
          </SheetTitle>
          <SheetDescription>{t("settings.desc")}</SheetDescription>
        </SheetHeader>

        <div className="flex-1 space-y-7 overflow-y-auto px-6 py-6">
          <Section title={t("settings.general")}>
            <Row label={t("settings.language")}>
              <LanguageControl />
            </Row>
          </Section>
          <Section title={t("settings.device")}>
            <div className="space-y-5">
              <Row label={t("settings.appearance")}>
                <AppearanceControl />
              </Row>
              <Row label={t("settings.textSize")} value={t(`settings.size.${prefs.textSize}`)}>
                <TextSizeControl />
              </Row>
            </div>
          </Section>
          <Section title={t("settings.legal")}>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
              <Link to="/terms" onClick={close} className="underline-offset-4 hover:underline">
                {t("terms.title")}
              </Link>
              <Link to="/privacy" onClick={close} className="underline-offset-4 hover:underline">
                {t("terms.privacyTitle")}
              </Link>
            </div>
          </Section>
        </div>

        <div className="border-t bg-muted/40 px-4 py-4">
          <h3 className="label-mono mb-2 px-2">{t("settings.account")}</h3>
          {user ? (
            <div>
              <div className="mb-2 flex items-center gap-3 px-2 py-1">
                <UserAvatar name={name} url={avatarUrl} />
                <div className="min-w-0">
                  <p className="truncate font-medium">{name}</p>
                  {profile && <p className="truncate font-mono text-xs text-muted-foreground">@{profile.username}</p>}
                </div>
              </div>
              <nav className="space-y-0.5">
                <Link to="/profile" search={{ tab: "profile" }} onClick={close} className={itemClass}>
                  <User className="size-4 text-muted-foreground" /> {t("settings.profile")}
                  <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                </Link>
                <Link to="/profile" search={{ tab: "account" }} onClick={close} className={itemClass}>
                  <UserCog className="size-4 text-muted-foreground" /> {t("settings.accountInfo")}
                  <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                </Link>
                <Link to="/profile" search={{ tab: "password" }} onClick={close} className={itemClass}>
                  <KeyRound className="size-4 text-muted-foreground" /> {t("settings.changePassword")}
                  <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                </Link>
                <Link to="/score" onClick={close} className={itemClass}>
                  <Trophy className="size-4 text-muted-foreground" /> {t("settings.score")}
                  <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                </Link>
                {isAdmin && (
                  <Link to="/admin" onClick={close} className={itemClass}>
                    <ShieldCheck className="size-4 text-coral" /> {t("settings.admin")}
                    <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                  </Link>
                )}
                <button type="button" onClick={logOut} className={`${itemClass} text-destructive`}>
                  <LogOut className="size-4" /> {t("settings.logout")}
                </button>
              </nav>
            </div>
          ) : (
            <div className="px-2">
              <p className="mb-3 text-sm text-muted-foreground">{t("settings.guest")}</p>
              <div className="grid gap-2">
                <Link
                  to="/auth"
                  search={{ redirect: undefined }}
                  onClick={close}
                  className="inline-flex h-10 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground transition-transform hover:-translate-y-0.5"
                >
                  {t("settings.signIn")}
                </Link>
                <Link
                  to="/signup"
                  onClick={close}
                  className="inline-flex h-10 items-center justify-center rounded-full border bg-card text-sm font-medium transition-colors hover:bg-muted"
                >
                  {t("settings.signUp")}
                </Link>
              </div>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
