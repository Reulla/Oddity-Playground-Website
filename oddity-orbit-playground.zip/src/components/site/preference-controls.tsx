import { Moon, Sun } from "lucide-react";
import { TEXT_SIZES, usePreferences, type TextSize } from "@/lib/preferences";
import { Segmented } from "./segmented";

const SIZE_GLYPH: Record<TextSize, string> = { sm: "text-xs", md: "text-sm", lg: "text-base", xl: "text-lg" };

export function LanguageControl() {
  const { prefs, setPrefs, t } = usePreferences();
  return (
    <Segmented
      label={t("settings.language")}
      value={prefs.lang}
      onChange={(lang) => setPrefs({ lang })}
      options={[
        { value: "en", label: "English" },
        { value: "id", label: "Indonesia" },
      ]}
    />
  );
}

export function AppearanceControl() {
  const { prefs, setPrefs, t } = usePreferences();
  return (
    <Segmented
      label={t("settings.appearance")}
      value={prefs.theme}
      onChange={(theme) => setPrefs({ theme })}
      options={[
        { value: "light", label: <><Sun className="size-3.5" /> {t("settings.light")}</> },
        { value: "dark", label: <><Moon className="size-3.5" /> {t("settings.dark")}</> },
      ]}
    />
  );
}

export function TextSizeControl() {
  const { prefs, setPrefs, t } = usePreferences();
  return (
    <Segmented
      label={t("settings.textSize")}
      value={prefs.textSize}
      onChange={(textSize) => setPrefs({ textSize })}
      options={TEXT_SIZES.map((s) => ({
        value: s,
        title: t(`settings.size.${s}`),
        label: (
          <>
            <span className={`font-display font-bold ${SIZE_GLYPH[s]}`} aria-hidden>
              A
            </span>
            <span className="sr-only">{t(`settings.size.${s}`)}</span>
          </>
        ),
      }))}
    />
  );
}

export function PreferenceRows() {
  const { prefs, t } = usePreferences();
  return (
    <div className="space-y-5">
      <Row label={t("settings.language")}>
        <LanguageControl />
      </Row>
      <Row label={t("settings.appearance")}>
        <AppearanceControl />
      </Row>
      <Row label={t("settings.textSize")} value={t(`settings.size.${prefs.textSize}`)}>
        <TextSizeControl />
      </Row>
    </div>
  );
}

export function Row({ label, value, children }: { label: string; value?: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <span className="text-sm font-medium">{label}</span>
        {value && <span className="label-mono">{value}</span>}
      </div>
      {children}
    </div>
  );
}
