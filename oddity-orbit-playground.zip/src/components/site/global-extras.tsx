import { useEffect } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { ScrollText } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";

const KONAMI = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];

/** Hidden interaction: the Konami code, anywhere on the site. */
export function KonamiListener() {
  const { award } = useRewards();
  useEffect(() => {
    let pos = 0;
    const onKey = (e: KeyboardEvent) => {
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      pos = key === KONAMI[pos] ? pos + 1 : key === KONAMI[0] ? 1 : 0;
      if (pos === KONAMI.length) {
        pos = 0;
        document.documentElement.animate(
          [{ transform: "rotate(0)" }, { transform: "rotate(2deg)" }, { transform: "rotate(-2deg)" }, { transform: "rotate(0)" }],
          { duration: 600 },
        );
        void award("easter_egg", "konami");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [award]);
  return null;
}

/** Shown to signed-in users who haven't accepted the current Terms version. */
export function TermsBanner() {
  const { ready, user, profile, termsOk } = useAuth();
  const t = useT();
  const { pathname } = useLocation();
  if (!ready || !user || !profile || termsOk) return null;
  if (pathname.startsWith("/terms-update") || pathname.startsWith("/signup")) return null;
  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-8">
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-sun bg-sun/20 px-4 py-3 text-sm">
        <ScrollText className="size-4 shrink-0" />
        <span className="font-medium">{t("terms.updatedTitle")}</span>
        <span className="text-muted-foreground">{t("terms.updatedSub")}</span>
        <Link to="/terms-update" className="ml-auto rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
          {t("terms.review")}
        </Link>
      </div>
    </div>
  );
}
