import { cn } from "@/lib/utils";

export function UserAvatar({
  name,
  url,
  className,
}: {
  name: string;
  url?: string | null;
  className?: string;
}) {
  const initials = name.slice(0, 2).toUpperCase();
  return (
    <span
      className={cn(
        "grid size-10 shrink-0 place-items-center overflow-hidden rounded-full border bg-sun/30 font-display text-sm font-bold text-foreground",
        className,
      )}
    >
      {url ? <img src={url} alt="" className="size-full object-cover" /> : initials}
    </span>
  );
}
