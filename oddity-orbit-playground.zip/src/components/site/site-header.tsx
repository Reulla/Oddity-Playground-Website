import { useRef } from "react";
import { Link } from "@tanstack/react-router";
import { useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";
import { Mail } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useInbox } from "@/lib/use-inbox";
import { SettingsPanel } from "./settings-panel";

const NAV = [
  { to: "/lab", label: "nav.lab", short: "nav.labShort", mobile: true },
  { to: "/button", label: "nav.button", short: "nav.buttonShort", mobile: true },
  { to: "/oddities", label: "nav.archive", short: "nav.archiveShort", mobile: true },
  { to: "/human-or-not", label: "nav.human", short: "nav.humanShort", mobile: true },
  { to: "/score", label: "nav.score", short: "nav.score", mobile: false },
] as const;

export function Logo() {
  return (
    <span className="font-display text-xl font-extrabold tracking-tight">
      ODD<span className="text-coral">.</span>LAB
    </span>
  );
}

export function SiteHeader() {
  const t = useT();
  const { award } = useRewards();
  const clicks = useRef<number[]>([]);

  // Hidden interaction: click the logo five times within two seconds.
  const onLogoClick = () => {
    const now = Date.now();
    clicks.current = [...clicks.current.filter((c) => now - c < 2000), now];
    if (clicks.current.length >= 5) {
      clicks.current = [];
      void award("easter_egg", "logo-spinner");
    }
  };

  return (
    <header className="mx-auto flex w-full max-w-5xl items-center justify-between gap-2 px-4 py-5 sm:px-8">
      <Link to="/" onClick={onLogoClick} className="group flex items-center gap-2" aria-label={t("nav.home")}>
        <span className="relative grid size-7 place-items-center rounded-full border-2 border-foreground transition-transform duration-500 group-hover:rotate-180">
          <span className="size-2 rounded-full bg-coral" />
        </span>
        <Logo />
      </Link>
      <nav className="flex items-center gap-0.5 sm:gap-1">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            className={`whitespace-nowrap rounded-full px-2.5 py-1.5 text-[0.8rem] text-muted-foreground transition-colors hover:text-foreground sm:px-3 sm:text-sm ${
              n.mobile ? "" : "hidden md:inline-block"
            }`}
            activeProps={{ className: "bg-card text-foreground shadow-soft" }}
          >
            <span className="sm:hidden">{t(n.short)}</span>
            <span className="hidden sm:inline">{t(n.label)}</span>
          </Link>
        ))}
        <InboxLink />
        <SettingsPanel />
      </nav>
    </header>
  );
}

function InboxLink() {
  const t = useT();
  const { user } = useAuth();
  const { data } = useInbox();
  if (!user) return null;
  const unread = (data ?? []).filter((m) => !m.read_at).length;
  return (
    <Link to="/inbox" aria-label={t("nav.inbox")} className="relative grid size-9 place-items-center rounded-full text-muted-foreground hover:text-foreground">
      <Mail className="size-[1.1rem]" />
      {unread > 0 && (
        <span className="absolute -right-0.5 -top-0.5 grid min-w-4 place-items-center rounded-full bg-coral px-1 text-[0.6rem] font-bold text-primary-foreground">
          {unread > 9 ? "9+" : unread}
        </span>
      )}
    </Link>
  );
}

export function SiteFooter() {
  const t = useT();
  return (
    <footer className="mx-auto mt-24 flex w-full max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-5 pb-10 pt-6 sm:px-8">
      <p className="label-mono">{t("footer.tagline")}</p>
      <div className="flex items-center gap-4">
        <Link to="/terms" className="label-mono transition-colors hover:text-foreground">
          {t("footer.terms")}
        </Link>
        <Link to="/privacy" className="label-mono transition-colors hover:text-foreground">
          {t("footer.privacy")}
        </Link>
        <p className="label-mono">{t("footer.touch")}</p>
      </div>
    </footer>
  );
}
