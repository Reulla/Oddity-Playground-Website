import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { adminListUsers, adminModerate, adminUserDetail, type AdminUser } from "@/lib/admin.functions";
import { isTimedOut, type ModAction } from "@/lib/moderation";
import { formatDate, useLang, useT } from "@/lib/preferences";
import type { MessageKey } from "@/lib/i18n/en";
import { ActivityTable } from "./admin-activity";
import { Panel, SmallButton, inputClass, labelClass } from "./admin-ui";

function statusLabel(t: (k: MessageKey) => string, status: string) {
  return ["active", "suspended", "banned"].includes(status) ? t(`admin.status.${status}` as MessageKey) : status;
}

export function AdminUsers() {
  const t = useT();
  const lang = useLang();
  const fetchUsers = useServerFn(adminListUsers);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<AdminUser | null>(null);
  const { data, isLoading, isError } = useQuery({
    queryKey: ["admin", "users", search, page],
    queryFn: () => fetchUsers({ data: { search, page } }),
  });
  const pages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <Panel title={t("admin.tab.users")}>
      <input className={`${inputClass} mb-4`} placeholder={t("admin.search")} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} />
      {isLoading ? (
        <p className="text-muted-foreground">{t("common.loading")}</p>
      ) : isError || !data ? (
        <p className="text-destructive">{t("admin.error")}</p>
      ) : data.users.length === 0 ? (
        <p className="text-muted-foreground">{t("admin.noUsers")}</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="pb-2 pr-3 font-medium">{t("admin.col.user")}</th>
                <th className="pb-2 pr-3 font-medium">{t("admin.col.email")}</th>
                <th className="pb-2 pr-3 font-medium">{t("admin.col.joined")}</th>
                <th className="pb-2 pr-3 font-medium">{t("admin.col.status")}</th>
                <th className="pb-2 pr-3 font-medium">{t("admin.col.score")}</th>
                <th className="pb-2" />
              </tr>
            </thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u.id} className="border-t">
                  <td className="py-2 pr-3 font-medium">
                    {u.username} {u.is_admin && <span className="label-mono text-coral">{t("admin.adminBadge")}</span>}
                  </td>
                  <td className="py-2 pr-3 text-muted-foreground">{u.email}</td>
                  <td className="whitespace-nowrap py-2 pr-3">{formatDate(lang, u.created_at)}</td>
                  <td className="py-2 pr-3">{statusLabel(t, u.status)}</td>
                  <td className="py-2 pr-3">{u.score}</td>
                  <td className="py-2 text-right">
                    <SmallButton onClick={() => setOpen(u)}>{t("admin.mod.open")}</SmallButton>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-4 flex items-center gap-2">
            <SmallButton disabled={page === 0} onClick={() => setPage(page - 1)}>{t("admin.prev")}</SmallButton>
            <span className="label-mono">{t("admin.page", { n: page + 1, total: pages })}</span>
            <SmallButton disabled={page + 1 >= pages} onClick={() => setPage(page + 1)}>{t("admin.next")}</SmallButton>
          </div>
        </div>
      )}
      <Dialog open={!!open} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          {open && <UserModeration user={open} />}
        </DialogContent>
      </Dialog>
    </Panel>
  );
}

function UserModeration({ user }: { user: AdminUser }) {
  const t = useT();
  const lang = useLang();
  const queryClient = useQueryClient();
  const fetchDetail = useServerFn(adminUserDetail);
  const moderate = useServerFn(adminModerate);
  const [reason, setReason] = useState("");
  const [minutes, setMinutes] = useState(60);
  const [days, setDays] = useState(7);
  const [busy, setBusy] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "user", user.id],
    queryFn: () => fetchDetail({ data: { userId: user.id } }),
  });

  const run = async (action: ModAction) => {
    if (!reason.trim()) { toast.error(t("admin.invalid")); return; }
    if (action === "ban" && !window.confirm(t("admin.mod.confirmBan", { name: user.username }))) return;
    setBusy(true);
    try {
      await moderate({
        data: { userId: user.id, action, reason: reason.trim(), amount: action === "timeout" ? minutes : action === "suspend" ? days : null },
      });
      toast.success(t("admin.done"));
      setReason("");
      void queryClient.invalidateQueries({ queryKey: ["admin"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("admin.error"));
    } finally {
      setBusy(false);
    }
  };

  const p = data?.profile;
  return (
    <>
      <DialogHeader>
        <DialogTitle>{user.username}</DialogTitle>
      </DialogHeader>
      {isLoading || !data || !p ? (
        <p className="text-muted-foreground">{t("common.loading")}</p>
      ) : (
        <div className="space-y-5 text-sm">
          <p className="text-muted-foreground">
            {user.email} · {t("admin.col.joined")} {formatDate(lang, p.created_at)} · {statusLabel(t, p.status)}
            {p.suspended_until && ` ${t("admin.mod.until", { date: formatDate(lang, p.suspended_until, true) })}`}
            {isTimedOut(p.timeout_until) && ` · ${t("admin.mod.timedOut")} ${t("admin.mod.until", { date: formatDate(lang, p.timeout_until, true) })}`}
          </p>

          {data.isAdmin ? (
            <p className="text-muted-foreground">{t("admin.mod.cantAdmin")}</p>
          ) : (
            <section className="space-y-3 rounded-xl border p-4">
              <h3 className="font-bold">{t("admin.mod.title")}</h3>
              <label className="block">
                <span className={labelClass}>{t("admin.mod.reason")}</span>
                <textarea className={`${inputClass} h-20 py-2`} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} />
              </label>
              <div className="flex flex-wrap gap-2">
                <SmallButton disabled={busy} onClick={() => run("warning")}>{t("admin.mod.warning")}</SmallButton>
                <SmallButton disabled={busy} onClick={() => run("lift")}>{t("admin.mod.lift")}</SmallButton>
              </div>
              <div className="flex flex-wrap items-end gap-2">
                <label>
                  <span className={labelClass}>{t("admin.mod.minutes")}</span>
                  <input type="number" min={10} max={10080} className={`${inputClass} w-32`} value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} />
                </label>
                <SmallButton disabled={busy} onClick={() => run("timeout")}>{t("admin.mod.timeout")}</SmallButton>
              </div>
              <div className="flex flex-wrap items-end gap-2">
                <label>
                  <span className={labelClass}>{t("admin.mod.days")}</span>
                  <input type="number" min={1} max={365} className={`${inputClass} w-32`} value={days} onChange={(e) => setDays(Number(e.target.value))} />
                </label>
                <SmallButton tone="danger" disabled={busy} onClick={() => run("suspend")}>{t("admin.mod.suspend")}</SmallButton>
                <SmallButton tone="danger" disabled={busy} onClick={() => run("ban")}>{t("admin.mod.ban")}</SmallButton>
              </div>
            </section>
          )}

          <section>
            <h3 className="mb-2 font-bold">{t("admin.mod.history")}</h3>
            {data.history.length === 0 ? (
              <p className="text-muted-foreground">{t("admin.mod.noHistory")}</p>
            ) : (
              <ul className="space-y-1">
                {data.history.map((h) => (
                  <li key={h.id} className="border-t pt-1">
                    <span className="text-muted-foreground">{formatDate(lang, h.created_at, true)}</span> · <b>{t(`admin.mod.${h.action}` as MessageKey)}</b>
                    {h.expires_at && ` ${t("admin.mod.until", { date: formatDate(lang, h.expires_at, true) })}`} · {h.admin} — {h.reason}
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section>
            <h3 className="mb-2 font-bold">{t("admin.mod.recent")}</h3>
            <ActivityTable rows={data.activity.map((a) => ({ ...a, username: user.username }))} showUser={false} />
          </section>
        </div>
      )}
    </>
  );
}
