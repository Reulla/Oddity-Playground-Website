import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { adminGetStats } from "@/lib/admin.functions";
import { experiments } from "@/lib/experiments";
import { experimentText } from "@/lib/i18n/content";
import { useLang, useT } from "@/lib/preferences";
import { Panel } from "./admin-ui";

const axis = { fontSize: 11, fill: "var(--muted-foreground)" };
const tooltipStyle = {
  contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 },
  labelStyle: { color: "var(--foreground)" },
};

function StatCard({ label, value }: { label: string; value: number | undefined }) {
  return (
    <div className="rounded-2xl border bg-card p-4 shadow-soft">
      <p className="label-mono">{label}</p>
      <p className="mt-2 font-display text-3xl font-extrabold">{(value ?? 0).toLocaleString()}</p>
    </div>
  );
}

function ChartBox({ children, empty }: { children: React.ReactElement; empty: boolean }) {
  const t = useT();
  if (empty) return <p className="grid h-48 place-items-center text-sm text-muted-foreground">{t("admin.chart.empty")}</p>;
  return (
    <div className="h-48">
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  );
}

const short = (d: string) => d.slice(5);

export function AdminOverview() {
  const t = useT();
  const lang = useLang();
  const fetchStats = useServerFn(adminGetStats);
  const { data, isLoading, isError } = useQuery({ queryKey: ["admin", "stats"], queryFn: () => fetchStats() });

  if (isLoading) return <p className="text-muted-foreground">{t("common.loading")}</p>;
  if (isError || !data) return <p className="text-destructive">{t("admin.error")}</p>;

  const expName = (id: string) => {
    const e = experiments.find((x) => x.id === id);
    return e ? experimentText(lang, e).title : id;
  };
  const popularity = data.experiment_popularity.map((p) => ({ name: expName(p.item), count: p.count }));
  const sum = (rows: { count: number }[]) => rows.reduce((s, r) => s + r.count, 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label={t("admin.stat.users")} value={data.total_users} />
        <StatCard label={t("admin.stat.active24")} value={data.active_24h} />
        <StatCard label={t("admin.stat.active7")} value={data.active_7d} />
        <StatCard label={t("admin.stat.suspended")} value={data.suspended_users} />
        <StatCard label={t("admin.stat.rewards")} value={data.total_rewards} />
        <StatCard label={t("admin.stat.unlocks")} value={data.total_unlocks} />
        <StatCard label={t("admin.stat.events")} value={data.events_7d} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title={t("admin.chart.registrations")} sub={t("admin.chart.daily")}>
          <ChartBox empty={sum(data.registrations_daily) === 0}>
            <BarChart data={data.registrations_daily}>
              <CartesianGrid stroke="var(--border)" vertical={false} />
              <XAxis dataKey="day" tickFormatter={short} tick={axis} interval={6} />
              <YAxis allowDecimals={false} tick={axis} width={28} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="count" fill="var(--coral)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartBox>
        </Panel>
        <Panel title={t("admin.chart.registrations")} sub={t("admin.chart.monthly")}>
          <ChartBox empty={sum(data.registrations_monthly) === 0}>
            <BarChart data={data.registrations_monthly}>
              <CartesianGrid stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tickFormatter={short} tick={axis} />
              <YAxis allowDecimals={false} tick={axis} width={28} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="count" fill="var(--sky)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartBox>
        </Panel>
        <Panel title={t("admin.chart.activity")} sub={t("admin.chart.daily")}>
          <ChartBox empty={sum(data.active_daily) === 0}>
            <LineChart data={data.active_daily}>
              <CartesianGrid stroke="var(--border)" vertical={false} />
              <XAxis dataKey="day" tickFormatter={short} tick={axis} interval={6} />
              <YAxis allowDecimals={false} tick={axis} width={28} />
              <Tooltip {...tooltipStyle} />
              <Line type="monotone" dataKey="count" stroke="var(--mint)" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ChartBox>
        </Panel>
        <Panel title={t("admin.chart.activity")} sub={t("admin.chart.monthly")}>
          <ChartBox empty={sum(data.active_monthly) === 0}>
            <LineChart data={data.active_monthly}>
              <CartesianGrid stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tickFormatter={short} tick={axis} />
              <YAxis allowDecimals={false} tick={axis} width={28} />
              <Tooltip {...tooltipStyle} />
              <Line type="monotone" dataKey="count" stroke="var(--sun)" strokeWidth={2.5} />
            </LineChart>
          </ChartBox>
        </Panel>
        <Panel title={t("admin.chart.popularity")}>
          <ChartBox empty={popularity.length === 0}>
            <BarChart data={popularity} layout="vertical" margin={{ left: 8 }}>
              <CartesianGrid stroke="var(--border)" horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={axis} />
              <YAxis type="category" dataKey="name" tick={axis} width={110} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="count" fill="var(--lime)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ChartBox>
        </Panel>
        <Panel title={t("admin.chart.achievements")}>
          <ChartBox empty={sum(data.achievement_stats) === 0}>
            <BarChart data={data.achievement_stats} layout="vertical" margin={{ left: 8 }}>
              <CartesianGrid stroke="var(--border)" horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={axis} />
              <YAxis type="category" dataKey="title" tick={axis} width={110} interval={0} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="count" fill="var(--coral)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ChartBox>
        </Panel>
      </div>
    </div>
  );
}
