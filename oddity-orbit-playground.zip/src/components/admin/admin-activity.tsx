import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ACTIVITY_KINDS, adminListActivity, type ActivityRow } from "@/lib/admin.functions";
import { formatDate, useLang, useT } from "@/lib/preferences";
import type { MessageKey } from "@/lib/i18n/en";
import { Panel, SmallButton, inputClass, labelClass } from "./admin-ui";

export function activityLabel(t: (k: MessageKey) => string, kind: string) {
  return (ACTIVITY_KINDS as readonly string[]).includes(kind) ? t(`admin.act.k.${kind}` as MessageKey) : kind;
}

export function ActivityTable({ rows, showUser = true }: { rows: Pick<ActivityRow, "id" | "created_at" | "kind" | "item_id" | "username">[]; showUser?: boolean }) {
  const t = useT();
  const lang = useLang();
  if (!rows.length) return <p className="text-sm text-muted-foreground">{t("admin.act.none")}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-t">
              <td className="whitespace-nowrap py-2 pr-3 text-muted-foreground">{formatDate(lang, r.created_at, true)}</td>
              {showUser && <td className="py-2 pr-3 font-medium">{r.username ?? "—"}</td>}
              <td className="py-2 pr-3">{activityLabel(t, r.kind)}</td>
              <td className="py-2 font-mono text-xs text-muted-foreground">{r.item_id ?? ""}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function AdminActivity() {
  const t = useT();
  const fetchActivity = useServerFn(adminListActivity);
  const [username, setUsername] = useState("");
  const [kind, setKind] = useState<"all" | (typeof ACTIVITY_KINDS)[number]>("all");
  const [days, setDays] = useState(7);
  const [page, setPage] = useState(0);
  const { data, isLoading, isError } = useQuery({
    queryKey: ["admin", "activity", username, kind, days, page],
    queryFn: () => fetchActivity({ data: { username, kind, days, page } }),
  });

  return (
    <Panel title={t("admin.tab.activity")}>
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <label>
          <span className={labelClass}>{t("admin.act.filterUser")}</span>
          <input className={inputClass} value={username} onChange={(e) => { setUsername(e.target.value); setPage(0); }} />
        </label>
        <label>
          <span className={labelClass}>{t("admin.act.kind")}</span>
          <select className={inputClass} value={kind} onChange={(e) => { setKind(e.target.value as typeof kind); setPage(0); }}>
            <option value="all">{t("admin.act.all")}</option>
            {ACTIVITY_KINDS.map((k) => (
              <option key={k} value={k}>{activityLabel(t, k)}</option>
            ))}
          </select>
        </label>
        <label>
          <span className={labelClass}>&nbsp;</span>
          <select className={inputClass} value={days} onChange={(e) => { setDays(Number(e.target.value)); setPage(0); }}>
            {[1, 7, 30, 90, 365].map((d) => (
              <option key={d} value={d}>{t("admin.act.days", { n: d })}</option>
            ))}
          </select>
        </label>
      </div>
      {isLoading ? (
        <p className="text-muted-foreground">{t("common.loading")}</p>
      ) : isError || !data ? (
        <p className="text-destructive">{t("admin.error")}</p>
      ) : (
        <>
          <ActivityTable rows={data.rows} />
          <div className="mt-4 flex gap-2">
            {page > 0 && <SmallButton onClick={() => setPage(page - 1)}>{t("admin.prev")}</SmallButton>}
            {data.hasMore && <SmallButton onClick={() => setPage(page + 1)}>{t("admin.next")}</SmallButton>}
          </div>
        </>
      )}
    </Panel>
  );
}
