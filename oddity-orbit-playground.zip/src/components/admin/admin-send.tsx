import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { adminSendMessage } from "@/lib/admin.functions";
import { useT } from "@/lib/preferences";
import { Panel, SmallButton, inputClass, labelClass } from "./admin-ui";

export function AdminSend() {
  const t = useT();
  const send = useServerFn(adminSendMessage);
  const [mode, setMode] = useState<"all" | "one">("one");
  const [username, setUsername] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim() || (mode === "one" && username.trim().length < 3)) { toast.error(t("admin.invalid")); return; }
    setBusy(true);
    try {
      const res = await send({ data: { to: mode === "all" ? "all" : username.trim(), title, body } });
      if (!res.ok) { toast.error(t("admin.send.notFound")); return; }
      toast.success(t("admin.send.sent", { n: res.count }));
      setTitle("");
      setBody("");
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Panel title={t("admin.tab.send")}>
      <form onSubmit={submit} className="max-w-xl space-y-3">
        <div>
          <span className={labelClass}>{t("admin.send.to")}</span>
          <div className="flex gap-2">
            <SmallButton tone={mode === "one" ? "primary" : "default"} onClick={() => setMode("one")}>{t("admin.send.one")}</SmallButton>
            <SmallButton tone={mode === "all" ? "primary" : "default"} onClick={() => setMode("all")}>{t("admin.send.all")}</SmallButton>
          </div>
        </div>
        {mode === "one" && (
          <label className="block">
            <span className={labelClass}>{t("admin.send.username")}</span>
            <input className={inputClass} value={username} onChange={(e) => setUsername(e.target.value)} />
          </label>
        )}
        <label className="block">
          <span className={labelClass}>{t("admin.send.subject")}</span>
          <input className={inputClass} maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <label className="block">
          <span className={labelClass}>{t("admin.send.body")}</span>
          <textarea className={`${inputClass} h-32 py-2`} maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} />
        </label>
        <button type="submit" disabled={busy} className="h-10 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground disabled:opacity-50">
          {t("admin.send.button")}
        </button>
      </form>
    </Panel>
  );
}
