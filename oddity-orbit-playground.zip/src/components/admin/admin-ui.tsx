import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Panel({ title, sub, action, children, className }: { title?: string; sub?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-2xl border bg-card p-5 shadow-soft", className)}>
      {(title || action) && (
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            {title && <h2 className="font-bold">{title}</h2>}
            {sub && <p className="mt-0.5 text-sm text-muted-foreground">{sub}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function SmallButton({ tone = "default", className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { tone?: "default" | "primary" | "danger" }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex h-8 items-center gap-1.5 rounded-full px-3 text-xs font-medium transition-colors disabled:pointer-events-none disabled:opacity-50",
        tone === "primary" && "bg-primary text-primary-foreground hover:bg-primary/90",
        tone === "danger" && "border border-destructive/40 text-destructive hover:bg-destructive/10",
        tone === "default" && "border bg-card hover:bg-muted",
        className,
      )}
      {...props}
    />
  );
}

export const inputClass =
  "h-10 w-full rounded-xl border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40";
export const labelClass = "mb-1 block text-xs font-medium text-muted-foreground";
