import { TERMS_EFFECTIVE, TERMS_SECTIONS, TERMS_VERSION } from "@/lib/terms";
import { formatDate, useLang, useT } from "@/lib/preferences";

export function TermsDocument({ only }: { only?: "privacy" }) {
  const lang = useLang();
  const t = useT();
  const sections = only === "privacy" ? TERMS_SECTIONS.filter((s) => s.privacy) : TERMS_SECTIONS;
  return (
    <div>
      <p className="label-mono">{t("terms.meta", { v: TERMS_VERSION, date: formatDate(lang, TERMS_EFFECTIVE) })}</p>
      <nav aria-label={t("terms.contents")} className="mt-4 flex flex-wrap gap-2">
        {sections.map((s) => (
          <a key={s.id} href={`#${s.id}`} className="rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground">
            {s.title[lang]}
          </a>
        ))}
      </nav>
      <div className="mt-8 space-y-8">
        {sections.map((s) => (
          <section key={s.id} id={s.id} className="scroll-mt-6">
            <h2 className="text-xl font-bold">{s.title[lang]}</h2>
            <ul className="mt-3 space-y-2">
              {s.body[lang].map((p, i) => (
                <li key={i} className="flex gap-3 leading-relaxed text-muted-foreground">
                  <span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-coral" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
