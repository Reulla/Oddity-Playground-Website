import { forwardRef, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function AuthCard({ eyebrow, title, sub, children }: { eyebrow?: string; title: string; sub?: string; children: ReactNode }) {
  return (
    <div className="mx-auto w-full max-w-md px-4 pt-8 sm:pt-14">
      {eyebrow && <p className="label-mono">{eyebrow}</p>}
      <h1 className="mt-3 text-4xl font-extrabold">
        {title}
        <span className="text-coral">.</span>
      </h1>
      {sub && <p className="mt-3 text-muted-foreground">{sub}</p>}
      <div className="mt-8 rounded-3xl border bg-card p-6 shadow-soft sm:p-8">{children}</div>
    </div>
  );
}

type FieldProps = InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string | undefined; hint?: string | undefined };

export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field({ label, error, hint, id, className, ...props }, ref) {
  const inputId = id ?? props.name;
  return (
    <div className="space-y-1.5">
      <label htmlFor={inputId} className="text-sm font-medium">
        {label}
      </label>
      <input
        ref={ref}
        id={inputId}
        aria-invalid={!!error}
        aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
        className={cn(
          "flex h-11 w-full rounded-xl border bg-background px-3.5 text-base outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-foreground/40 focus-visible:ring-2 focus-visible:ring-ring/40 disabled:opacity-60 sm:text-sm",
          error && "border-destructive",
          className,
        )}
        {...props}
      />
      {error ? (
        <p id={`${inputId}-error`} className="text-sm text-destructive">
          {error}
        </p>
      ) : hint ? (
        <p id={`${inputId}-hint`} className="text-xs text-muted-foreground">
          {hint}
        </p>
      ) : null}
    </div>
  );
});

export function FormMessage({ tone, children }: { tone: "error" | "success"; children: ReactNode }) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={cn(
        "rounded-xl border px-3.5 py-2.5 text-sm",
        tone === "error" ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-mint bg-mint/20 text-foreground",
      )}
    >
      {children}
    </div>
  );
}

export function PrimaryButton({ className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn(
        "inline-flex h-11 w-full items-center justify-center rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground shadow-lift transition-all duration-200 hover:-translate-y-0.5 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

/** Only same-site paths are allowed as a post-sign-in destination. */
export function safeRedirect(path: string | undefined) {
  if (!path || !path.startsWith("/") || path.startsWith("//") || path.startsWith("/\\")) return "/";
  return path;
}

/** Maps auth error responses to message keys. */
export function authErrorKey(error: { message?: string | undefined; code?: string | undefined; status?: number | undefined } | null | undefined) {
  const code = error?.code ?? "";
  const msg = (error?.message ?? "").toLowerCase();
  if (code === "user_banned" || msg.includes("banned")) return "err.suspended" as const;
  if (code === "email_not_confirmed" || msg.includes("not confirmed")) return "err.emailNotConfirmed" as const;
  if (code === "invalid_credentials" || msg.includes("invalid login")) return "err.invalidCredentials" as const;
  if (code === "weak_password" && msg.includes("pwned")) return "err.leakedPassword" as const;
  if (code === "weak_password") return "err.passwordWeak" as const;
  if (error?.status === 429 || code.includes("rate_limit")) return "err.rateLimited" as const;
  return "err.generic" as const;
}
