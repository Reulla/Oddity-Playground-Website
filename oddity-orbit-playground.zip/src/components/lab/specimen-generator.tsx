import { useEffect, useRef, useState } from "react";
import { Download, RefreshCw } from "lucide-react";
import { fitCanvas, readPalette, seeded } from "@/lib/canvas";
import { ControlButton, Controls, Stage, Stat } from "./lab-ui";
import { useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";
import { GOALS } from "@/lib/rewards";

type Style = "flow" | "orbits" | "tiles";
const STYLES: { id: Style; label: string }[] = [
  { id: "flow", label: "Flow field" },
  { id: "orbits", label: "Orbits" },
  { id: "tiles", label: "Tiles" },
];

const newSeed = () => Math.floor(Math.random() * 9000) + 1000;

export function SpecimenGenerator() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const t = useT();
  const [style, setStyle] = useState<Style>("flow");
  const [seed, setSeed] = useState(4821);
  const { award, logExperiment } = useRewards();
  const made = useRef(0);
  useEffect(() => logExperiment("art"), [logExperiment]);
  const regenerate = () => {
    setSeed(newSeed());
    made.current += 1;
    if (made.current >= GOALS.artSpecimens) void award("experiment", "art", "Specimen Generator");
  };

  useEffect(() => {
    setSeed(newSeed());
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const palette = readPalette();
    let raf = 0;

    const draw = (w: number, h: number) => {
      cancelAnimationFrame(raf);
      const rand = seeded(seed * 31 + style.length);
      const colors: string[] = [...palette.accents].sort(() => rand() - 0.5).slice(0, 3 + Math.floor(rand() * 2));
      const pickColor = () => colors[Math.floor(rand() * colors.length)] ?? palette.ink;
      ctx.globalAlpha = 1;
      ctx.fillStyle = palette.card;
      ctx.fillRect(0, 0, w, h);

      if (style === "flow") {
        const f1 = 0.002 + rand() * 0.006;
        const f2 = 0.002 + rand() * 0.006;
        const o1 = rand() * 100;
        const o2 = rand() * 100;
        const twist = 1 + rand() * 2.5;
        const angle = (x: number, y: number) =>
          (Math.sin(x * f1 + o1) + Math.cos(y * f2 + o2) + Math.sin((x + y) * f1 * 0.5)) * twist;
        const walkers = Array.from({ length: Math.round((w * h) / 900) }, () => ({
          x: rand() * w,
          y: rand() * h,
          c: pickColor(),
        }));
        let frame = 0;
        ctx.lineWidth = 1.4;
        ctx.lineCap = "round";
        const step = () => {
          ctx.globalAlpha = 0.5;
          for (const p of walkers) {
            const a = angle(p.x, p.y);
            const nx = p.x + Math.cos(a) * 1.6;
            const ny = p.y + Math.sin(a) * 1.6;
            ctx.strokeStyle = p.c;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(nx, ny);
            ctx.stroke();
            p.x = nx;
            p.y = ny;
          }
          frame++;
          if (frame < 140) raf = requestAnimationFrame(step);
          else ctx.globalAlpha = 1;
        };
        raf = requestAnimationFrame(step);
      } else if (style === "orbits") {
        const centers = 1 + Math.floor(rand() * 3);
        for (let c = 0; c < centers; c++) {
          const cx = w * (0.2 + rand() * 0.6);
          const cy = h * (0.2 + rand() * 0.6);
          const rings = 8 + Math.floor(rand() * 14);
          for (let i = 0; i < rings; i++) {
            const r = 10 + i * (6 + rand() * 10);
            const start = rand() * Math.PI * 2;
            const len = 0.3 + rand() * Math.PI * 1.6;
            ctx.strokeStyle = pickColor();
            ctx.lineWidth = 2 + rand() * 6;
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.arc(cx, cy, r, start, start + len);
            ctx.stroke();
            if (rand() < 0.35) {
              ctx.fillStyle = palette.ink;
              ctx.beginPath();
              ctx.arc(cx + Math.cos(start + len) * r, cy + Math.sin(start + len) * r, 3, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }
      } else {
        const size = Math.max(36, Math.min(w, h) / (5 + Math.floor(rand() * 5)));
        const cols = Math.ceil(w / size);
        const rows = Math.ceil(h / size);
        for (let y = 0; y < rows; y++) {
          for (let x = 0; x < cols; x++) {
            const px = x * size;
            const py = y * size;
            const kind = Math.floor(rand() * 6);
            ctx.fillStyle = pickColor();
            ctx.beginPath();
            if (kind === 0) {
              const corner = Math.floor(rand() * 4);
              const cx = px + (corner % 2) * size;
              const cy = py + Math.floor(corner / 2) * size;
              ctx.moveTo(cx, cy);
              ctx.arc(cx, cy, size, 0, Math.PI * 2);
              ctx.save();
              ctx.clip(new Path2D(`M${px} ${py}h${size}v${size}h${-size}z`));
              ctx.fill();
              ctx.restore();
              continue;
            } else if (kind === 1) {
              ctx.arc(px + size / 2, py + size / 2, size * 0.32, 0, Math.PI * 2);
            } else if (kind === 2) {
              ctx.moveTo(px, py);
              ctx.lineTo(px + size, py);
              ctx.lineTo(px, py + size);
            } else if (kind === 3) {
              ctx.arc(px + size / 2, py + size, size / 2, Math.PI, 0);
            } else if (kind === 4) {
              ctx.fillStyle = palette.ink;
              ctx.arc(px + size / 2, py + size / 2, size * 0.08, 0, Math.PI * 2);
            } else {
              ctx.rect(px + size * 0.15, py + size * 0.15, size * 0.7, size * 0.7);
            }
            ctx.fill();
          }
        }
      }
    };

    let last = { w: 0, h: 0 };
    const stopFit = fitCanvas(canvas, (w, h) => {
      if (Math.abs(w - last.w) < 1 && Math.abs(h - last.h) < 1) return;
      last = { w, h };
      draw(w, h);
    });
    return () => {
      cancelAnimationFrame(raf);
      stopFit();
    };
  }, [seed, style]);

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = `oddlab-specimen-${seed}.png`;
    a.click();
  };

  return (
    <div>
      <Stage hint={t("lab.specimen", { seed })}>
        <canvas
          ref={canvasRef}
          onClick={regenerate}
          className="block h-[60vh] max-h-[560px] min-h-[340px] w-full cursor-pointer"
          aria-label={`Generative artwork, specimen number ${seed}. Tap for a new one.`}
        />
      </Stage>
      <Controls>
        {STYLES.map((s) => (
          <ControlButton key={s.id} active={style === s.id} onClick={() => setStyle(s.id)}>
            {t(`lab.style.${s.id}`)}
          </ControlButton>
        ))}
        <ControlButton onClick={regenerate}>
          <RefreshCw className="size-3.5" /> {t("lab.newSpecimen")}
        </ControlButton>
        <ControlButton onClick={download}>
          <Download className="size-3.5" /> {t("lab.save")}
        </ControlButton>
      </Controls>
      <div className="mt-5 flex items-center">
        <span className="label-mono">{t("lab.unique")}</span>
        <Stat label={t("lab.seed")} value={seed} />
      </div>
    </div>
  );
}
