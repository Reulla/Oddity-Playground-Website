import { useEffect, useRef, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { fitCanvas, readPalette } from "@/lib/canvas";
import { ControlButton, Controls, Stage, Stat } from "./lab-ui";
import { useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";
import { GOALS } from "@/lib/rewards";

type Ball = { x: number; y: number; vx: number; vy: number; r: number; c: string };
type Api = { rain: () => void; shake: () => void; clear: () => void };

const MAX_BALLS = 180;

export function GravityBox() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const t = useT();
  const { award, logExperiment } = useRewards();
  const thrown = useRef(0);
  const onThrow = useRef(() => {});
  onThrow.current = () => {
    thrown.current += 1;
    if (thrown.current >= GOALS.gravityPlanets) void award("experiment", "gravity", "Gravity Box");
  };
  useEffect(() => logExperiment("gravity"), [logExperiment]);
  const [gravity, setGravity] = useState(0.5);
  const [ballCount, setBallCount] = useState(0);
  useEffect(() => {
    if (gravity <= -1) void award("easter_egg", "anti-gravity");
  }, [gravity, award]);
  const gravityRef = useRef(gravity);
  const apiRef = useRef<Api>({ rain: () => {}, shake: () => {}, clear: () => {} });

  useEffect(() => {
    gravityRef.current = gravity;
  }, [gravity]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const palette = readPalette();
    let w = 0;
    let h = 0;
    const stopFit = fitCanvas(canvas, (nw, nh) => {
      w = nw;
      h = nh;
    });

    const balls: Ball[] = [];
    const add = (x: number, y: number, vx = 0, vy = 0) => {
      if (balls.length >= MAX_BALLS) balls.shift();
      balls.push({
        x,
        y,
        vx,
        vy,
        r: 8 + Math.random() * 18,
        c: palette.accents[Math.floor(Math.random() * palette.accents.length)] ?? palette.ink,
      });
      setBallCount(balls.length);
    };

    // A few planets to start with
    for (let i = 0; i < 8; i++) add(40 + Math.random() * (w - 80), 30 + Math.random() * h * 0.4);

    apiRef.current = {
      rain: () => {
        for (let i = 0; i < 20; i++) {
          const top = gravityRef.current >= 0;
          add(20 + Math.random() * (w - 40), top ? 20 + Math.random() * 40 : h - 20 - Math.random() * 40, (Math.random() - 0.5) * 3, 0);
        }
      },
      shake: () => {
        for (const b of balls) {
          b.vx += (Math.random() - 0.5) * 24;
          b.vy += (Math.random() - 0.5) * 24;
        }
      },
      clear: () => {
        balls.length = 0;
        setBallCount(0);
      },
    };

    // Drag to fling, tap to drop
    let drag: { x: number; y: number; cx: number; cy: number } | null = null;
    const local = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onDown = (e: PointerEvent) => {
      const p = local(e);
      drag = { x: p.x, y: p.y, cx: p.x, cy: p.y };
      canvas.setPointerCapture(e.pointerId);
    };
    const onMove = (e: PointerEvent) => {
      if (!drag) return;
      const p = local(e);
      drag.cx = p.x;
      drag.cy = p.y;
    };
    const onUp = () => {
      if (!drag) return;
      add(drag.x, drag.y, (drag.cx - drag.x) / 6, (drag.cy - drag.y) / 6);
      onThrow.current();
      drag = null;
    };
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onUp);

    let raf = 0;
    const tick = () => {
      const g = gravityRef.current;
      ctx.clearRect(0, 0, w, h);

      for (const b of balls) {
        b.vy += g;
        b.vx *= 0.999;
        b.vy *= 0.999;
        b.x += b.vx;
        b.y += b.vy;
        if (b.x < b.r) (b.x = b.r), (b.vx *= -0.8);
        if (b.x > w - b.r) (b.x = w - b.r), (b.vx *= -0.8);
        if (b.y < b.r) {
          b.y = b.r;
          b.vy *= -0.75;
          if (g < 0) b.vx *= 0.98;
        }
        if (b.y > h - b.r) {
          b.y = h - b.r;
          b.vy *= -0.75;
          if (g > 0) b.vx *= 0.98;
        }
      }

      // Ball-to-ball collisions
      for (let i = 0; i < balls.length; i++) {
        const a = balls[i]!;
        for (let j = i + 1; j < balls.length; j++) {
          const b = balls[j]!;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const min = a.r + b.r;
          const d2 = dx * dx + dy * dy;
          if (d2 >= min * min || d2 === 0) continue;
          const d = Math.sqrt(d2);
          const nx = dx / d;
          const ny = dy / d;
          const ma = a.r * a.r;
          const mb = b.r * b.r;
          const overlap = min - d;
          a.x -= nx * overlap * (mb / (ma + mb));
          a.y -= ny * overlap * (mb / (ma + mb));
          b.x += nx * overlap * (ma / (ma + mb));
          b.y += ny * overlap * (ma / (ma + mb));
          const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
          if (rv < 0) {
            const imp = (-(1 + 0.8) * rv) / (1 / ma + 1 / mb);
            a.vx -= (imp * nx) / ma;
            a.vy -= (imp * ny) / ma;
            b.vx += (imp * nx) / mb;
            b.vy += (imp * ny) / mb;
          }
        }
      }

      for (const b of balls) {
        ctx.fillStyle = b.c;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
      }

      if (drag) {
        ctx.strokeStyle = palette.ink;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(drag.x, drag.y);
        ctx.lineTo(drag.cx, drag.cy);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.arc(drag.x, drag.y, 6, 0, Math.PI * 2);
        ctx.stroke();
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      stopFit();
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onUp);
    };
  }, []);

  const gLabel = gravity === 0 ? t("lab.zero") : `${gravity > 0 ? "↓" : "↑"} ${Math.abs(gravity).toFixed(2)}`;

  return (
    <div>
      <Stage hint={t("lab.hint.gravity")}>
        <canvas
          ref={canvasRef}
          className="dot-grid block h-[60vh] max-h-[560px] min-h-[340px] w-full touch-none cursor-pointer"
          aria-label="Gravity simulation. Tap to drop a planet, drag to fling one."
        />
      </Stage>
      <Controls>
        <ControlButton onClick={() => apiRef.current.rain()}>{t("lab.rain")}</ControlButton>
        <ControlButton onClick={() => setGravity((g) => -g)}>{t("lab.flip")}</ControlButton>
        <ControlButton active={gravity === 0} onClick={() => setGravity((g) => (g === 0 ? 0.5 : 0))}>
          {t("lab.zeroG")}
        </ControlButton>
        <ControlButton onClick={() => apiRef.current.shake()}>{t("lab.shake")}</ControlButton>
        <ControlButton onClick={() => apiRef.current.clear()}>{t("lab.clear")}</ControlButton>
      </Controls>
      <div className="mt-5 flex items-center gap-4">
        <span className="label-mono shrink-0">{t("lab.gravity")}</span>
        <Slider
          value={[gravity]}
          min={-1}
          max={1}
          step={0.05}
          onValueChange={(v) => setGravity(Math.round((v[0] ?? 0) * 100) / 100)}
          className="max-w-xs"
          aria-label={t("lab.gravityAria")}
        />
        <Stat label="g" value={`${gLabel} · ${t("lab.planets", { n: ballCount })}`} />
      </div>
    </div>
  );
}
