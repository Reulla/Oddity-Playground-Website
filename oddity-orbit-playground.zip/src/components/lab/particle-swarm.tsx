import { useEffect, useRef, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { fitCanvas, readPalette } from "@/lib/canvas";
import { ControlButton, Controls, Stage, Stat } from "./lab-ui";
import { useT } from "@/lib/preferences";
import { useRewards } from "@/lib/use-rewards";
import { GOALS } from "@/lib/rewards";

type Mode = "attract" | "repel" | "orbit";
type P = { x: number; y: number; vx: number; vy: number; r: number; c: string };

export function ParticleSwarm() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const t = useT();
  const [mode, setMode] = useState<Mode>("attract");
  const [count, setCount] = useState(260);
  const { award, logExperiment } = useRewards();
  const [modesTried, setModesTried] = useState<Set<Mode>>(() => new Set<Mode>(["attract"]));
  useEffect(() => logExperiment("particles"), [logExperiment]);
  useEffect(() => {
    if (GOALS.particleModes.every((m) => modesTried.has(m))) void award("experiment", "particles", "Particle Swarm");
  }, [modesTried, award]);
  useEffect(() => {
    if (count >= 600) void award("easter_egg", "crowd-control");
  }, [count, award]);
  const modeRef = useRef<Mode>(mode);
  const scatterRef = useRef<() => void>(() => {});

  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const palette = readPalette();
    let w = 0;
    let h = 0;
    const stopFit = fitCanvas(canvas, (nw, nh) => {
      w = nw;
      h = nh;
    });

    const ps: P[] = Array.from({ length: count }, (_, i) => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 2,
      vy: (Math.random() - 0.5) * 2,
      r: 1.5 + Math.random() * 2.5,
      c: palette.accents[i % palette.accents.length] ?? palette.ink,
    }));

    const pointer = { x: w / 2, y: h / 2, active: false };

    const burst = (x: number, y: number, power: number) => {
      for (const p of ps) {
        const dx = p.x - x;
        const dy = p.y - y;
        const d = Math.hypot(dx, dy) || 1;
        const f = (power * 120) / (d + 30);
        p.vx += (dx / d) * f;
        p.vy += (dy / d) * f;
      }
    };
    scatterRef.current = () => burst(w / 2, h / 2, 1.4);

    const local = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onMove = (e: PointerEvent) => {
      const p = local(e);
      pointer.x = p.x;
      pointer.y = p.y;
      pointer.active = true;
    };
    const onLeave = () => {
      pointer.active = false;
    };
    const onDown = (e: PointerEvent) => {
      onMove(e);
      burst(pointer.x, pointer.y, 1);
    };
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("pointercancel", onLeave);

    let raf = 0;
    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      const m = modeRef.current;
      for (const p of ps) {
        if (pointer.active) {
          const dx = pointer.x - p.x;
          const dy = pointer.y - p.y;
          const d = Math.hypot(dx, dy) || 1;
          if (m === "attract") {
            const f = Math.min(0.6, 40 / d);
            p.vx += (dx / d) * f;
            p.vy += (dy / d) * f;
          } else if (m === "repel") {
            if (d < 160) {
              const f = (160 - d) / 160;
              p.vx -= (dx / d) * f * 1.6;
              p.vy -= (dy / d) * f * 1.6;
            }
          } else {
            const f = Math.min(0.5, 30 / d);
            p.vx += (-dy / d) * f + (dx / d) * f * 0.35;
            p.vy += (dx / d) * f + (dy / d) * f * 0.35;
          }
        } else {
          p.vx += (Math.random() - 0.5) * 0.12;
          p.vy += (Math.random() - 0.5) * 0.12;
        }
        p.vx *= 0.95;
        p.vy *= 0.95;
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) (p.x = 0), (p.vx *= -1);
        if (p.x > w) (p.x = w), (p.vx *= -1);
        if (p.y < 0) (p.y = 0), (p.vy *= -1);
        if (p.y > h) (p.y = h), (p.vy *= -1);
        ctx.fillStyle = p.c;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      stopFit();
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("pointercancel", onLeave);
    };
  }, [count]);

  return (
    <div>
      <Stage hint={t("lab.hint.particles")}>
        <canvas
          ref={canvasRef}
          className="block h-[60vh] max-h-[560px] min-h-[340px] w-full touch-none cursor-crosshair"
          aria-label="Particle simulation. Move your pointer to influence the particles; tap to make them burst."
        />
      </Stage>
      <Controls>
        {(["attract", "repel", "orbit"] as Mode[]).map((m) => (
          <ControlButton key={m} active={mode === m} onClick={() => { setMode(m); setModesTried((s) => new Set(s).add(m)); }} >
            {t(`lab.mode.${m}`)}
          </ControlButton>
        ))}
        <ControlButton onClick={() => scatterRef.current()}>{t("lab.scatter")}</ControlButton>
      </Controls>
      <div className="mt-5 flex items-center gap-4">
        <span className="label-mono shrink-0">{t("lab.particles")}</span>
        <Slider
          value={[count]}
          min={40}
          max={600}
          step={20}
          onValueChange={(v) => setCount(v[0] ?? 260)}
          className="max-w-xs"
          aria-label={t("lab.particlesAria")}
        />
        <Stat label="n =" value={count} />
      </div>
    </div>
  );
}
