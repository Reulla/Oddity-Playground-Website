import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Stage({ children, hint }: { children: ReactNode; hint?: string }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border bg-card shadow-soft">
      {children}
      {hint && (
        <p className="label-mono pointer-events-none absolute left-3 top-3 select-none rounded-full bg-background/80 px-2.5 py-1">
          {hint}
        </p>
      )}
    </div>
  );
}

export function Controls({ children }: { children: ReactNode }) {
  return <div className="mt-4 flex flex-wrap items-center gap-2">{children}</div>;
}

export function ControlButton({
  active,
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex h-9 items-center gap-1.5 rounded-full border px-4 text-sm font-medium transition-all duration-200 active:scale-95",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "bg-card text-foreground hover:border-foreground/30 hover:bg-muted",
        className,
      )}
      {...props}
    />
  );
}

export function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <span className="ml-auto font-mono text-xs text-muted-foreground">
      {label} <span className="text-foreground">{value}</span>
    </span>
  );
}
