import { describe, expect, it } from "vitest";
import { GOLDEN_EVENT, MILESTONES, pickButtonEvent } from "@/lib/button-events";
import { oddities, pickRandomOddity } from "@/lib/oddities";
import { pickRandomExperiment } from "@/lib/experiments";

describe("The Button", () => {
  it("shows the milestone message on the 10th click", () => {
    expect(pickButtonEvent(10, undefined).text).toBe(MILESTONES[10]);
  });

  it("never repeats the same event twice in a row", () => {
    for (let i = 0; i < 200; i++) {
      const prev = pickButtonEvent(3, undefined);
      const next = pickButtonEvent(3, prev.id, () => 0.5);
      if (prev.id !== GOLDEN_EVENT.id) expect(next.id).not.toBe(prev.id);
    }
  });

  it("gives the Golden Click when the 1% roll hits", () => {
    expect(pickButtonEvent(7, undefined, () => 0.001).id).toBe(GOLDEN_EVENT.id);
  });
});

describe("Random picks", () => {
  it("random discovery never returns the oddity already shown", () => {
    for (let i = 0; i < 100; i++) {
      expect(pickRandomOddity(oddities, 1)?.id).not.toBe(1);
    }
  });

  it("random experiment can skip the current one", () => {
    for (let i = 0; i < 100; i++) {
      expect(pickRandomExperiment("button")?.id).not.toBe("button");
    }
  });
});
