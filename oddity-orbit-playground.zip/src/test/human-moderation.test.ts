import { describe, expect, it } from "vitest";
import { HON_DEFAULT_MINUTES, clampMinutes, difficultyFor } from "@/lib/human-or-not";
import { moderationExpiry } from "@/lib/moderation";

describe("Human Or Not? timer", () => {
  it("defaults to 3 minutes", () => expect(HON_DEFAULT_MINUTES).toBe(3));
  it("only allows 3 to 20 minutes", () => {
    expect(clampMinutes(1)).toBe(3);
    expect(clampMinutes(45)).toBe(20);
    expect(clampMinutes(12)).toBe(12);
  });
  it("gets harder as the timer gets longer", () => {
    expect(difficultyFor(3)).toBe(1);
    expect(difficultyFor(20)).toBe(5);
    expect(difficultyFor(10)).toBeGreaterThan(difficultyFor(5));
  });
});

describe("Moderation lengths", () => {
  const now = new Date("2026-01-01T00:00:00Z");
  it("timeout ends after the chosen minutes", () => {
    expect(moderationExpiry("timeout", 60, now)).toEqual(new Date("2026-01-01T01:00:00Z"));
  });
  it("suspension ends after the chosen days", () => {
    expect(moderationExpiry("suspend", 7, now)).toEqual(new Date("2026-01-08T00:00:00Z"));
  });
  it("ban is permanent", () => expect(moderationExpiry("ban", 999, now)).toBeNull());
  it("rejects lengths out of range", () => {
    expect(moderationExpiry("timeout", 5, now)).toBe("invalid");
    expect(moderationExpiry("suspend", 400, now)).toBe("invalid");
  });
});
